---

name: wechat-hot-article-extractor
description: 使用 API 或网页抓取等多种数据源，提取近期发布、阅读量 10 万+ 的微信公众号爆款文章。
version: 1.0.0
tags: [wechat, content, trending, scraping, analysis]
---




# 🧠 WeChat Hot Article Extractor

## 📌 Overview
This skill extracts WeChat public account articles that meet the following criteria:

- Published within the last N days (default: 7)
- Read count ≥ specified threshold (default: 100,000)

Supports multiple data sources including:
- Newrank API
- GSData API
- Sogou WeChat Search (fallback)
- Custom database

---

## ⚙️ Input Schema

```json
{
  "days": 7,
  "min_read": 100000,
  "source": "auto",
  "keyword": "热点",
  "api_key": null
}