# 公众号文章去 AI 化

把 AI 生成的公众号长文改写成有作者声音的真人文。专攻长文（1500-3000 字）AI 痕迹：开头套话、中段对仗、结尾鸡汤。

## 这是什么

`wechat-article-rewrite` 是一个针对**中国本地场景**原创设计的 OpenClaw /  Agent Skill。

不是任何已有项目的 fork 或翻译——从问题定义、框架设计、示例都是为中国用户从零写的。

## 触发场景

详见 `SKILL.md` 的 description 字段，AI 会自动判断何时调用。常见关键词：

- `公众号`
- `AI 改写`
- `去 AI 化`
- `长文`
- `自媒体`
- `降低 AI 率`

## 安装

### （推荐）

```bash
# 通过  Web 界面下载
# https://.cloud.tencent.com/skills/wechat-article-rewrite
```

### OpenClaw / Claude Code

```bash
mkdir -p ~/.claude/skills
cp -R wechat-article-rewrite ~/.claude/skills/wechat-article-rewrite
```

### Cursor

把整个文件夹放到项目的 `.cursor/skills/wechat-article-rewrite/` 下，重启 Cursor 即可。

## 用法

直接用自然语言描述需求，AI 会自动加载本 skill。例如：

```
帮我用 公众号文章去 AI 化 来 ...
```

## License

MIT © 2026 ikun

## 反馈

- 觉得有用：在  给个 star
- 报 bug / 建议：在  评论区留言
