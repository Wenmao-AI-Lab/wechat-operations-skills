import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
README_PATH = ROOT / "README.md"
SKILL_PATH = ROOT / "SKILL.md"
EXAMPLES_PATH = ROOT / "references" / "examples.md"
VALIDATOR_PATH = ROOT / "scripts" / "validate-skill-package.py"

validator_spec = importlib.util.spec_from_file_location("skill_validator", VALIDATOR_PATH)
skill_validator = importlib.util.module_from_spec(validator_spec)
validator_spec.loader.exec_module(skill_validator)


class SkillDocsTest(unittest.TestCase):
    def test_examples_reference_file_is_required(self):
        self.assertIn("references/examples.md", skill_validator.REQUIRED_FILES)
        self.assertTrue(EXAMPLES_PATH.exists(), "examples reference should exist")

    def test_readme_has_quick_selector(self):
        readme = README_PATH.read_text(encoding="utf-8")

        self.assertIn("## 3 秒上手", readme)
        self.assertIn("你现在想做什么？", readme)
        self.assertIn("全自动 XX，不用我选", readme)
        self.assertIn("审校这篇文章", readme)
        self.assertIn("炼化 XX 风格", readme)
        self.assertIn("发布包", readme)

    def test_skill_has_default_entry_strategy_and_examples_reference(self):
        skill = SKILL_PATH.read_text(encoding="utf-8")

        self.assertIn("## 默认入口策略", skill)
        self.assertIn("默认按 L2 标准模式处理", skill)
        self.assertIn("references/examples.md", skill)


if __name__ == "__main__":
    unittest.main()
