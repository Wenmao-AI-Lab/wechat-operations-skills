import importlib.util
import unittest
from pathlib import Path


SCRIPT_PATH = Path(__file__).resolve().parents[1] / "scripts" / "wechat-formatter.py"
spec = importlib.util.spec_from_file_location("wechat_formatter", SCRIPT_PATH)
wechat_formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wechat_formatter)


class WechatFormatterTest(unittest.TestCase):
    def test_short_footnote_is_inlined(self):
        result = wechat_formatter.convert("正文有注释[^n]\n\n[^n]: 很短的说明")

        self.assertIn("正文有注释（注：很短的说明）", result)
        self.assertNotIn("[^n]:", result)

    def test_long_footnote_moves_to_appendix(self):
        long_note = "这是一条很长的引用说明，" * 8

        result = wechat_formatter.convert(f"正文有长注释[^long-note]\n\n[^long-note]: {long_note}")

        self.assertIn("### 注释与引用", result)
        self.assertIn(long_note, result)
        self.assertNotIn("[^long-note]", result)

    def test_code_block_is_labeled_and_indented(self):
        result = wechat_formatter.convert("```python\nprint('hi')\n```")

        self.assertIn("【代码 · python】", result)
        self.assertIn("  print('hi')", result)

    def test_table_is_converted_to_list(self):
        markdown = "| 工具 | 用途 |\n|---|---|\n| Codex | 写作 |\n"

        result = wechat_formatter.convert(markdown)

        self.assertIn("【表格】", result)
        self.assertIn("工具：Codex，用途：写作", result)

    def test_quote_block_is_indented(self):
        result = wechat_formatter.convert("> 这是一句引用")

        self.assertIn("  这是一句引用", result)

    def test_trailing_hashtag_line_is_stripped_but_inline_hashtag_is_kept(self):
        markdown = "正文里提到 #AI 这个话题。\n\n#AI #写作"

        result = wechat_formatter.convert(markdown)

        self.assertIn("正文里提到 #AI 这个话题。", result)
        self.assertTrue(result.rstrip().endswith("AI 写作"))


if __name__ == "__main__":
    unittest.main()
