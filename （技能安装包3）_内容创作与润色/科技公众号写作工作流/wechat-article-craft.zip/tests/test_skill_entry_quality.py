import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SKILL_PATH = ROOT / "SKILL.md"
WORKFLOW_DETAILS_PATH = ROOT / "references" / "workflow-details.md"
FORWARD_EVALS_PATH = ROOT / "references" / "forward-evals.md"
VALIDATOR_PATH = ROOT / "scripts" / "validate-skill-package.py"


class SkillEntryQualityTest(unittest.TestCase):
    def test_forward_eval_suite_exists_and_has_core_scenarios(self):
        self.assertTrue(FORWARD_EVALS_PATH.exists(), "forward eval suite should exist")
        content = FORWARD_EVALS_PATH.read_text(encoding="utf-8")

        cases = re.findall(r"^## Case \d+：", content, re.MULTILINE)
        self.assertGreaterEqual(len(cases), 8)
        for marker in [
            "全自动直出",
            "半自动选题",
            "审校已有稿",
            "指定风格写作",
            "发布包生成",
        ]:
            self.assertIn(marker, content)

    def test_triggers_focus_on_high_intent_phrases(self):
        skill = SKILL_PATH.read_text(encoding="utf-8")

        for marker in [
            "- 帮我看看",
            "- 点评\n",
            "- 敏感词",
            "- 违禁词",
            "- 社交分享",
            "- 子进程",
            "- 哪个风格好",
        ]:
            self.assertNotIn(marker, skill)

        for marker in [
            "- 全自动",
            "- 写公众号",
            "- 文章审校",
            "- 标题优化",
            "- 炼化",
            "- 点评文章",
            "- 风格交叉",
            "- 发布包",
        ]:
            self.assertIn(marker, skill)

    def test_workflow_details_has_fast_style_recommendation(self):
        content = WORKFLOW_DETAILS_PATH.read_text(encoding="utf-8")

        self.assertIn("## 快速风格推荐", content)
        for marker in [
            "产品实测 / 工具踩坑",
            "行业新闻 / 技术突破",
            "技术科普 / 入门教程",
            "深度研究 / 长文论证",
        ]:
            self.assertIn(marker, content)

    def test_validator_requires_forward_eval_suite(self):
        validator = VALIDATOR_PATH.read_text(encoding="utf-8")

        self.assertIn('"references/forward-evals.md"', validator)
        self.assertIn("forward eval", validator.lower())


if __name__ == "__main__":
    unittest.main()
