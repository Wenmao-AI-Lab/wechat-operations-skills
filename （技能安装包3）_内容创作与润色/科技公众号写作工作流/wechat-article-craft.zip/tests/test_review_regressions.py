import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONSISTENCY_PATH = ROOT / ".consistency.yml"
DESIGN_PATH = ROOT / "DESIGN.md"
SKILL_PATH = ROOT / "SKILL.md"
README_PATH = ROOT / "README.md"
L1_PATH = ROOT / "references" / "l1-fast-lane.md"
WORKFLOW_DETAILS_PATH = ROOT / "references" / "workflow-details.md"


class ReviewRegressionsTest(unittest.TestCase):
    def test_consistency_header_version_is_current(self):
        content = CONSISTENCY_PATH.read_text(encoding="utf-8")
        self.assertIn("v5.12.3+", content)

    def test_design_uses_current_framework_and_content_framework_count(self):
        content = DESIGN_PATH.read_text(encoding="utf-8")
        self.assertIn("20 大 V 风格 + 8 套内容框架", content)
        self.assertNotIn("20 大 V 风格 + 7 套内容框架", content)
        self.assertNotIn("3内核+9技法", content)
        self.assertIn("3 个内核维度 + 8 个技法维度 + 可选多模态维度", content)

    def test_design_heading_numbering_is_unique(self):
        content = DESIGN_PATH.read_text(encoding="utf-8")
        self.assertIn("## 七、Skill 自维护", content)
        self.assertIn("## 八、版本演进", content)
        self.assertNotIn("## 七、版本演进", content)

    def test_skill_output_uses_dynamic_l2_grep_total(self):
        content = SKILL_PATH.read_text(encoding="utf-8")
        self.assertIn("[L2] - 最低保障 grep：[通过项数]/[总项数]", content)
        self.assertNotIn("[L2] - 最低保障 grep：[通过项数]/9", content)

    def test_operational_docs_use_file_aligned_style_names(self):
        targets = [
            SKILL_PATH.read_text(encoding="utf-8"),
            README_PATH.read_text(encoding="utf-8"),
            L1_PATH.read_text(encoding="utf-8"),
            WORKFLOW_DETAILS_PATH.read_text(encoding="utf-8"),
        ]
        combined = "\n".join(targets)

        self.assertIn("数字生命卡兹克", combined)
        self.assertIn("凯文凯利", combined)
        self.assertNotRegex(combined, r"(?m)^\| 卡兹克 \|")
        self.assertNotRegex(combined, r"(?m)^\| 凯文·凯利 \|")


if __name__ == "__main__":
    unittest.main()
