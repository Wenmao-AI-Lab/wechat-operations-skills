#!/usr/bin/env python3
"""Validate the Work Buddy skill package before publishing or syncing."""

from __future__ import annotations

import argparse
import filecmp
import re
import sys
from pathlib import Path


VERSION = "5.12.3"
REQUIRED_FILES = [
    "SKILL.md",
    "README.md",
    "DESIGN.md",
    "CHANGELOG.md",
    ".consistency.yml",
    "references/examples.md",
    "references/forward-evals.md",
    "references/l1-fast-lane.md",
    "references/l2-l3-workflow.md",
    "references/workflow-details.md",
    "references/refinement-framework.md",
    "scripts/wechat-formatter.py",
    "scripts/validate-skill-package.py",
    "tests/test_skill_docs.py",
    "tests/test_skill_entry_quality.py",
    "tests/test_review_regressions.py",
    "tests/test_wechat_formatter.py",
]
REFINEMENT_REQUIRED_SECTIONS = [
    "风格注入指令",
    "匹配矩阵",
    "绝招判据",
    "建议刷新",
]
STALE_PATTERNS = [
    r"L1 所需规则已在 SKILL\.md 自包含",
    r"L1 自包含~700行",
    r"SKILL\.md → L1自包含",
    r"3 内核（⑨⑩⑪）\+ 9 技法",
    r"3 内核 \+ 9 技法",
    r"3 个内核 \+ 9",
    r"全文自动",
    r"排版/多平台分发的 → 这不是科技公众号写作做的事",
]
IGNORED_NAMES = {".DS_Store"}
IGNORED_SUFFIXES = {".pyc", ".pyo"}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def error(errors: list[str], message: str) -> None:
    errors.append(message)


def check_required_files(root: Path, errors: list[str]) -> None:
    for relative in REQUIRED_FILES:
        if not (root / relative).is_file():
            error(errors, f"missing required file: {relative}")


def check_forbidden_artifacts(root: Path, errors: list[str]) -> None:
    for path in root.rglob("*"):
        if "__pycache__" in path.parts:
            error(errors, f"forbidden cache artifact: {path.relative_to(root)}")
        elif path.name in IGNORED_NAMES or path.suffix in IGNORED_SUFFIXES:
            error(errors, f"forbidden generated artifact: {path.relative_to(root)}")


def check_versions(root: Path, errors: list[str]) -> None:
    targets = [
        "SKILL.md",
        "README.md",
        "DESIGN.md",
        "CHANGELOG.md",
        "references/workflow-details.md",
    ]
    for relative in targets:
        path = root / relative
        if path.exists() and VERSION not in read_text(path):
            error(errors, f"{relative} does not mention v{VERSION}")

    skill = read_text(root / "SKILL.md") if (root / "SKILL.md").exists() else ""
    if f'version: "{VERSION}"' not in skill:
        error(errors, f"SKILL.md frontmatter version is not {VERSION}")


def check_stale_text(root: Path, errors: list[str]) -> None:
    text_files = [
        "README.md",
        "DESIGN.md",
        "SKILL.md",
        "references/l2-l3-workflow.md",
        "references/workflow-details.md",
        "references/refinement-framework.md",
        "references/audit-semantic-drift.md",
    ]
    for relative in text_files:
        path = root / relative
        if not path.exists():
            continue
        content = read_text(path)
        for pattern in STALE_PATTERNS:
            if re.search(pattern, content):
                error(errors, f"stale text in {relative}: {pattern}")


def check_refinements(root: Path, errors: list[str]) -> None:
    refinements_dir = root / "references" / "refinements"
    files = sorted(refinements_dir.glob("*.md")) if refinements_dir.exists() else []
    if len(files) != 20:
        error(errors, f"expected 20 refinement files, found {len(files)}")

    for path in files:
        content = read_text(path)
        for section in REFINEMENT_REQUIRED_SECTIONS:
            if section not in content:
                error(errors, f"{path.relative_to(root)} missing section/text: {section}")


def check_style_count(root: Path, errors: list[str]) -> None:
    skill_path = root / "SKILL.md"
    if not skill_path.exists():
        return
    content = read_text(skill_path)
    table_rows = re.findall(r"^\| [^|\n]+ \| [^|\n]+ \| [^|\n]+ \|$", content, re.MULTILINE)
    style_rows = [row for row in table_rows if not row.startswith("| 风格 ") and "---" not in row]
    if len(style_rows) < 20:
        error(errors, f"SKILL.md style table has fewer than 20 rows: {len(style_rows)}")


def check_quick_start_docs(root: Path, errors: list[str]) -> None:
    readme = root / "README.md"
    skill = root / "SKILL.md"
    examples = root / "references" / "examples.md"

    if readme.exists():
        content = read_text(readme)
        for marker in [
            "## 3 秒上手",
            "你现在想做什么？",
            "全自动 XX，不用我选",
            "审校这篇文章",
            "炼化 XX 风格",
            "完整示例见 `references/examples.md`。",
        ]:
            if marker not in content:
                error(errors, f"README.md missing quick-start marker: {marker}")

    if skill.exists():
        content = read_text(skill)
        for marker in [
            "## 默认入口策略",
            "默认按 L2 标准模式处理",
            "references/examples.md",
        ]:
            if marker not in content:
                error(errors, f"SKILL.md missing entry-strategy marker: {marker}")

    if examples.exists():
        content = read_text(examples)
        for marker in [
            "全自动写一篇 AI Agent 现状 3000 字，不用我选",
            "帮我看看这篇文章哪里不行",
            "用阮一峰风格写一篇 MCP 入门",
        ]:
            if marker not in content:
                error(errors, f"references/examples.md missing example marker: {marker}")


def check_forward_evals(root: Path, errors: list[str]) -> None:
    forward_evals = root / "references" / "forward-evals.md"
    workflow_details = root / "references" / "workflow-details.md"

    if forward_evals.exists():
        content = read_text(forward_evals)
        cases = re.findall(r"^## Case \d+：", content, re.MULTILINE)
        if len(cases) < 8:
            error(errors, f"forward eval suite has fewer than 8 cases: {len(cases)}")
        for marker in [
            "全自动直出",
            "半自动选题",
            "审校已有稿",
            "指定风格写作",
            "发布包生成",
        ]:
            if marker not in content:
                error(errors, f"forward eval suite missing scenario marker: {marker}")

    if workflow_details.exists():
        content = read_text(workflow_details)
        for marker in [
            "## 快速风格推荐",
            "产品实测 / 工具踩坑",
            "行业新闻 / 技术突破",
            "技术科普 / 入门教程",
            "深度研究 / 长文论证",
        ]:
            if marker not in content:
                error(errors, f"workflow-details missing style recommendation marker: {marker}")


def check_trigger_hygiene(root: Path, errors: list[str]) -> None:
    skill = root / "SKILL.md"
    if not skill.exists():
        return

    content = read_text(skill)
    banned_markers = [
        "- 帮我看看",
        "- 点评\n",
        "- 敏感词",
        "- 违禁词",
        "- 社交分享",
        "- 子进程",
        "- 哪个风格好",
    ]
    required_markers = [
        "- 全自动",
        "- 写公众号",
        "- 文章审校",
        "- 标题优化",
        "- 炼化",
        "- 点评文章",
        "- 风格交叉",
        "- 发布包",
    ]

    for marker in banned_markers:
        if marker in content:
            error(errors, f"SKILL.md still contains low-precision trigger: {marker.strip()}")
    for marker in required_markers:
        if marker not in content:
            error(errors, f"SKILL.md missing high-intent trigger: {marker.strip()}")


def check_review_regressions(root: Path, errors: list[str]) -> None:
    consistency = root / ".consistency.yml"
    design = root / "DESIGN.md"
    skill = root / "SKILL.md"

    if consistency.exists():
        content = read_text(consistency)
        if "v5.12.3+" not in content:
            error(errors, ".consistency.yml header version is not v5.12.3+")

    if design.exists():
        content = read_text(design)
        if "20 大 V 风格 + 7 套内容框架" in content:
            error(errors, "DESIGN.md still mentions 7 content frameworks")
        if "3内核+9技法" in content or "3 内核+9技法" in content or "3 内核 + 9 技法" in content:
            error(errors, "DESIGN.md still uses the old 3内核+9技法 wording")
        if "## 七、版本演进" in content:
            error(errors, "DESIGN.md still has duplicate 七 heading for version history")

    if skill.exists():
        content = read_text(skill)
        if "[L2] - 最低保障 grep：[通过项数]/9" in content:
            error(errors, "SKILL.md still hardcodes the L2 grep total as 9")


def compare_dirs(project_root: Path, active_root: Path, errors: list[str]) -> None:
    if not active_root.exists():
        error(errors, f"active skill path does not exist: {active_root}")
        return

    comparison = filecmp.dircmp(project_root, active_root)

    def walk(cmp: filecmp.dircmp, prefix: Path = Path("")) -> None:
        for name in cmp.left_only:
            error(errors, f"active sync missing: {prefix / name}")
        for name in cmp.right_only:
            error(errors, f"active sync extra: {prefix / name}")
        for name in cmp.diff_files:
            error(errors, f"active sync differs: {prefix / name}")
        for name, subcmp in cmp.subdirs.items():
            walk(subcmp, prefix / name)

    walk(comparison)


def validate(root: Path, active: Path | None = None) -> list[str]:
    errors: list[str] = []
    check_required_files(root, errors)
    check_forbidden_artifacts(root, errors)
    check_versions(root, errors)
    check_stale_text(root, errors)
    check_refinements(root, errors)
    check_style_count(root, errors)
    check_quick_start_docs(root, errors)
    check_forward_evals(root, errors)
    check_trigger_hygiene(root, errors)
    check_review_regressions(root, errors)
    if active:
        compare_dirs(root, active, errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, help="Path to the skill package, e.g. 5-skill")
    parser.add_argument("--active", type=Path, help="Optional active Work Buddy skill path")
    args = parser.parse_args()

    root = args.root.resolve()
    active = args.active.resolve() if args.active else None
    errors = validate(root, active)

    if errors:
        print(f"Skill package validation failed: {len(errors)} issue(s)")
        for item in errors:
            print(f"- {item}")
        return 1

    print("Skill package validation passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
