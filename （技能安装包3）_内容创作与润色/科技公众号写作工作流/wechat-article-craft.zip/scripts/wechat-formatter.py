#!/usr/bin/env python3
"""
公众号格式适配器 —— Markdown → 公众号编辑器可粘贴文本

处理公众号编辑器不支持的 Markdown 语法：
- 脚注 [^n] → 短脚注转括号注释，长脚注转文末附录
- 代码块 ``` → 标注 + 缩进
- 表格 | → 缩进列表
- 分隔线 --- → 空行
- #标签 → 去#号

用法：python3 wechat-formatter.py <文章.md> [输出文件]
"""

import re
import sys
from pathlib import Path


def collect_footnotes(text: str) -> tuple[str, dict[str, str]]:
    """提取脚注定义，返回 (正文, {脚注ID: 脚注内容})"""
    footnotes = {}
    # 匹配 [^id]: content 定义
    def_pattern = re.compile(r'^\[\^([\w-]+)\]:\s*(.+)$', re.MULTILINE)
    for m in def_pattern.finditer(text):
        footnotes[m.group(1)] = m.group(2).strip()
    # 删除脚注定义行
    text = def_pattern.sub('', text)
    return text, footnotes


def inline_footnotes(text: str, footnotes: dict[str, str]) -> str:
    """将 [^id] 引用替换为内联格式"""
    def replacer(m):
        fid = m.group(1)
        content = footnotes.get(fid, '')
        if not content:
            return ''
        if len(content) <= 80:
            return f'（注：{content}）'
        return ''  # 长脚注留在附录

    return re.sub(r'\[\^([\w-]+)\]', replacer, text)


def build_footnote_appendix(footnotes: dict[str, str]) -> str:
    """生成长脚注文末附录"""
    long_notes = {k: v for k, v in footnotes.items() if len(v) > 80}
    if not long_notes:
        return ''
    lines = ['', '### 注释与引用', '']
    for i, (fid, content) in enumerate(long_notes.items(), 1):
        lines.append(f'{i}. {content}')
    return '\n'.join(lines)


def convert_code_blocks(text: str) -> str:
    """代码块 → 标注+缩进"""
    def replacer(m):
        lang = m.group(1) or ''
        code = m.group(2).strip()
        prefix = f'【代码{f" · {lang}" if lang else ""}】'
        indented = '\n'.join(f'  {line}' for line in code.split('\n'))
        return f'{prefix}\n{indented}\n'
    return re.sub(r'```(\w*)\n(.*?)```', replacer, text, flags=re.DOTALL)


def convert_tables(text: str) -> str:
    """表格 → 缩进列表"""
    def replacer(m):
        table = m.group(0)
        lines = table.strip().split('\n')
        if len(lines) < 2:
            return table
        # 取表头
        headers = [h.strip() for h in lines[0].strip('|').split('|')]
        # 跳过对齐行
        data_lines = [l for l in lines[2:] if l.strip() and not re.match(r'^[\|\-\s:]+$', l)]
        result = ['【表格】']
        for dl in data_lines:
            cells = [c.strip() for c in dl.strip('|').split('|')]
            row_parts = []
            for h, c in zip(headers, cells):
                row_parts.append(f'{h}：{c}')
            result.append('  • ' + '，'.join(row_parts))
        return '\n'.join(result)
    return re.sub(r'(\|.+\|\n\|[-|\s:]+\|\n(\|.+\|\n?)+)', replacer, text)


def convert_separators(text: str) -> str:
    """分隔线 → 空行"""
    return re.sub(r'\n---\n', '\n', text)


def strip_hashtags(text: str) -> str:
    """独立话题标签行去 #，避免误伤正文中的 #AI。"""
    def replacer(m):
        tags = re.findall(r'#(\S+)', m.group(0))
        return ' '.join(tags)

    return re.sub(r'(?m)^(?:#[^\s#]+(?:\s+|$))+$', replacer, text)


def format_quotes(text: str) -> str:
    """引用块 > → 缩进（公众号编辑器可手动设引用样式）"""
    lines = text.split('\n')
    result = []
    in_quote = False
    for line in lines:
        if line.startswith('> '):
            if not in_quote:
                in_quote = True
            result.append('  ' + line[2:])
        else:
            if in_quote and line.strip() == '':
                in_quote = False
            result.append(line)
    return '\n'.join(result)


def convert(markdown_text: str) -> str:
    """主转换流程"""
    text = markdown_text

    # 1. 提取脚注
    text, footnotes = collect_footnotes(text)

    # 2. 代码块
    text = convert_code_blocks(text)

    # 3. 表格
    text = convert_tables(text)

    # 4. 分隔线
    text = convert_separators(text)

    # 5. 引用块
    text = format_quotes(text)

    # 6. 内联脚注
    text = inline_footnotes(text, footnotes)

    # 7. 文末标签
    text = strip_hashtags(text)

    # 8. 长脚注附录
    text += build_footnote_appendix(footnotes)

    # 9. 清理多余空行
    text = re.sub(r'\n{4,}', '\n\n\n', text)

    return text.rstrip() + '\n'


def main():
    if len(sys.argv) < 2:
        print('用法：python3 wechat-formatter.py <文章.md> [输出文件]')
        print('  输出文件可省略，默认输出到 <文章>-wechat.md')
        sys.exit(1)

    input_path = Path(sys.argv[1])
    if not input_path.exists():
        print(f'错误：文件不存在 — {input_path}')
        sys.exit(1)

    output_path = Path(sys.argv[2]) if len(sys.argv) > 2 else input_path.with_stem(f'{input_path.stem}-wechat')

    text = input_path.read_text(encoding='utf-8')
    result = convert(text)
    output_path.write_text(result, encoding='utf-8')

    print(f'✅ 已转换：{input_path.name} → {output_path.name}')
    print(f'   可直接粘贴到公众号编辑器。')
    print(f'   提示：标题（##/###）和加粗（**）保留，需在编辑器中手动设置样式。')


if __name__ == '__main__':
    main()
