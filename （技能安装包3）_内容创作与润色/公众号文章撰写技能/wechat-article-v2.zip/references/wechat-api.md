# 微信公众号 API 参考文档

## 基础接口

### 获取 Access Token

- **接口英文名**：getAccessToken
- **请求URL**：`GET https://api.weixin.qq.com/cgi-bin/token?appid=APPID&secret=APPSECRET&grant_type=client_credential`
- **请求参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| appid | string | 是 | 账号唯一凭证 |
| secret | string | 是 | 唯一凭证密钥 |
| grant_type | string | 是 | 填 client_credential |

- **返回参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| access_token | string | 获取到的凭证 |
| expires_in | number | 凭证有效时间（秒），目前为 7200 |

- **注意事项**：
  - Token 有效期 7200 秒（2小时），需缓存避免频繁请求
  - 必须在服务器端调用
  - 需要配置 IP 白名单
  - 不同应用类型的 Token 互相隔离

- **常见错误码**：
  - `-1`：系统繁忙，稍候再试
  - `40001`：AppSecret 错误或 access_token 无效
  - `40013`：不合法的 AppID
  - `40164`：调用 IP 不在白名单中
  - `40243`：AppSecret 已被冻结

---

## 素材管理接口

### 上传发表内容中的图片（正文图片）

- **接口英文名**：uploadImage
- **请求URL**：`POST https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=ACCESS_TOKEN`
- **请求参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| media | formdata | 是 | 图片文件 |

- **返回参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| url | string | 图片 URL（用于正文插入） |

- **注意事项**：
  - 图片不占用素材库 100,000 的数量限制
  - 仅支持 jpg/png 格式
  - 图片大小必须在 1MB 以下
  - 返回的 URL 可直接用于草稿正文的 img 标签

### 上传永久素材（封面图）

- **接口英文名**：addMaterial
- **请求URL**：`POST https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=ACCESS_TOKEN&type=image`
- **请求参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| media | formdata | 是 | 图片文件 |

- **返回参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| media_id | string | 永久素材 media_id（用作封面 thumb_media_id） |
| url | string | 图片 URL（仅图片类型返回） |

- **注意事项**：
  - 图片大小限制 10MB
  - 支持格式：bmp/png/jpeg/jpg/gif
  - 图片素材上限 100,000 个
  - URL 仅限腾讯系域名内使用

---

## 草稿箱接口

### 新增草稿

- **接口英文名**：draft_add
- **请求URL**：`POST https://api.weixin.qq.com/cgi-bin/draft/add?access_token=ACCESS_TOKEN`
- **请求体参数**：

```json
{
  "articles": [
    {
      "title": "标题（不超过32字）",
      "author": "作者（不超过16字）",
      "digest": "摘要（不超过128字）",
      "content": "正文HTML（不超过20000字符，<1MB）",
      "thumb_media_id": "封面图的永久media_id",
      "content_source_url": "原文链接（可选）",
      "need_open_comment": 0,
      "only_fans_can_comment": 0
    }
  ]
}
```

- **字段说明**：

| 字段 | 类型 | 必填 | 说明及限制 |
|------|------|------|-----------|
| title | string | 是 | 标题，不超过32字 |
| author | string | 否 | 作者，不超过16字 |
| digest | string | 否 | 摘要，不超过128字；未填则取正文前54字 |
| content | string | 是 | 正文HTML，不超过20000字符，小于1MB |
| thumb_media_id | string | 是 | 封面图的永久MediaID |
| content_source_url | string | 否 | 原文链接，不超过1KB |
| need_open_comment | number | 否 | 0不打开评论（默认），1打开 |
| only_fans_can_comment | number | 否 | 0所有人可评论（默认），1仅粉丝 |

- **返回参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| media_id | string | 草稿 media_id |

- **关键注意事项**：
  - 正文中图片 URL 必须来自 uploadimg 接口，外部 URL 会被过滤
  - 不要使用 Unicode 转义格式（\uXXXX）
  - 草稿发布后会从草稿箱移除
  - content 支持 HTML 标签，会去除 JS

### 获取草稿列表

- **请求URL**：`POST https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token=ACCESS_TOKEN`
- **请求体**：

```json
{
  "offset": 0,
  "count": 20,
  "no_content": 1
}
```

### 删除草稿

- **请求URL**：`POST https://api.weixin.qq.com/cgi-bin/draft/delete?access_token=ACCESS_TOKEN`
- **请求体**：`{"media_id": "MEDIA_ID"}`

---

## 发布接口

### 发布草稿

- **接口英文名**：freePublish_submit
- **请求URL**：`POST https://api.weixin.qq.com/cgi-bin/freepublish/submit?access_token=ACCESS_TOKEN`
- **请求体**：`{"media_id": "MEDIA_ID"}`
- **返回参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| publish_id | string | 发布任务ID |

- **注意**：发布是异步操作，需轮询查询发布状态

### 查询发布状态

- **请求URL**：`POST https://api.weixin.qq.com/cgi-bin/freepublish/get?access_token=ACCESS_TOKEN`
- **请求体**：`{"publish_id": "PUBLISH_ID"}`
