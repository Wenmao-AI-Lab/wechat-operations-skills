#!/usr/bin/env python3
"""
获取微信公众号 Access Token
从环境变量读取 APPID 和 APPSECRET，获取并输出 access_token。
支持缓存 token 到脚本同级目录，避免频繁请求。

用法:
    python get_token.py
    python get_token.py --json    # 输出 JSON 格式（含 expires_in）
"""

import argparse
import json
import sys

from utils import fetch_access_token, load_cached_token, save_token_cache


def parse_args():
    parser = argparse.ArgumentParser(description="获取微信公众号 Access Token")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    return parser.parse_args()


def main():
    args = parse_args()

    cached = load_cached_token()
    if cached:
        payload = cached
    else:
        access_token, expires_in = fetch_access_token()
        payload = save_token_cache(access_token, expires_in)

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    sys.stdout.write(payload["access_token"] + "\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
