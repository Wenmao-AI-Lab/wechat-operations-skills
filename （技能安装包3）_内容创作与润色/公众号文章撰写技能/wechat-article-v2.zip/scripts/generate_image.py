#!/usr/bin/env python3
"""
使用火山方舟豆包 Seedream 模型生成图片
调用 doubao-seedream-5-0-260128 模型，支持文生图

用法:
    python generate_image.py --prompt "描述文字" --output output.jpg
    python generate_image.py --prompt "描述文字" --output cover.jpg --type cover  # 封面图

环境变量:
    ARK_API_KEY: 火山方舟 API Key
"""

import sys
import os
import argparse
import json
import requests
import time

FIXED_SIZE = "3136x1344"


def get_api_key():
    """从环境变量获取 API Key"""
    api_key = os.getenv("ARK_API_KEY")
    if not api_key:
        print("ERROR: 环境变量 ARK_API_KEY 未设置", file=sys.stderr)
        print("请在火山方舟控制台获取 API Key: https://console.volcengine.com/ark", file=sys.stderr)
        sys.exit(1)
    return api_key


def generate_image(prompt, model="doubao-seedream-5-0-260128"):
    """
    调用火山方舟 API 生成图片
    
    Args:
        prompt: 文字描述
        model: 模型名称，默认 doubao-seedream-5-0-260128
    
    Returns:
        dict: 包含 image_url, width, height 等信息
    """
    api_key = get_api_key()
    
    # 火山方舟官方 Base URL
    base_url = "https://ark.cn-beijing.volces.com/api/v3/images/generations"
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    # 构建请求参数
    payload = {
        "model": model,
        "prompt": prompt,
        "size": FIXED_SIZE,
        "sequential_image_generation": "disabled",
        "stream": False,
        "response_format": "url",
        "watermark": False
    }
    
    try:
        response = requests.post(base_url, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        data = response.json()
        
        # 解析响应
        if "data" not in data or len(data["data"]) == 0:
            print(f"ERROR: API 返回数据异常：{data}", file=sys.stderr)
            return None
        
        image_data = data["data"][0]
        image_url = image_data.get("url")
        
        if not image_url:
            print(f"ERROR: 未获取到图片 URL: {data}", file=sys.stderr)
            return None
        
        # 提取尺寸信息（如果 API 返回）
        width = image_data.get("width", 0)
        height = image_data.get("height", 0)
        
        return {
            "url": image_url,
            "width": width,
            "height": height,
            "size": FIXED_SIZE
        }
        
    except requests.exceptions.RequestException as e:
        print(f"ERROR: API 请求失败：{e}", file=sys.stderr)
        if hasattr(e, 'response') and e.response is not None:
            print(f"响应内容：{e.response.text}", file=sys.stderr)
        return None


def download_image(url, output_path):
    """
    下载图片到本地
    
    Args:
        url: 图片 URL
        output_path: 保存路径
    
    Returns:
        bool: 是否成功
    """
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        with open(output_path, 'wb') as f:
            f.write(response.content)
        
        return True
        
    except requests.exceptions.RequestException as e:
        print(f"ERROR: 下载图片失败：{e}", file=sys.stderr)
        return False


def main():
    parser = argparse.ArgumentParser(description="使用火山方舟 Seedream 模型生成图片")
    parser.add_argument("--prompt", "-p", required=True, help="图片描述文字")
    parser.add_argument("--output", "-o", help="输出文件路径（可选，不提供则只打印 URL）")
    parser.add_argument("--type", "-t", choices=["cover", "content"], default="content",
                        help="图片用途：cover=封面图，content=正文配图（默认 content）")
    parser.add_argument("--model", "-m", default="doubao-seedream-5-0-260128",
                        help="模型名称（默认 doubao-seedream-5-0-260128）")
    
    args = parser.parse_args()
    
    # 调用 API 生成图片
    result = generate_image(args.prompt, model=args.model)
    
    if not result:
        print("ERROR: 图片生成失败", file=sys.stderr)
        sys.exit(1)
    
    print(f"\n[SUCCESS] 图片生成成功！")
    print(f"URL: {result['url']}")
    print(f"尺寸：{result['width']} x {result['height']}")
    
    # 如果指定了输出路径，下载图片
    if args.output:
        # 确保输出目录存在
        output_dir = os.path.dirname(args.output)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        print(f"\n正在下载图片到：{args.output}")
        
        # 重试 3 次
        for i in range(3):
            if download_image(result['url'], args.output):
                print(f"[SUCCESS] 图片已保存到：{args.output}")
                break
            else:
                if i < 2:
                    print(f"下载失败，重试 {i+2}/3...")
                    time.sleep(2)
                else:
                    print("ERROR: 下载图片失败，已达到最大重试次数", file=sys.stderr)
                    sys.exit(1)
    
    # 输出 JSON 结果（方便其他脚本解析）
    output = {
        "url": result['url'],
        "width": result['width'],
        "height": result['height'],
        "size": result['size'],
        "local_path": args.output if args.output and os.path.exists(args.output) else None
    }
    
    print(f"\n{json.dumps(output, ensure_ascii=False, indent=2)}")


if __name__ == "__main__":
    main()
