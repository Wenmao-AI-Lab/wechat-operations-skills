#!/usr/bin/env python3
"""
微信公众号文章排版脚本 - 研究院纪要风格
将 Markdown 格式的纯文本转换为格式化 HTML，应用接近机构公众号长文的排版样式。

风格特点：
- 主标题简洁直接
- 摘要使用浅灰色信息区
- 章节标题采用 01/02/03 编号样式
- 正文朴素克制，突出内容本身
- 支持 Markdown 表格渲染

用法:
    python format_article.py --input article.md --output article.html
    python format_article.py --input article.md --output article.html --title "文章标题"
"""

import sys
import re
import os
import argparse

# 导入工具模块
from utils import log_info, log_warning, log_error


STYLES = {
        "main_title": {
            "margin": "0 0 14px 0",
            "font_size": "22px",
            "font_weight": "800",
            "color": "#161616",
            "line_height": "1.3"
        },
        "container": {
            "padding": "8px 14px 20px 14px",
            "font_size": "16px",
            "color": "#555f6d",
            "line_height": "1.8",
            "letter_spacing": "0",
            "text_align": "left"
        },
        "paragraph": {
            "margin": "0 0 20px 0",
            "text_indent": "0"
        },
        "summary": {
            "margin": "4px 0 28px 0",
            "padding": "14px 16px",
            "background": "#f5f5f5"
        },
        "section_title": {
            "margin": "40px 0 22px 0",
            "number_size": "18px",
            "number_weight": "800",
            "number_color": "#1f49a8",
            "title_size": "18px",
            "title_weight": "800",
            "title_color": "#1f49a8",
            "highlight": "#dbeafe"
        },
        "subsection_title": {
            "margin": "20px 0 12px 0",
            "font_size": "17px",
            "font_weight": "700",
            "color": "#1f49a8"
        },
        "highlight_box": {
            "margin": "18px 0 22px 0",
            "padding": "0 0 0 12px",
            "font_size": "16px",
            "line_height": "1.8",
            "font_weight": "600"
        },
        "divider": {
            "margin": "26px 0",
            "height": "1px",
            "background": "#e5e7eb"
        },
        "data_box": {
            "margin": "18px 0 22px 0",
            "padding": "0 0 0 12px",
            "border_left": "4px solid #1f49a8"
        },
        "table": {
            "margin": "24px 0",
            "border_collapse": "collapse",
            "width": "100%",
            "font_size": "14px",
            "th_background": "#f2f6ff",
            "th_color": "#1f49a8",
            "td_border": "1px solid #e5e7eb",
            "tr_even_background": "#fafafa"
        },
        "conclusion": {
            "margin": "30px 0 0 0"
        }
}


def get_magazine_styles():
    """返回适合研究院纪要风格的排版配置。"""
    return STYLES


def format_main_title(title):
    """格式化主标题（简洁机构风格）"""
    styles = get_magazine_styles()["main_title"]

    return f'''<section style="margin: {styles['margin']};">
    <h1 style="
        margin: 0;
        font-size: {styles['font_size']};
        font-weight: {styles['font_weight']};
        color: {styles['color']};
        line-height: {styles['line_height']};
        letter-spacing: 0;
    ">{title}</h1>
</section>'''


def format_container(content):
    """包裹容器样式"""
    styles = get_magazine_styles()["container"]
    style_str = f'padding: {styles["padding"]}; font-size: {styles["font_size"]}; color: {styles["color"]}; line-height: {styles["line_height"]}; letter-spacing: {styles["letter_spacing"]}; text-align: {styles["text_align"]};'
    return f'<section style="{style_str}">\n{content}\n</section>'


def format_paragraph(text):
    """格式化正文段落（纪要风格正文）"""
    styles = get_magazine_styles()["paragraph"]
    style_str = f'margin: {styles["margin"]}; text-indent: {styles["text_indent"]};'

    return f'<p style="{style_str}">{text}</p>'


def format_summary_block(paragraphs):
    """格式化摘要灰色区域。"""
    styles = get_magazine_styles()["summary"]
    html_parts = []
    for paragraph in paragraphs:
        html_parts.append(f'<p style="margin: 0 0 12px 0; color: #5b6470;">{paragraph}</p>')

    if html_parts:
        html_parts[-1] = html_parts[-1].replace('margin: 0 0 12px 0; color: #5b6470;', 'margin: 0; color: #5b6470;')

    return f'''<section style="
    margin: {styles['margin']};
    padding: {styles['padding']};
    background: {styles['background']};
">
    {''.join(html_parts)}
</section>'''


def format_section_title(title, index):
    """格式化段落标题（## 开头的行 - 编号章节风格）"""
    styles = get_magazine_styles()["section_title"]
    number = f"{index:02d}"

    return f'''<section style="
    margin: {styles['margin']};
    text-align: center;
">
    <p style="
        margin: 0;
        line-height: 1;
    ">
        <strong style="
            font-weight: {styles['number_weight']};
        ">
            <span style="
                font-size: {styles['number_size']};
                color: {styles['number_color']};
                letter-spacing: 1px;
            ">{number}</span>
        </strong>
    </p>
    <h2 style="
        display: inline;
        margin: 10px 0 0 0;
        padding: 0 6px 2px 6px;
        font-size: {styles['title_size']};
        font-weight: {styles['title_weight']};
        color: {styles['title_color']};
        line-height: 1.5;
        background: linear-gradient(transparent 78%, {styles['highlight']} 78%);
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
    ">{title}</h2>
</section>'''


def normalize_section_title(raw_title):
    """标准化章节标题，兼容手写编号前缀。"""
    # 兼容历史写法：## 01 / 标题（避免与自动编号重复）
    return re.sub(r'^\d{1,2}\s*/\s*', '', raw_title).strip()


def format_subsection_title(title):
    """格式化小标题（### 开头的行 - 蓝色小节标题）"""
    styles = get_magazine_styles()["subsection_title"]

    return f'''<h3 style="
        margin: {styles['margin']};
        font-size: {styles['font_size']};
        font-weight: {styles['font_weight']};
        color: {styles['color']};
        line-height: 1.7;
    ">{title}</h3>'''


def format_highlight_box(text, icon="💡", box_type="default"):
    """格式化强调色块（弱化组件感，接近机构文章重点句）"""
    styles = get_magazine_styles()["highlight_box"]
    text_colors = {
        "default": "#4b5563",
        "warning": "#8a5a18",
        "data": "#1f49a8",
        "insight": "#1f49a8"
    }
    border_colors = {
        "default": "#d1d5db",
        "warning": "#f2c078",
        "data": "#9cc4ff",
        "insight": "#9cc4ff"
    }
    text_color = text_colors.get(box_type, text_colors["default"])
    border_color = border_colors.get(box_type, border_colors["default"])

    return f'''<section style="
    margin: {styles['margin']};
    padding: {styles['padding']};
    border-left: 4px solid {border_color};
">
    <p style="
        margin: 0;
        font-size: {styles['font_size']};
        line-height: {styles['line_height']};
        color: {text_color};
        font-weight: {styles['font_weight']};
    ">
        {text}
    </p>
</section>'''


def format_data_box(text):
    """格式化数据重点段"""
    styles = get_magazine_styles()["data_box"]
    
    # 提取数字并放大
    text_with_large_numbers = re.sub(
        r'(几十万|几百万|数千|数亿|\d+[%％]?)',
        r'<strong style="font-size: 16px; color: #c0392b;">\1</strong>',
        text
    )
    
    html = f'''<section style="
    margin: {styles['margin']};
    padding: {styles['padding']};
    border-left: {styles['border_left']};
">
    <p style="
        margin: 0;
        font-size: 16px;
        line-height: 1.8;
        color: #4b5563;
        font-weight: 600;
    ">
        <span style="
            font-size: 16px;
            font-weight: 800;
            color: #1f49a8;
            display: inline-block;
            margin-right: 8px;
        ">📊 关键数据</span>
        {text_with_large_numbers}
    </p>
</section>'''
    
    return html


def format_divider():
    """格式化分割线（弱化处理）"""
    styles = get_magazine_styles()["divider"]
    style_str = f'margin: {styles["margin"]}; height: {styles["height"]}; background: {styles["background"]};'
    return f'<div style="{style_str}"></div>'


def format_conclusion(text):
    """格式化结尾段落。"""
    return format_paragraph(text)


def format_table(markdown_table):
    """格式化 Markdown 表格"""
    styles = get_magazine_styles()["table"]
    
    lines = markdown_table.strip().split('\n')
    if len(lines) < 2:
        return ''
    
    # 解析表头
    header_line = lines[0]
    separator_line = lines[1]
    
    # 提取表头单元格（去掉首尾的 |）
    headers = [cell.strip() for cell in header_line.strip('|').split('|')]
    
    # 解析对齐方式（从分隔行）
    alignments = []
    separator_cells = separator_line.strip('|').split('|')
    for cell in separator_cells:
        cell = cell.strip()
        if cell.startswith(':') and cell.endswith(':'):
            alignments.append('center')
        elif cell.endswith(':'):
            alignments.append('right')
        else:
            alignments.append('left')
    
    # 解析数据行
    data_rows = []
    for line in lines[2:]:
        if line.strip() and '|' in line:
            cells = [cell.strip() for cell in line.strip('|').split('|')]
            data_rows.append(cells)
    
    # 生成 HTML 表格
    html = f'''<table style="
    margin: {styles['margin']};
    border-collapse: {styles['border_collapse']};
    width: {styles['width']};
    font-size: {styles['font_size']};
">
    <thead>
        <tr style="
            background: {styles['th_background']};
        ">
'''
    
    # 添加表头
    for i, header in enumerate(headers):
        align = alignments[i] if i < len(alignments) else 'left'
        html += f'''            <th style="
                padding: 10px 12px;
                color: {styles['th_color']};
                font-weight: 700;
                text-align: {align};
                border: none;
            ">{header}</th>
'''
    
    html += '''        </tr>
    </thead>
    <tbody>
'''
    
    # 添加数据行
    for row_idx, row in enumerate(data_rows):
        bg_style = styles['tr_even_background'] if (row_idx + 1) % 2 == 0 else 'transparent'
        html += f'''        <tr style="background: {bg_style};">
'''
        for i, cell in enumerate(row):
            align = alignments[i] if i < len(alignments) else 'left'
            # 处理单元格内的加粗和斜体
            cell_content = process_inline_styles(cell)
            html += f'''            <td style="
                padding: 8px 10px;
                border: {styles['td_border']};
                text-align: {align};
            ">{cell_content}</td>
'''
        html += '''        </tr>
'''
    
    html += '''    </tbody>
</table>'''
    
    return html


def process_markdown(content):
    """
    处理 Markdown 内容，转换为 HTML（研究院纪要风格）
    支持：
    - # 主标题（忽略，因为标题已单独传入）
    - [SUMMARY] ... [/SUMMARY] 摘要灰色区域
    - ## 段落标题
    - ### 小标题
    - **加粗**
    - [IMG:描述] 图片占位符
    - 💡 强调
    - 📊 数据
    - ⚠️ 警告
    - Markdown 表格
    - 普通段落
    """
    lines = content.split('\n')
    html_parts = []
    current_paragraph = []
    section_index = 0

    def flush_paragraph():
        if not current_paragraph:
            return
        para_text = " ".join(current_paragraph)
        html_parts.append(format_paragraph(para_text))
        current_paragraph.clear()
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        if not line:
            # 空行，结束当前段落
            flush_paragraph()
            i += 1
            continue
        
        # 检测 Markdown 表格（以 | 开头且包含 | 的行）
        if line.startswith('|') and '|' in line[1:]:
            # 收集表格的所有行
            table_lines = [line]
            i += 1
            while i < len(lines):
                next_line = lines[i].strip()
                if next_line.startswith('|') and '|' in next_line[1:]:
                    table_lines.append(next_line)
                    i += 1
                else:
                    break
            
            # 结束当前段落
            flush_paragraph()
            
            # 格式化表格
            markdown_table = '\n'.join(table_lines)
            html_parts.append(format_table(markdown_table))
            continue

        # 处理摘要块 [SUMMARY] ... [/SUMMARY]
        if line == '[SUMMARY]':
            flush_paragraph()
            i += 1
            summary_lines = []
            current_summary = []

            while i < len(lines):
                summary_line = lines[i].strip()
                if summary_line == '[/SUMMARY]':
                    break
                if not summary_line:
                    if current_summary:
                        summary_lines.append(' '.join(current_summary))
                        current_summary = []
                else:
                    current_summary.append(summary_line)
                i += 1

            if current_summary:
                summary_lines.append(' '.join(current_summary))

            if summary_lines:
                html_parts.append(format_summary_block(summary_lines))

            if i >= len(lines) or lines[i].strip() != '[/SUMMARY]':
                log_warning("摘要块缺少 [/SUMMARY] 结束标记")
                continue

            i += 1
            continue
        
        # 处理 # 主标题（忽略，因为标题已单独传入）
        if line.startswith('# ') and not line.startswith('## '):
            log_warning("忽略一级标题（# 开头），标题应单独传入")
            i += 1
            continue
        
        # 处理 ## 段落标题
        if line.startswith('## '):
            flush_paragraph()
            title = normalize_section_title(line[3:].strip())
            section_index += 1
            html_parts.append(format_section_title(title, section_index))
            i += 1
            continue
        
        # 处理 ### 小标题（使用独立的样式）
        if line.startswith('### '):
            flush_paragraph()
            title = line[4:].strip()
            html_parts.append(format_subsection_title(title))
            i += 1
            continue
        
        # 处理强调色块（💡 开头）
        if line.startswith('💡'):
            flush_paragraph()
            text = line[1:].strip()
            html_parts.append(format_highlight_box(text, "💡", "insight"))
            i += 1
            continue
        
        # 处理 📊 数据/事实
        if line.startswith('📊'):
            flush_paragraph()
            text = line[2:].strip()
            html_parts.append(format_data_box(text))
            i += 1
            continue
        
        # 处理 ⚠️ 注意事项
        if line.startswith('⚠️'):
            flush_paragraph()
            text = line[2:].strip()
            html_parts.append(format_highlight_box(text, "⚠️", "warning"))
            i += 1
            continue
        
        # 处理图片占位符 [IMG:描述]
        if '[IMG:' in line:
            flush_paragraph()
            
            # 提取图片描述
            matches = re.findall(r'\[IMG:([^\]]+)\]', line)
            for desc in matches:
                # 暂时保留占位符，后续由人工或其他脚本替换为真实图片 URL
                html_parts.append(f'<!-- IMG_PLACEHOLDER: {desc} -->')
            i += 1
            continue
        
        # 处理分割线（---）
        if line == '---':
            flush_paragraph()
            html_parts.append(format_divider())
            i += 1
            continue
        
        # 普通段落文字
        current_paragraph.append(line)
        i += 1
    
    # 处理剩余的段落
    if current_paragraph:
        para_text = ' '.join(current_paragraph)
        # 判断是否是结尾
        if any(kw in para_text for kw in ["总结", "结尾", "最后", "✦"]):
            html_parts.append(format_conclusion(para_text))
        else:
            html_parts.append(format_paragraph(para_text))
    
    return '\n'.join(html_parts)


def process_inline_styles(content):
    """处理行内样式，如 **加粗**"""
    # 处理 **加粗**
    content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
    
    # 处理 *斜体*
    content = re.sub(r'\*(.+?)\*', r'<em>\1</em>', content)
    
    return content


def format_article(input_path, output_path=None, title=None):
    """主函数：读取 Markdown，输出格式化 HTML"""
    
    # 读取输入文件
    log_info(f"读取 Markdown 文件：{input_path}")
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except OSError as e:
        log_error(f"读取文件失败：{e}")
        sys.exit(1)
    
    # 先处理行内样式
    log_info("处理行内样式...")
    content = process_inline_styles(content)
    
    # 转换为 HTML
    log_info("应用研究院纪要风格排版...")
    html_body = process_markdown(content)
    
    # 如果有标题，添加主标题样式
    if title:
        log_info(f"添加主标题：{title}")
        html_full = format_main_title(title) + '\n\n' + format_container(html_body)
    else:
        html_full = format_container(html_body)
    
    # 输出
    if output_path:
        log_info(f"写入 HTML 文件：{output_path}")
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_full)
            log_info(f"OK 研究院纪要风格排版完成：{output_path}")
        except OSError as e:
            log_error(f"写入文件失败：{e}")
            sys.exit(1)
    else:
        print(html_full)
    
    return html_full


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="微信公众号文章排版脚本 - 研究院纪要风格")
    parser.add_argument("--input", "-i", type=str, required=True, help="输入 Markdown 文件路径")
    parser.add_argument("--output", "-o", type=str, help="输出 HTML 文件路径（可选，不提供则打印到终端）")
    parser.add_argument("--title", "-t", type=str, help="文章标题（用于生成主标题样式）")
    
    return parser.parse_args()


def main():
    args = parse_args()
    
    input_path = args.input
    output_path = args.output
    title = args.title
    
    if not os.path.exists(input_path):
        log_error(f"文件不存在：{input_path}")
        sys.exit(1)
    
    format_article(input_path, output_path, title)


if __name__ == "__main__":
    main()
