#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WeChat Sender - Windows 微信自动发送工具核心类

支持功能:
- 发送文字消息
- 发送图片
- 发送文件

使用示例:
    from wechat_sender import WeChatSender

    sender = WeChatSender()
    sender.send_message("YHD", "你好")
    sender.send_image("YHD", "C:/path/to/image.jpg")
    sender.send_file("YHD", "C:/path/to/file.xlsx")
"""

import pyautogui
import pyperclip
import ctypes
import time
import sys
import os
import io
from ctypes import wintypes

if sys.platform == 'win32':
    import win32clipboard
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

# 注意:GUI 自动化时 FAILSAFE 会被误触发(如窗口贴近屏幕边缘),
# 导致脚本随机中断。此处关闭以确保操作稳定性,用户可随时手动关闭脚本。
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.5


class WeChatSender:
    """微信自动发送工具类"""

    def __init__(self, verbose: bool = True):
        """
        初始化微信发送器

        Args:
            verbose: 是否打印详细日志
        """
        self.verbose = verbose
        self.user32 = ctypes.windll.user32
        self.hwnd = None
        self.win_rect = None

    def log(self, msg: str):
        """打印日志"""
        if self.verbose:
            print(f"[WeChatSender] {msg}")

    def find_wechat_window(self) -> bool:
        """
        查找微信主窗口

        Returns:
            bool: 是否找到窗口
        """
        main_hwnds = []
        child_hwnds = []

        def enum_callback(hwnd, lParam):
            length = self.user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buffer = ctypes.create_unicode_buffer(length + 1)
                self.user32.GetWindowTextW(hwnd, buffer, length + 1)
                title = buffer.value
                if '微信' in title or 'Weixin' in title:
                    class_buffer = ctypes.create_unicode_buffer(256)
                    self.user32.GetClassNameW(hwnd, class_buffer, 256)
                    class_name = class_buffer.value
                    if class_name.startswith('Qt5'):
                        main_hwnds.append(hwnd)
                    elif class_name.startswith('Chrome_WidgetWin'):
                        child_hwnds.append(hwnd)
            return True

        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        self.user32.EnumWindows(EnumWindowsProc(enum_callback), 0)

        # 关闭子窗口
        for child_hwnd in child_hwnds:
            self.user32.PostMessageW(child_hwnd, 0x0010, 0, 0)  # WM_CLOSE
            time.sleep(0.5)

        if child_hwnds:
            time.sleep(1)

        if not main_hwnds:
            self.log("未找到微信主窗口")
            return False

        # --- 第一步：先恢复所有候选窗口（最小化的窗口 GetWindowRect 返回负坐标，
        #     不恢复就按坐标筛选会把最小化窗口误判为隐藏窗口而排除）
        restored_any = False
        for h in main_hwnds:
            if self.user32.IsIconic(h):
                self.user32.ShowWindow(h, 9)  # SW_RESTORE
                restored_any = True
        if restored_any:
            time.sleep(0.8)

        # --- 第二步：按恢复后的坐标筛选可见窗口
        valid_hwnds = []
        for h in main_hwnds:
            rect = wintypes.RECT()
            self.user32.GetWindowRect(h, ctypes.byref(rect))
            # 检查窗口是否可见且坐标为正（在屏幕内）
            if rect.left >= 0 and rect.top >= 0:
                area = (rect.right - rect.left) * (rect.bottom - rect.top)
                valid_hwnds.append((h, rect, area))
        
        if valid_hwnds:
            # 优先选择面积最大的可见窗口
            best = max(valid_hwnds, key=lambda x: x[2])
            self.hwnd = best[0]
            rect = best[1]
        else:
            # 兜底：使用第一个
            self.hwnd = main_hwnds[0]
            rect = wintypes.RECT()
            self.user32.GetWindowRect(self.hwnd, ctypes.byref(rect))

        # 获取窗口位置
        self.log(f"找到微信窗口: hwnd={self.hwnd}, pos=({rect.left},{rect.top},{rect.right},{rect.bottom}), size=({rect.right-rect.left}x{rect.bottom-rect.top})")
        return True

    def activate_window(self) -> bool:
        """
        激活微信窗口（恢复最小化并激活）

        策略：
        1. 恢复最小化窗口
        2. 用 SetForegroundWindow + keybd_event(Alt) 尝试抢焦点
        3. 等待 UI 就绪
        4. 最后点击窗口中心，彻底确保焦点在微信

        注意：当浏览器持有前台时 SetForegroundWindow 可能失败（Windows 限制），
        此时第 4 步的点击仍可将焦点转移到微信，搜索和发送仍可继续。

        Returns:
            bool: 是否成功激活
        """
        if not self.hwnd:
            self.log("请先调用 find_wechat_window()")
            return False

        # 窗口已在 find_wechat_window 中恢复，此处再次确认兜底
        if self.user32.IsIconic(self.hwnd):
            self.user32.ShowWindow(self.hwnd, 9)  # SW_RESTORE
            time.sleep(1)
            self.log("已恢复最小化窗口（兜底恢复）")

        # 获取窗口位置（恢复后才是可见坐标）
        rect = wintypes.RECT()
        self.user32.GetWindowRect(self.hwnd, ctypes.byref(rect))
        self.win_rect = (rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top)

        # 尝试 SetForegroundWindow + Alt 模拟
        foreground_hwnd = self.user32.GetForegroundWindow()
        foreground_thread = self.user32.GetWindowThreadProcessId(foreground_hwnd, None)
        wechat_thread = self.user32.GetWindowThreadProcessId(self.hwnd, None)

        attached = False
        if foreground_thread != wechat_thread:
            self.user32.AttachThreadInput(foreground_thread, wechat_thread, True)
            attached = True

        self.user32.ShowWindow(self.hwnd, 9)
        time.sleep(0.3)
        self.user32.BringWindowToTop(self.hwnd)
        time.sleep(0.3)
        self.user32.keybd_event(0x12, 0, 0, 0)  # Alt down
        self.user32.keybd_event(0x12, 0, 2, 0)  # Alt up
        time.sleep(0.1)
        self.user32.SetForegroundWindow(self.hwnd)
        time.sleep(0.5)
        if attached:
            self.user32.AttachThreadInput(foreground_thread, wechat_thread, False)
        time.sleep(1.5)

        # 验证切换结果（不阻塞，仅记录日志）
        new_fg = self.user32.GetForegroundWindow()
        if new_fg != self.hwnd:
            self.log(f"提示：前台切换可能未成功 (fg={new_fg}, wechat={self.hwnd})，点击窗口中心补救")
        else:
            self.log(f"窗口位置: ({rect.left}, {rect.top}, {rect.right}, {rect.bottom})")

        # === 第四步：点击窗口中心，彻底确保焦点在微信 ===
        # 即使 SetForegroundWindow 失败，点击也能将焦点转移到微信
        center_x = (rect.left + rect.right) // 2
        center_y = (rect.top + rect.bottom) // 2
        pyautogui.click(center_x, center_y)
        time.sleep(1.5)

        self.log(f"窗口位置: ({rect.left}, {rect.top}, {rect.right}, {rect.bottom})")
        return True

    def search_contact(self, contact_name: str) -> bool:
        """
        搜索并进入联系人聊天窗口

        Args:
            contact_name: 联系人名称

        Returns:
            bool: 是否成功
        """
        if not self.win_rect:
            self.log("请先调用 activate_window()")
            return False

        win_left, win_top, win_width, win_height = self.win_rect
        self.log(f"搜索流程开始: win=({win_left},{win_top},{win_width},{win_height})")

        # 点击左侧聊天列表区域
        self.log(f"点击左侧聊天列表: ({win_left + 80}, {win_top + 150})")
        pyautogui.click(win_left + 80, win_top + 150)
        time.sleep(1)

        # Ctrl+F 打开搜索
        self.log("按下 Ctrl+F 打开搜索框")
        pyautogui.hotkey('ctrl', 'f')
        time.sleep(2)

        # 直接输入联系人名称（Ctrl+F 后搜索框已聚焦，无需点击搜索框——2026-05-13修复）
        self.log(f"直接输入联系人名称: {contact_name}")
        pyautogui.typewrite(contact_name, interval=0.1)
        time.sleep(1)

        # 第一次回车:确认选择联系人
        self.log("按第一次回车确认选择联系人")
        pyautogui.press('enter')
        time.sleep(2)

        # 第二次回车:进入聊天窗口
        self.log("按第二次回车进入聊天窗口")
        pyautogui.press('enter')
        time.sleep(2)

        # 点击输入框区域
        input_x = win_left + win_width // 2
        input_y = win_top + win_height - 100
        pyautogui.click(input_x, input_y)
        time.sleep(1.5)

        # Ctrl+A 全选输入框内容（搜索后输入框可能残留搜索词，如"YHD"）
        self.log("Ctrl+A 全选输入框内容")
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.5)

        # Delete 强制清空（2026-05-10 修复：Ctrl+A 单独使用有时选不全残留文字）
        self.log("Delete 清空残留内容")
        pyautogui.press('delete')
        time.sleep(0.5)

        # 再 Ctrl+A 一次（双保险）
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.5)

        self.log(f"已进入联系人 '{contact_name}' 的聊天窗口")
        return True

    def send_message(self, contact_name: str, message: str, max_retries: int = 2) -> bool:
        """
        发送文字消息(带自动重试)

        Args:
            contact_name: 联系人名称
            message: 消息内容
            max_retries: 最大重试次数,默认 2 次

        Returns:
            bool: 是否成功
        """
        self.log(f"准备发送消息给 '{contact_name}': {message[:50]}...")

        for attempt in range(1, max_retries + 1):
            if not self.find_wechat_window():
                return False

            if not self.activate_window():
                if attempt < max_retries:
                    self.log(f"前台切换失败,等待 2 秒后重试 ({attempt}/{max_retries})...")
                    time.sleep(2)
                    continue
                return False

            if not self.search_contact(contact_name):
                return False

            # 二次点击输入框确保焦点,窗口就绪后再发送
            win_left, win_top, win_width, win_height = self.win_rect
            input_x = win_left + win_width // 2
            input_y = win_top + win_height - 100
            pyautogui.click(input_x, input_y)
            time.sleep(0.5)
            pyautogui.click(input_x, input_y)
            time.sleep(0.5)
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.3)

            # Delete 强制清空（2026-05-10 修复）
            pyautogui.press('delete')
            time.sleep(0.3)

            # 发送消息
            pyperclip.copy(message)
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(1)
            pyautogui.press('enter')
            time.sleep(1)

            self.log("消息发送完成")
            return True

        return False

    def send_image(self, contact_name: str, image_path: str, max_retries: int = 2) -> bool:
        """
        发送图片(带自动重试)

        Args:
            contact_name: 联系人名称
            image_path: 图片路径
            max_retries: 最大重试次数,默认 2 次

        Returns:
            bool: 是否成功
        """
        self.log(f"准备发送图片给 '{contact_name}': {image_path}")

        if not Path(image_path).exists():
            self.log(f"图片不存在: {image_path}")
            return False

        for attempt in range(1, max_retries + 1):
            if not self.find_wechat_window():
                return False

            if not self.activate_window():
                if attempt < max_retries:
                    self.log(f"前台切换失败,等待 2 秒后重试 ({attempt}/{max_retries})...")
                    time.sleep(2)
                    continue
                return False

            if not self.search_contact(contact_name):
                return False

            # === 以下为发送逻辑,在循环内 ===
            # 将图片转换为 BMP/DIB 格式并复制到剪贴板
            import win32clipboard
            import win32con
            from PIL import Image

            img = Image.open(image_path).convert('RGB')
            buf = io.BytesIO()
            img.save(buf, 'BMP')
            bmp_data = buf.getvalue()[14:]  # 去掉 BMP 文件头

            win32clipboard.OpenClipboard()
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardData(win32con.CF_DIB, bmp_data)
            win32clipboard.CloseClipboard()

            time.sleep(0.5)

            # 点击输入框区域,确保焦点在输入框(2026-04-29 修复)
            win_left, win_top, win_width, win_height = self.win_rect
            input_x = win_left + win_width // 2
            input_y = win_top + win_height - 100

            # 第一次点击
            pyautogui.click(input_x, input_y)
            time.sleep(0.5)

            # 第二次点击 - 确保输入框真正聚焦,窗口 UI 完全就绪
            pyautogui.click(input_x, input_y)
            time.sleep(0.5)

            # Ctrl+A 全选输入框内容(搜索后输入框可能残留搜索词,如YHD)
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.3)

            # Delete 强制清空（2026-05-10 修复）
            pyautogui.press('delete')
            time.sleep(0.3)

            # 再 Ctrl+A 一次（双保险）
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.3)

            # 粘贴并发送
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(2)
            pyautogui.press('enter')
            time.sleep(1)

            self.log("图片发送完成")
            return True

        return False

    def send_file(self, contact_name: str, file_path: str, max_retries: int = 2) -> bool:
        """
        发送文件(带自动重试)

        Args:
            contact_name: 联系人名称
            file_path: 文件路径
            max_retries: 最大重试次数,默认 2 次

        Returns:
            bool: 是否成功
        """
        self.log(f"准备发送文件给 '{contact_name}': {file_path}")

        if not Path(file_path).exists():
            self.log(f"文件不存在: {file_path}")
            return False

        for attempt in range(1, max_retries + 1):
            if not self.find_wechat_window():
                return False

            if not self.activate_window():
                if attempt < max_retries:
                    self.log(f"前台切换失败,等待 2 秒后重试 ({attempt}/{max_retries})...")
                    time.sleep(2)
                    continue
                return False

            if not self.search_contact(contact_name):
                return False

            # === 以下为发送逻辑,在循环内 ===
            # 使用 win32clipboard 将文件路径以 CF_HDROP 格式写入剪贴板
            abs_path = os.path.abspath(file_path)
            path_bytes = (abs_path + '\0').encode('utf-16-le')

            class DROPFILES(ctypes.Structure):
                _fields_ = [
                    ('pFiles', ctypes.c_uint32),   # 文件列表偏移
                    ('pt_x',   ctypes.c_int32),
                    ('pt_y',   ctypes.c_int32),
                    ('fNC',    ctypes.c_int32),
                    ('fWide',  ctypes.c_bool),
                    ]

            df = DROPFILES()
            df.pFiles = ctypes.sizeof(DROPFILES)
            df.fWide = True

            # 分配内存,复制 DROPFILES 头 + 路径 + 双\0结尾
            buf_len = ctypes.sizeof(df) + len(path_bytes) + 2
            GMEM_MOVEABLE = 0x0002
            h_mem = ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVEABLE, buf_len)
            p_mem = ctypes.windll.kernel32.GlobalLock(h_mem)
            ctypes.memmove(p_mem, ctypes.addressof(df), ctypes.sizeof(df))
            ctypes.memmove(p_mem + ctypes.sizeof(df), path_bytes, len(path_bytes))
            ctypes.windll.kernel32.GlobalUnlock(h_mem)

            win32clipboard.OpenClipboard()
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardData(win32clipboard.CF_HDROP, h_mem)
            win32clipboard.CloseClipboard()
            time.sleep(1)

            # 二次点击输入框确保焦点
            win_left, win_top, win_width, win_height = self.win_rect
            input_x = win_left + win_width // 2
            input_y = win_top + win_height - 100
            pyautogui.click(input_x, input_y)
            time.sleep(0.5)
            pyautogui.click(input_x, input_y)
            time.sleep(0.5)
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.3)

            # Delete 强制清空（2026-05-10 修复）
            pyautogui.press('delete')
            time.sleep(0.3)

            # 再 Ctrl+A 一次（双保险）
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.3)

            # 粘贴并发送
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(3)
            pyautogui.press('enter')
            time.sleep(1)

            self.log("文件发送完成")
            return True

        return False


def main():
    """命令行入口"""
    import argparse

    parser = argparse.ArgumentParser(description='微信自动发送工具')
    parser.add_argument('--contact', required=True, help='联系人名称')
    parser.add_argument('--message', help='消息内容')
    parser.add_argument('--image', help='图片路径')
    parser.add_argument('--file', help='文件路径')

    args = parser.parse_args()

    sender = WeChatSender()

    if args.message:
        sender.send_message(args.contact, args.message)
    elif args.image:
        sender.send_image(args.contact, args.image)
    elif args.file:
        sender.send_file(args.contact, args.file)
    else:
        print("请指定 --message, --image 或 --file")


if __name__ == '__main__':
    main()