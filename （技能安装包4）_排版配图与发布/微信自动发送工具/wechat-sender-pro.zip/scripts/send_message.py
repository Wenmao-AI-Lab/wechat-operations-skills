#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
发送文字消息脚本

用法:
    python send_message.py --contact "联系人名字" --message "消息内容"
"""

import argparse
import sys

# 添加脚本目录到路径
sys.path.insert(0, __file__.rsplit('\\', 1)[0])

from wechat_sender import WeChatSender


def main():
    parser = argparse.ArgumentParser(description='发送微信文字消息')
    parser.add_argument('--contact', required=True, help='联系人名称')
    parser.add_argument('--message', required=True, help='消息内容')
    parser.add_argument('--quiet', action='store_true', help='静默模式')
    
    args = parser.parse_args()
    
    sender = WeChatSender(verbose=not args.quiet)
    success = sender.send_message(args.contact, args.message)
    
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
