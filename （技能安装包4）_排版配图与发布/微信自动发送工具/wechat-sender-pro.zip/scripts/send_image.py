#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
发送图片脚本

用法:
    python send_image.py --contact "联系人名字" --image "图片路径"
"""

import argparse
import sys

sys.path.insert(0, __file__.rsplit('\\', 1)[0])

from wechat_sender import WeChatSender


def main():
    parser = argparse.ArgumentParser(description='发送微信图片')
    parser.add_argument('--contact', required=True, help='联系人名称')
    parser.add_argument('--image', required=True, help='图片路径')
    parser.add_argument('--quiet', action='store_true', help='静默模式')
    
    args = parser.parse_args()
    
    sender = WeChatSender(verbose=not args.quiet)
    success = sender.send_image(args.contact, args.image)
    
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
