#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量搜索并发送文件 - wechat-sender 辅助脚本

集成文件搜索 + 结果展示 + 用户确认 + 微信发送。

用法：
    python batch_send.py --keyword "报价单" --contact "YHD"
    python batch_send.py --keyword "日报" --dirs "D:/" --contact "YHD"
    python batch_send.py --keyword "报价单" --contact "YHD" --depth 4
    python batch_send.py --keyword "报价单" --contact "YHD" --ext xlsx
"""

import sys
import os
import re
import json
import argparse
import subprocess
from pathlib import Path
from datetime import datetime
from collections import defaultdict

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

# ── 内嵌 find_file.py 的搜索逻辑 ────────────────────────────────────────

DEFAULT_SEARCH_DIRS = [
    os.path.expanduser('~/Desktop'),
    os.path.expanduser('~/Downloads'),
    os.path.expanduser('~/.qclaw/workspace'),
]

MAX_RESULTS = 100

def _is_temp_file(name: str) -> bool:
    if name.startswith('~$') or name.startswith('._') or name.startswith('.~'):
        return True
    return False

def _dedup_name(name: str):
    base = name
    is_dup = False
    m = re.search(r'\s*\(\d+\)(\.[^.]+)$', base)
    if m:
        base = base[:m.start()] + m.group(1)
        is_dup = True
    m = re.search(r'[-_]副本|[-_]copy', base, re.IGNORECASE)
    if m:
        base = base[:m.start()] + base[m.end():]
        is_dup = True
    return base.strip(), is_dup

def _friendly_dir(rel_path: str) -> str:
    parts = Path(rel_path).parts
    if len(parts) == 1:
        return parts[0]
    if len(parts) == 2:
        return parts[1]
    return f'{parts[-2]}/{parts[-1]}'

def search_files(name, search_dirs=None, ext=None, depth=3, limit=MAX_RESULTS):
    if search_dirs is None:
        search_dirs = DEFAULT_SEARCH_DIRS

    name_lower = name.lower()
    ext_lower = ext.lower().lstrip('.') if ext else None
    results = []
    seen_names = set()

    for search_dir in search_dirs:
        sp = Path(search_dir)
        if not sp.is_dir():
            continue
        try:
            for fp in sp.rglob('*'):
                if not fp.is_file():
                    continue
                try:
                    rel = fp.relative_to(sp)
                    if len(rel.parts) > depth:
                        continue
                except ValueError:
                    continue

                fname = fp.name
                fname_lower = fname.lower()
                if ext_lower and not fname_lower.endswith(f'.{ext_lower}'):
                    continue
                if name_lower not in fname_lower:
                    continue
                if _is_temp_file(fname):
                    continue

                norm_name, is_dup = _dedup_name(fname)
                if is_dup and norm_name in seen_names:
                    continue
                seen_names.add(norm_name)

                stat = fp.stat()
                rel_path = fp.relative_to(sp)
                rel_str = str(rel_path).replace('\\', '/')
                parent_rel = str(rel_path.parent).replace('\\', '/')

                results.append({
                    'name':       fname,
                    'path':       str(fp).replace('\\', '/'),
                    'size_kb':    round(stat.st_size / 1024, 1),
                    'modified':   datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
                    'dir':        str(fp.parent).replace('\\', '/'),
                    'rel':        rel_str,
                    'parent_rel': parent_rel,
                    '_mtime':     stat.st_mtime,
                })
                if len(results) >= limit:
                    break
        except PermissionError:
            continue

    results.sort(key=lambda x: x['_mtime'], reverse=True)
    for i, r in enumerate(results, 1):
        r.pop('_mtime')
        r['index'] = i
    return results


def format_grouped(results, keyword):
    if not results:
        return None

    total = len(results)
    groups = defaultdict(list)
    for r in results:
        groups[r['parent_rel']].append(r)

    lines = [f'找到 {total} 个匹配文件，已按项目分类：\n']

    for i, (parent_rel, items) in enumerate(groups.items(), 1):
        dir_label = _friendly_dir(parent_rel)
        lines.append(f'📁 {dir_label}')
        for item in items:
            lines.append(f'  • [{item["index"]}] {item["name"]}')
        lines.append('')

    lines.append('回复序号选择发送（多个序号用逗号分隔，如 1,3,5）')
    return '\n'.join(lines)


def format_list(results, keyword):
    if not results:
        return None

    lines = [f'找到 {len(results)} 个匹配文件：\n']
    for r in results:
        lines.append(f'[{r["index"]}] {r["name"]} — {r["modified"]} | {r["size_kb"]}KB')
    lines.append('\n回复序号选择发送（多个序号用逗号分隔，如 1,3,5）')
    return '\n'.join(lines)


def format_single(result):
    return (
        f'找到 1 个文件：\n'
        f'  [{result["index"]}] {result["name"]}\n'
        f'  路径：{result["path"]}\n'
        f'  修改：{result["modified"]} | 大小：{result["size_kb"]}KB\n\n'
        f'回复「发送」确认，或输入序号（直接发送）。'
    )


def send_file(contact: str, file_path: str) -> bool:
    """
    调用 wechat_sender.WeChatSender 发送文件
    """
    if not Path(file_path).exists():
        print(f'文件不存在: {file_path}')
        return False

    # 动态导入，避免非 Windows 环境报错
    sys.path.insert(0, str(Path(__file__).parent))
    try:
        from wechat_sender import WeChatSender
    except ImportError:
        print('错误：找不到 wechat_sender 模块，请确认 scripts/wechat_sender.py 存在')
        return False

    sender = WeChatSender()
    return sender.send_file(contact, file_path)


def main():
    parser = argparse.ArgumentParser(
        description='搜索文件并发送至微信联系人（交互式）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例：
  python batch_send.py --keyword "报价单" --contact "YHD"
  python batch_send.py --keyword "日报" --dirs "D:/" --contact "YHD" --depth 4
  python batch_send.py --keyword "报价单" --contact "YHD" --ext xlsx
  python batch_send.py --keyword "报价单" --contact "YHD" --indices "1,3"   # 直接发送指定序号
        '''
    )
    parser.add_argument('--keyword',  required=True, help='文件名关键词（模糊匹配）')
    parser.add_argument('--contact',  required=True, help='微信联系人名称')
    parser.add_argument('--dirs',      default='',   help='搜索目录，逗号分隔，默认桌面/下载/文档/Workspace')
    parser.add_argument('--ext',       default='',   help='限定扩展名（如 xlsx、pdf）')
    parser.add_argument('--depth',     type=int, default=3, help='递归深度（默认3）')
    parser.add_argument('--limit',     type=int, default=MAX_RESULTS, help='最多返回条数')
    parser.add_argument('--indices',   default='',   help='直接指定要发送的文件序号（逗号分隔，跳过确认）')
    parser.add_argument('--json',      action='store_true', help='只输出 JSON 结果，不发送')
    parser.add_argument('--dry-run',   action='store_true', help='不实际发送，只显示结果')

    args = parser.parse_args()

    # 解析搜索目录
    if args.dirs:
        dirs = [d.strip() for d in args.dirs.split(',') if d.strip()]
    else:
        dirs = None

    # 搜索文件
    results = search_files(
        name=args.keyword,
        search_dirs=dirs,
        ext=args.ext or None,
        depth=args.depth,
        limit=args.limit,
    )

    # JSON 模式：只输出搜索结果
    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return

    # 无结果
    if not results:
        print(f'未找到包含「{args.keyword}」的文件。请尝试：')
        print('  1. 换更通用的关键词')
        print('  2. 指定 --dirs "D:/" 扩大搜索范围')
        print('  3. 增加 --depth（如 --depth 5）')
        return

    # 直接发送模式：--indices 参数，跳过确认
    if args.indices:
        idx_set = set()
        for part in args.indices.split(','):
            part = part.strip()
            if not part:
                continue
            try:
                idx_set.add(int(part))
            except ValueError:
                pass
        to_send = [r for r in results if r['index'] in idx_set]
        if not to_send:
            print(f'未找到序号 {args.indices} 对应的文件')
            return
        for r in to_send:
            print(f'发送 [{r["index"]}] {r["name"]} ...')
            if not args.dry_run:
                ok = send_file(args.contact, r['path'])
                print('✅ 发送成功' if ok else '❌ 发送失败')
        return

    # ── 正常模式：展示结果，等待用户输入序号 ─────────────────────────────
    # 根据数量选择展示格式
    if len(results) == 1:
        output = format_single(results[0])
    elif len(results) <= 15:
        output = format_list(results, args.keyword)
    else:
        output = format_grouped(results, args.keyword)

    print(output)

    # 读取用户输入（stdin）
    # 注意：在 OpenClaw agent 环境中通过 exec 调用时，
    # 用户输入通过 process.write 写入 stdin
    try:
        user_input = input('请回复序号：').strip()
    except (EOFError, OSError):
        print('（无可用输入，跳过发送）')
        return

    if not user_input:
        print('未收到输入，退出')
        return

    # 解析序号
    idx_set = set()
    for part in user_input.split(','):
        part = part.strip()
        if not part:
            continue
        if part == '发送' or part == 'y' or part == 'yes':
            # 用户直接回复"发送"，对于单文件直接发送
            if len(results) == 1:
                idx_set.add(results[0]['index'])
            continue
        try:
            idx_set.add(int(part))
        except ValueError:
            pass

    if not idx_set:
        print('未识别有效序号，退出')
        return

    to_send = [r for r in results if r['index'] in idx_set]
    for r in to_send:
        print(f'发送 [{r["index"]}] {r["name"]} → {args.contact} ...')
        if not args.dry_run:
            ok = send_file(args.contact, r['path'])
            print('✅ 发送成功' if ok else '❌ 发送失败')


if __name__ == '__main__':
    main()
