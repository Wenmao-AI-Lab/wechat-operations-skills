#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件搜索工具 - wechat-sender 辅助脚本 v2

递归搜索文件，支持模糊匹配、智能分组、去重、精简输出。
供 agent 调用后将结果展示给用户确认，再决定发送哪个文件。

用法：
    python find_file.py --name "报价单"
    python find_file.py --name "报价" --dirs "D:/" --depth 3
    python find_file.py --name "日报" --ext xlsx --limit 10
"""

import os
import sys
import json
import argparse
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

# 默认搜索目录
DEFAULT_SEARCH_DIRS = [
    os.path.expanduser('~/Desktop'),
    os.path.expanduser('~/Downloads'),
    os.path.expanduser('~/Documents'),
    os.path.expanduser('~/.qclaw/workspace'),
]

# 目录友好名称映射
DIR_LABELS = {
    os.path.expanduser('~/Desktop'):           '桌面',
    os.path.expanduser('~/Downloads'):         '下载',
    os.path.expanduser('~/Documents'):         '文档',
    os.path.expanduser('~/.qclaw/workspace'):  'Workspace',
}

# 结果过多阈值
GROUP_THRESHOLD = 15  # 超过此数按目录分组摘要
MAX_RESULTS = 100      # 最多返回条数


def _get_dir_label(dir_path: str) -> str:
    """获取目录友好名称"""
    for dir_path_key, label in DIR_LABELS.items():
        if dir_path.startswith(dir_path_key):
            return label
    # D:/ 或 E:/ 等盘符 → 取前两段
    parts = Path(dir_path).parts
    if len(parts) >= 2:
        return f"{parts[0]}/{parts[1]}"
    return dir_path


def _is_temp_file(name: str) -> bool:
    """判断是否为临时文件/垃圾文件"""
    # Excel/PPT/Word 临时文件
    if name.startswith('~$'):
        return True
    # macOS 临时文件
    if name.startswith('.~') or name.startswith('._'):
        return True
    return False


def _dedup_name(name: str) -> str:
    """
    去重标准化文件名，用于检测重复副本。
    
    规则：
    - 去掉末尾的 (1), (2), (3), -副本, -copy 等后缀
    - 返回标准化的基础名和是否为重复标记
    """
    base = name
    is_dup = False

    # 匹配 (数字) 后缀，如 "文件(1).xlsx", "文件(2).xlsx"
    m = re.search(r'\s*\(\d+\)(\.[^.]+)$', base)
    if m:
        base = base[:m.start()] + m.group(1)
        is_dup = True

    # 匹配 -副本, -copy, _copy 后缀
    m = re.search(r'[-_]副本|[-_]copy', base, re.IGNORECASE)
    if m:
        base = base[:m.start()] + base[m.end():]
        is_dup = True

    return base.strip(), is_dup


def search_files(
    name: str,
    search_dirs: list = None,
    ext: str = None,
    depth: int = 3,
    limit: int = MAX_RESULTS,
) -> list:
    """
    递归搜索文件

    Args:
        name:        文件名关键词（模糊匹配，不区分大小写）
        search_dirs: 搜索目录列表
        ext:         限定扩展名（如 xlsx、pdf），不含点号
        depth:       递归深度，默认3
        limit:       最多返回条数

    Returns:
        list of dict
    """
    if search_dirs is None:
        search_dirs = DEFAULT_SEARCH_DIRS

    name_lower = name.lower()
    ext_lower = ext.lower().lstrip('.') if ext else None
    results = []
    seen_names = set()  # 用于去重

    for search_dir in search_dirs:
        search_path = Path(search_dir)
        if not search_path.is_dir():
            continue

        try:
            for file_path in search_path.rglob('*'):
                if not file_path.is_file():
                    continue

                # 深度控制
                try:
                    rel = file_path.relative_to(search_path)
                    if len(rel.parts) > depth:
                        continue
                except ValueError:
                    continue

                fname = file_path.name
                fname_lower = fname.lower()

                # 扩展名过滤
                if ext_lower and not fname_lower.endswith(f'.{ext_lower}'):
                    continue

                # 模糊匹配
                if name_lower not in fname_lower:
                    continue

                # 排除临时文件
                if _is_temp_file(fname):
                    continue

                # 去重：标准化文件名，跳过重复副本
                norm_name, is_dup = _dedup_name(fname)
                if is_dup and norm_name in seen_names:
                    continue
                seen_names.add(norm_name)

                stat = file_path.stat()
                            # 计算相对路径（从搜索根目录出发）
                rel_path = file_path.relative_to(search_path)
                rel_str  = str(rel_path).replace('\\', '/')   # 完整相对路径（含文件名）
                parent_rel = str(rel_path.parent).replace('\\', '/')  # 文件所在目录的相对路径

                results.append({
                    'name':     fname,
                    'path':     str(file_path).replace('\\', '/'),
                    'size_kb':  round(stat.st_size / 1024, 1),
                    'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
                    'dir':      str(file_path.parent).replace('\\', '/'),   # 绝对路径（分组用）
                    'rel':      rel_str,        # 搜索根目录相对路径（显示用）
                    'parent_rel': parent_rel,   # 目录相对路径（分组用）
                    '_mtime':   stat.st_mtime,
                })

                if len(results) >= limit:
                    break
        except PermissionError:
            continue

    # 按修改时间倒序
    results.sort(key=lambda x: x['_mtime'], reverse=True)

    final = []
    for i, r in enumerate(results, 1):
        r.pop('_mtime')
        r['index'] = i
        final.append(r)

    return final


def _friendly_dir(rel_path: str) -> str:
    """将相对路径转为更简洁的友好显示名"""
    parts = Path(rel_path).parts
    if len(parts) == 1:
        # 单段目录（如 '2投标'），直接显示
        return parts[0]
    if len(parts) == 2:
        # 两段（如 '中天钢铁/报价单'），取第二段更清晰
        return parts[1]
    # 三段及以上，取倒数第二段（项目名）/倒数第一段（子目录）
    return f'{parts[-2]}/{parts[-1]}'


def format_results_grouped(results: list, keyword: str) -> str:
    """
    分组格式化结果 — 按父目录分组，适配微信消息

    与微信端展示一致的风格：
    📁 目录名（项目名）
      • 文件1.xlsx
      • 文件2.xlsx
    """
    if not results:
        return f'未找到包含「{keyword}」的文件。请提供更具体的文件名或完整路径。'

    total = len(results)

    # ── 按父目录相对路径分组 ──
    groups = defaultdict(list)
    for r in results:
        # 用 parent_rel 相对路径分组，避免绝对路径前缀差异导致同组被拆散
        groups[r['parent_rel']].append(r)

    lines = [f'找到 {total} 个匹配文件，已按项目分类：\n']

    for i, (parent_rel, items) in enumerate(groups.items(), 1):
        # 友好目录名：'中天钢铁/2投标' → 显示项目+子目录
        dir_label = _friendly_dir(parent_rel)
        lines.append(f'📁 {dir_label}')
        for item in items:
            lines.append(f'  • {item["name"]}')
        lines.append('')

    lines.append('回复序号或文件名选择发送。')
    return '\n'.join(lines)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='文件搜索工具')
    parser.add_argument('--name',  required=True, help='文件名关键词')
    parser.add_argument('--dirs',  default='',    help='搜索目录，逗号分隔')
    parser.add_argument('--ext',   default='',    help='限定扩展名（如 xlsx）')
    parser.add_argument('--depth', type=int, default=3, help='递归深度（默认3）')
    parser.add_argument('--limit', type=int, default=MAX_RESULTS, help='最多返回条数')
    parser.add_argument('--json',  action='store_true',  help='输出 JSON 格式')
    args = parser.parse_args()

    dirs = [d.strip() for d in args.dirs.split(',') if d.strip()] or None

    results = search_files(
        name=args.name,
        search_dirs=dirs,
        ext=args.ext or None,
        depth=args.depth,
        limit=args.limit,
    )

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print(format_results_grouped(results, args.name))
