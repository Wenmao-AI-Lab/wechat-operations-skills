#!/usr/bin/env python3
"""
wechat-article-gen: 智能正文配图生成脚本

分析 Markdown 文章内容，在关键节点智能生成 1~4 张配图。

**优先使用即梦AI（火山引擎）**，即梦AI不可用时自动切换到 OpenAI 兼容 API。

Usage:
    python3 generate_images.py --article /path/to/article.md --output ./images/
    python3 generate_images.py --article /path/to/article.md --output ./images/ --num-images 2
    python3 generate_images.py --article /path/to/article.md --output ./images/ --provider openai --api-key $IMAGE_GEN_API_KEY
"""

import argparse
import base64
import json
import os
import re
import sys
import textwrap
import time
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Optional

# ============== 配置 ==============
DEFAULT_NUM_IMAGES = 2
MIN_IMAGES = 1
MAX_IMAGES = 4
DEFAULT_IMAGE_SIZE = "1024x1024"
DEFAULT_MODEL = "dall-e-3"
DEFAULT_API_BASE = "https://api.openai.com/v1"
TIMEOUT_SECONDS = 120

# ============== 颜色输出 ==============
RED = '\033[0;31m'
GREEN = '\033[0;32m'
YELLOW = '\033[1;33m'
BLUE = '\033[0;34m'
NC = '\033[0m'  # No Color


def color_print(color, msg):
    print(f"{color}{msg}{NC}")


# ============== 数据结构 ==============
@dataclass
class ImageNode:
    """需要插入图片的节点"""
    index: int           # 在段落列表中的索引
    title: str            # 所属标题
    paragraph: str        # 段落文本
    score: float          # 信息密度得分
    image_path: Optional[str] = None  # 生成后的本地图片路径


# ============== 工具函数 ==============
def extract_frontmatter(markdown_text):
    """提取 frontmatter，返回 (frontmatter_dict, 正文内容)"""
    frontmatter = {}
    body = markdown_text

    if markdown_text.startswith('---'):
        parts = markdown_text.split('---', 2)
        if len(parts) >= 3:
            fm_text = parts[1]
            body = parts[2].lstrip('\n')

            for line in fm_text.split('\n'):
                if ':' in line:
                    key, val = line.split(':', 1)
                    frontmatter[key.strip()] = val.strip()

    return frontmatter, body


def split_paragraphs(text):
    """将 Markdown 正文按自然段落切分，保留标题信息"""
    paragraphs = []
    current_title = ""

    lines = text.split('\n')
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        # 检测标题
        heading_match = re.match(r'^(#{1,6})\s+(.+)$', stripped)
        if heading_match:
            current_title = heading_match.group(2).strip()
        elif len(stripped) > 10:  # 忽略短行和空行
            paragraphs.append({
                'title': current_title,
                'text': stripped,
                'type': 'heading' if heading_match else 'paragraph'
            })

    return paragraphs


def calculate_image_score(paragraph, title, index, total_paragraphs):
    """计算某个段落的信息密度得分，决定是否需要配图"""
    text = paragraph['text']
    t = title

    score = 0.0

    # 长度分数：太短不需要配图
    length = len(text)
    if length < 50:
        return 0.0
    elif length < 200:
        score += 1.0
    elif length < 500:
        score += 2.0
    else:
        score += 3.0

    # 标题关键词加分
    title_lower = t.lower()
    text_lower = text.lower()

    # 强视觉相关词（应该在这些地方配图）
    visual_keywords = [
        '对比', '区别', '差异', '比较', '优缺点', '排行榜',
        '步骤', '流程', '方法', '技巧', '教程', '指南',
        '数据', '统计', '图表', '趋势', '增长', '下降',
        '排名', '列表', '清单', '框架', '模型', '架构',
        '案例', '故事', '经历', '示例', '效果', '成果',
        '原理', '机制', '逻辑', '解释', '说明',
        '类型', '分类', '种类', '版本', '代际',
        '场景', '应用', '使用', '操作', '实战'
    ]
    for kw in visual_keywords:
        if kw in title_lower or kw in text_lower:
            score += 2.0

    # 位置权重：文章开头和重要转折点优先
    position = index / max(total_paragraphs - 1, 1)
    if position < 0.2:  # 文章前 20%
        score += 1.5
    elif 0.4 <= position <= 0.7:  # 中间段落
        score += 1.0

    # 避免重复配图：相邻段落不同时配图
    # （由调用方在选择时控制）

    return round(score, 2)


def select_best_nodes(paragraphs, num_images):
    """从段落列表中选择最需要配图的 N 个节点"""
    if not paragraphs:
        return []

    # 计算每个段落得分
    scored = []
    for i, para in enumerate(paragraphs):
        score = calculate_image_score(para, para['title'], i, len(paragraphs))
        if score > 0:
            scored.append((score, i, para))

    # 按得分降序排列
    scored.sort(key=lambda x: -x[0])

    # 选择得分最高的 N 个，且相邻节点间隔至少1
    selected = []
    selected_indices = set()
    for score, idx, para in scored:
        if len(selected) >= num_images:
            break

        # 检查与已选节点的距离
        too_close = False
        for si in selected_indices:
            if abs(si - idx) <= 1:
                too_close = True
                break

        if not too_close:
            node = ImageNode(
                index=idx,
                title=para['title'],
                paragraph=para['text'],
                score=score
            )
            selected.append(node)
            selected_indices.add(idx)

    # 如果选不够，补充得分最高的
    if len(selected) < num_images:
        for score, idx, para in scored:
            if len(selected) >= num_images:
                break
            if idx not in selected_indices:
                node = ImageNode(
                    index=idx,
                    title=para['title'],
                    paragraph=para['text'],
                    score=score
                )
                selected.append(node)
                selected_indices.add(idx)

    # 按原文顺序排序
    selected.sort(key=lambda x: x.index)
    return selected


def clean_prompt_text(text):
    """
    清洗原文，移除 emoji 表情符号和货币符号（如 $），
    避免干扰图片生成提示词。
    """
    import re
    # 移除 emoji（常见的 Unicode emoji 范围）
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # emoticons
        "\U0001F300-\U0001F5FF"  # symbols & pictographs
        "\U0001F680-\U0001F6FF"  # transport & map symbols
        "\U0001F1E0-\U0001F1FF"  # flags
        "\U00002702-\U000027B0"
        "\U000024C2-\U0001F251"
        "\U00002600-\U000026FF"
        "\U00002700-\U000027BF"
        "\U0001F900-\U0001F9FF"  # supplemental symbols
        "\U0001FA00-\U0001FA6F"
        "\U0001FA70-\U0001FAFF"
        "]+", flags=re.UNICODE
    )
    text = emoji_pattern.sub('', text)
    # 移除美元符号和其他货币符号
    text = text.replace('$', ' ')
    # 移除多余空格
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def generate_image_prompt(paragraph_text, title, aspect_ratio='16:9'):
    """
    根据段落内容生成英文图像提示词。

    Args:
        paragraph_text: 段落文本内容
        title: 所属标题
        aspect_ratio: 图片宽高比（如 '16:9'、'2.35:1'）
    """
    # 清洗原文，去除 emoji 和货币符号
    text = clean_prompt_text(paragraph_text.strip())
    t = clean_prompt_text(title.strip()) if title else ""

    context = ""
    if t:
        context = f"Article title: {t}. "

    # 比例描述
    ratio_instruction = f"The image must be in {aspect_ratio} aspect ratio (landscape/wide format). "

    text_lower = text.lower()

    # 数据/排名类
    if any(kw in text_lower for kw in ['排名', '排行', 'top', 'best', '数据', '统计', '增长', '下降', '趋势']):
        prompt = (
            f"{context}{ratio_instruction}"
            f"Create a clean, professional infographic-style illustration for a Chinese tech article. "
            f"Show a clear data visualization with minimal design, soft blue and white color palette, "
            f"modern flat style. The image should visually represent key data insights from: {text[:200]}. "
            f"No text overlay, purely visual. High quality, 4K style."
        )
    # 步骤/教程类
    elif any(kw in text_lower for kw in ['步骤', '流程', '方法', '技巧', '教程', '如何', '指南', '教学']):
        prompt = (
            f"{context}{ratio_instruction}"
            f"Create a step-by-step tutorial illustration for a Chinese tech article. "
            f"Show a clean, modern infographic with numbered steps or a flowchart, "
            f"using a blue and white color scheme, minimalist design style. "
            f"Visualize the concept: {text[:200]}. "
            f"No text, purely visual diagrams. High quality, professional look."
        )
    # 对比类
    elif any(kw in text_lower for kw in ['对比', '区别', '差异', '比较', '优缺点', 'vs', ' versus ']):
        prompt = (
            f"{context}{ratio_instruction}"
            f"Create a comparison illustration for a Chinese tech article. "
            f"Show a clean side-by-side or before/after visual layout, "
            f"modern minimalist design with blue accent colors. "
            f"Visual content based on: {text[:200]}. "
            f"No text labels, purely visual comparison. High quality."
        )
    # 概念/原理类
    elif any(kw in text_lower for kw in ['原理', '机制', '架构', '框架', '模型', '概念', '逻辑']):
        prompt = (
            f"{context}{ratio_instruction}"
            f"Create a conceptual diagram or illustration for a Chinese tech article. "
            f"Show an abstract visual representation of a system or concept, "
            f"using geometric shapes, soft blue gradients, modern minimalist style. "
            f"Concept to illustrate: {text[:200]}. "
            f"No text, purely visual. Elegant and professional."
        )
    # 案例/故事类
    elif any(kw in text_lower for kw in ['案例', '故事', '经历', '示例', '实战', '经验', '效果', '成果']):
        prompt = (
            f"{context}{ratio_instruction}"
            f"Create a storytelling scene illustration for a Chinese tech article. "
            f"Show a warm, professional scene illustration with subtle details, "
            f"soft lighting, modern aesthetic. Theme: {text[:200]}. "
            f"No text, purely visual narrative. High quality digital art."
        )
    # 工具/产品展示类
    elif any(kw in text_lower for kw in ['工具', '软件', '产品', 'APP', '应用', '功能', '界面']):
        prompt = (
            f"{context}{ratio_instruction}"
            f"Create a product showcase illustration for a Chinese tech article. "
            f"Show a modern device with elegant UI design, clean interface mockup style, "
            f"blue and white color scheme, professional look. Content: {text[:200]}. "
            f"No text, purely visual product shot."
        )
    # 默认：通用文章配图
    else:
        prompt = (
            f"{context}{ratio_instruction}"
            f"Create a modern editorial illustration for a Chinese technology article. "
            f"Show an abstract yet professional visual that represents the theme: {text[:200]}. "
            f"Use a clean, minimalist style with blue and white tones, "
            f"geometric shapes and soft gradients. "
            f"No text, purely visual. High quality digital illustration."
        )

    return prompt


def call_image_api(prompt, api_key, api_base=DEFAULT_API_BASE, model=DEFAULT_MODEL, size=DEFAULT_IMAGE_SIZE):
    """调用图像生成 API（OpenAI 兼容格式）"""
    url = f"{api_base.rstrip('/')}/images/generations"

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    payload = {
        "model": model,
        "prompt": prompt,
        "size": size,
        "n": 1
    }

    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8') if e.fp else ""
        raise Exception(f"HTTP {e.code}: {error_body}")
    except urllib.error.URLError as e:
        raise Exception(f"Network error: {e.reason}")


def download_image(url, output_path):
    """下载图片到本地"""
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as response:
        data = response.read()
    with open(output_path, 'wb') as f:
        f.write(data)
    return output_path


def save_b64_image(b64_data, output_path):
    """保存 base64 图片到本地"""
    image_data = base64.b64decode(b64_data)
    with open(output_path, 'wb') as f:
        f.write(image_data)
    return output_path


def add_rounded_corners(path, radius=4):
    """给图片加白色圆角（通过白底 + 圆角mask贴图实现）"""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        color_print(YELLOW, f"⚠️  PIL 未安装，跳过圆角处理: {path}")
        return
    img = Image.open(path).convert("RGBA")
    w, h = img.size
    # 创建白底
    white = Image.new("RGBA", (w, h), (255, 255, 255, 255))
    # 创建圆角mask（白=不透明，黑=透明）
    mask = Image.new("L", (w, h), 0)
    draw_mask = ImageDraw.Draw(mask)
    draw_mask.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=radius, fill=255)
    # 白底 + mask贴原图 → 原图显示在圆角区域内，外部为白色
    white.paste(img, (0, 0), mask)
    white.convert("RGB").save(path, "PNG")


# ============== 即梦AI 图片生成（调用 jimeng.py） ==============
def call_jimeng_api(prompt, output_path, config):
    """调用 jimeng.py 生成图片（通过子进程）"""
    import subprocess

    script_dir = os.path.dirname(os.path.abspath(__file__))
    jimeng_script = os.path.join(script_dir, 'jimeng.py')

    # 构建命令
    # 使用 size 参数（兼容 API 的面积值）避免 width/height 校验问题
    # 4096×4096 = 16777216（最高清），2048×2048 = 4194304（推荐）
    cmd = [
        sys.executable, jimeng_script,
        prompt,
        '-o', output_path,
        '--size', '4194304',   # 2048×2048，稳定可用
        '--poll-interval', '3',
        '--max-wait', '300'
    ]

    # 通过环境变量传递 config 路径
    env = os.environ.copy()
    config_file = os.path.join(os.path.dirname(script_dir), 'config.env')
    if os.path.exists(config_file):
        env['JIMENG_CONFIG_FILE'] = config_file

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        env=env,
        timeout=360
    )

    if result.returncode != 0:
        raise Exception(f"jimeng.py 执行失败: {result.stderr.strip()}")

    return {'status': 'done'}


def count_main_sections(body):
    """统计文章中的 ## 一级标题数量（即主要章节数）"""
    import re
    sections = re.findall(r'^##\s+[^#\n]', body, re.MULTILINE)
    return len(sections)


def auto_detect_num_images(paragraphs, body=""):
    """
    根据文章结构智能确定配图数量（1~4张）。
    优先看 ## 章节数量（最接近"让大语言模型判断"的效果），
    没有 ## 时回退到总字数。
    """
    section_count = 0
    if body:
        section_count = count_main_sections(body)

    if section_count >= 6:
        return 4
    elif section_count >= 4:
        return 3
    elif section_count >= 2:
        return 2
    elif section_count >= 1:
        return 1

    # 回退：按字数
    total_chars = sum(len(p['text']) for p in paragraphs)
    if total_chars < 800:
        return 1
    elif total_chars < 1500:
        return 2
    elif total_chars < 2500:
        return 3
    else:
        return 4


# ============== 主流程 ==============
def generate_images_for_article(
    article_path,
    output_dir,
    api_key=None,
    api_base=DEFAULT_API_BASE,
    model=DEFAULT_MODEL,
    num_images=None,
    provider='jimeng',  # 'jimeng' 或 'openai'
    config=None
):
    """主函数：分析文章，生成配图，返回结果"""

    color_print(BLUE, "🖼️  微信图文智能配图生成器")
    print("=" * 50)

    # 读取文章
    with open(article_path, 'r', encoding='utf-8') as f:
        markdown_content = f.read()

    # 提取 frontmatter 和正文
    frontmatter, body = extract_frontmatter(markdown_content)
    color_print(GREEN, f"✅ 文章已加载: {article_path}")
    color_print(YELLOW, f"   标题: {frontmatter.get('title', '未设置')}")

    # 切分段落
    paragraphs = split_paragraphs(body)
    if not paragraphs:
        color_print(RED, "❌ 未能提取有效段落，请检查文章格式")
        sys.exit(1)

    color_print(GREEN, f"✅ 提取到 {len(paragraphs)} 个有效段落")

    # 确定配图数量
    if num_images is None:
        num_images = auto_detect_num_images(paragraphs, body=body)
    num_images = max(MIN_IMAGES, min(MAX_IMAGES, num_images))
    color_print(YELLOW, f"🖼️  将生成 {num_images} 张配图（智能分配到关键节点）")

    # 选择最佳节点
    nodes = select_best_nodes(paragraphs, num_images)
    if not nodes:
        color_print(RED, "❌ 未能找到合适的配图位置")
        sys.exit(1)

    print("")
    color_print(GREEN, "📍 配图节点分配：")
    for i, node in enumerate(nodes):
        preview = textwrap.fill(node.paragraph, width=50)[:50]
        print(f"   [{i+1}] {node.title or '正文'} | 得分: {node.score} | 预览: {preview}...")

    print("")
    color_print(BLUE, "🎨 开始生成配图...")
    print("-" * 50)

    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    generated_paths = []
    errors = []

    for i, node in enumerate(nodes):
        color_print(YELLOW, f"\n🖼️  生成第 {i+1}/{num_images} 张...")
        color_print(BLUE, f"   节点: {node.title or '正文'}")
        preview = textwrap.fill(node.paragraph, width=60)[:80]
        color_print(BLUE, f"   内容: {preview}...")

        # 生成提示词
        prompt = generate_image_prompt(node.paragraph, node.title)
        color_print(BLUE, f"   提示词: {prompt[:80]}...")

        try:
            filename = f"generated_image_{i+1:02d}.png"
            filepath = os.path.join(output_dir, filename)

            if provider == 'jimeng':
                color_print(BLUE, f"   调用即梦AI生成...")
                result = call_jimeng_api(prompt, filepath, config)
                if os.path.exists(filepath):
                    add_rounded_corners(filepath, radius=4)
                    color_print(GREEN, f"   ✅ 保存成功（含4px圆角）: {filepath}")
                    generated_paths.append((node.index, filepath))
                else:
                    raise Exception("jimeng.py 未生成图片文件")
            else:
                result = call_image_api(prompt, api_key, api_base, model)

                if 'data' in result and len(result['data']) > 0:
                    img_data = result['data'][0]

                    if 'url' in img_data and img_data['url']:
                        color_print(BLUE, f"   下载图片 from URL...")
                        download_image(img_data['url'], filepath)
                    elif 'b64_json' in img_data and img_data['b64_json']:
                        color_print(BLUE, f"   保存 base64 图片...")
                        save_b64_image(img_data['b64_json'], filepath)
                    else:
                        raise Exception("API 响应中既没有 url 也没有 b64_json")

                    add_rounded_corners(filepath, radius=4)
                    color_print(GREEN, f"   ✅ 保存成功（含4px圆角）: {filepath}")
                    generated_paths.append((node.index, filepath))
                else:
                    raise Exception(f"API 响应格式异常: {result}")

        except Exception as e:
            color_print(RED, f"   ❌ 生成失败: {e}")
            errors.append((i+1, str(e)))

        # API 限流保护
        if i < len(nodes) - 1:
            time.sleep(1)

    print("")
    print("=" * 50)
    color_print(GREEN, f"🎉 配图生成完成！共成功 {len(generated_paths)}/{num_images} 张")

    if errors:
        color_print(RED, f"❌ 失败列表：")
        for idx, err in errors:
            color_print(RED, f"   第 {idx} 张: {err}")

    # 生成更新后的 Markdown
    new_markdown_lines = markdown_content.split('\n')
    lines_with_placeholders = []

    # 找到所有 ASSISTANT_GEN_IMAGE 占位符的位置
    new_content = markdown_content

    for idx, img_path in generated_paths:
        placeholder = "ASSISTANT_GEN_IMAGE"
        # 简单处理：在匹配位置后插入图片
        # 实际上每个节点只对应一个占位符替换
        rel_path = os.path.relpath(img_path, os.path.dirname(article_path))
        new_content = new_content.replace(
            f"![智能配图占位]({placeholder})",
            f"![配图{idx+1}]({rel_path})",
            1
        )

    # 如果没有占位符，则在段落末尾插入
    if "ASSISTANT_GEN_IMAGE" not in new_content:
        new_content_lines = new_content.split('\n')
        for idx, img_path in generated_paths:
            rel_path = os.path.relpath(img_path, os.path.dirname(article_path))
            # 在对应段落后面插入空行+图片
            pass  # 简化处理：保持原样，图片路径在 generate_info 中返回

    # 输出总结
    output_info_path = os.path.join(output_dir, "generation_report.json")
    report = {
        "article": article_path,
        "total_requested": num_images,
        "total_generated": len(generated_paths),
        "images": [
            {"index": idx, "path": path}
            for idx, path in generated_paths
        ],
        "errors": errors,
        "model": model
    }

    with open(output_info_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    color_print(GREEN, f"📄 报告已保存: {output_info_path}")
    print("")
    color_print(YELLOW, "💡 提示：")
    color_print(YELLOW, "   生成的图片已保存到: " + output_dir)
    color_print(YELLOW, "   如需在文章中插入图片，请在 Markdown 中添加：")
    color_print(YELLOW, "   ![描述](图片相对路径或绝对路径)")

    for idx, path in generated_paths:
        rel = os.path.relpath(path, os.path.dirname(article_path))
        color_print(YELLOW, f"   第{idx+1}张: ![配图]({rel})")

    return generated_paths, errors


# ============== CLI 入口 ==============
def main():
    parser = argparse.ArgumentParser(
        description="微信图文智能配图生成器 - 在文章关键节点自动生成 1~4 张配图",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python3 generate_images.py --article article.md --output ./images/
  python3 generate_images.py --article article.md --output ./images/ --num-images 3
  python3 generate_images.py --article article.md --output ./images/ --api-key $IMAGE_GEN_API_KEY

环境变量:
  IMAGE_GEN_API_KEY     图像生成 API Key（必填）
  IMAGE_GEN_API_BASE    API 地址（默认: https://api.openai.com/v1）
  IMAGE_GEN_MODEL       模型名称（默认: dall-e-3）
        """
    )

    parser.add_argument('--article', '-f', required=True,
                        help='文章 Markdown 文件路径')
    parser.add_argument('--output', '-o', required=True,
                        help='图片输出目录')
    parser.add_argument('--num-images', '-n', type=int, default=None,
                        help=f'配图数量（1~4，不指定则自动分配，默认 {DEFAULT_NUM_IMAGES}）')
    parser.add_argument('--api-key', '-k', default=None,
                        help='图像生成 API Key（OpenAI兼容API，可从 IMAGE_GEN_API_KEY 环境变量读取）')
    parser.add_argument('--api-base', '-b', default=DEFAULT_API_BASE,
                        help=f'API 地址（默认: {DEFAULT_API_BASE}）')
    parser.add_argument('--model', '-m', default=DEFAULT_MODEL,
                        help=f'模型名称（默认: {DEFAULT_MODEL}）')
    parser.add_argument('--provider', '-p', default='jimeng',
                        choices=['jimeng', 'openai'],
                        help='图片生成服务（默认 jimeng，优先使用即梦AI）')

    args = parser.parse_args()

    # 加载 config.env（用于即梦AI）
    config = None
    script_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(os.path.dirname(script_dir), 'config.env')
    if os.path.exists(config_file):
        with open(config_file, 'r', encoding='utf-8') as f:
            config = {}
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    k, v = line.split('=', 1)
                    v = v.split('#')[0].strip()  # 去除行内注释
                    config[k.strip()] = v

    # 确定 provider
    provider = args.provider
    if provider == 'jimeng':
        # 检查 jimeng 凭证是否可用
        jimeng_ak = config.get('JIMENG_ACCESS_KEY_ID') if config else None
        if not jimeng_ak:
            jimeng_ak = os.environ.get('JIMENG_ACCESS_KEY_ID')
        if not jimeng_ak:
            color_print(YELLOW, "⚠️  即梦AI凭证未配置，自动切换到 OpenAI API")
            provider = 'openai'

    # 获取 API Key（OpenAI 模式需要）
    api_key = args.api_key or os.environ.get('IMAGE_GEN_API_KEY', '')

    # 检查文章文件
    if not os.path.isfile(args.article):
        color_print(RED, f"❌ 文件不存在: {args.article}")
        sys.exit(1)

    # OpenAI 模式需要 API Key
    if provider == 'openai' and not api_key:
        color_print(RED, "❌ 错误：OpenAI API 模式需要设置 API Key")
        color_print(YELLOW, "")
        color_print(YELLOW, "请通过以下方式之一设置：")
        color_print(YELLOW, "  1. 命令行参数: --api-key YOUR_API_KEY")
        color_print(YELLOW, "  2. 环境变量: export IMAGE_GEN_API_KEY=YOUR_API_KEY")
        sys.exit(1)

    color_print(BLUE, f"🖼️  图片生成服务: {provider.upper()}")

    # 运行
    generated_paths, errors = generate_images_for_article(
        article_path=args.article,
        output_dir=args.output,
        api_key=api_key,
        api_base=args.api_base,
        model=args.model,
        num_images=args.num_images,
        provider=provider,
        config=config
    )

    print("")
    color_print(GREEN, f"✅ 配图完成！成功 {len(generated_paths)} 张")
    for idx, path in generated_paths:
        color_print(GREEN, f"   第{idx+1}张: {path}")
    if errors:
        for idx, err in errors:
            color_print(RED, f"   第{idx}张失败: {err}")


if __name__ == '__main__':
    main()
