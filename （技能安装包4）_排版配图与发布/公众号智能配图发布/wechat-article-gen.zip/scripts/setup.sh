#!/usr/bin/env bash
# setup.sh - 加载微信公众号凭证到环境变量
# Usage: source ./scripts/setup.sh
#
# 读取顺序：TOOLS.md (export 格式) > config.env (key=value 格式)

TOOLS_MD="$HOME/.openclaw/workspace/TOOLS.md"
SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# ============== 读取凭证 ==============
load() {
    local loaded=0

    # 1. 优先从 TOOLS.md（export 格式）
    if [ -f "$TOOLS_MD" ]; then
        local appid=$(grep "export WECHAT_APP_ID=" "$TOOLS_MD" | head -1 | sed 's/.*export WECHAT_APP_ID=//' | tr -d ' `')
        local secret=$(grep "export WECHAT_APP_SECRET=" "$TOOLS_MD" | head -1 | sed 's/.*export WECHAT_APP_SECRET=//' | tr -d ' `')
        if [ -n "$appid" ] && [ -n "$secret" ]; then
            export WECHAT_APP_ID="$appid"
            export WECHAT_APP_SECRET="$secret"
            loaded=1
        fi
    fi

    # 2. 其次从 config.env（key=value 格式）
    if [ $loaded -eq 0 ]; then
        local cfg="$SKILL_DIR/config.env"
        if [ -f "$cfg" ]; then
            local appid=$(grep "^WECHAT_APP_ID=" "$cfg" | head -1 | sed 's/.*=//' | tr -d ' `')
            local secret=$(grep "^WECHAT_APP_SECRET=" "$cfg" | head -1 | sed 's/.*=//' | tr -d ' `')
            if [ -n "$appid" ] && [ -n "$secret" ]; then
                export WECHAT_APP_ID="$appid"
                export WECHAT_APP_SECRET="$secret"
                loaded=1
            fi
        fi
    fi
}

load

# ============== 检查结果 ==============
if [ -z "$WECHAT_APP_ID" ] || [ -z "$WECHAT_APP_SECRET" ]; then
    echo -e "${RED}❌ 无法读取微信公众号凭证！${NC}"
    echo ""
    echo "请确保以下文件之一包含有效凭证："
    echo "  1. TOOLS.md (格式: export WECHAT_APP_ID=xxx)"
    echo "  2. $SKILL_DIR/config.env (格式: WECHAT_APP_ID=xxx)"
    exit 1
fi

echo ""
echo -e "${GREEN}✅ 微信公众号凭证已加载！${NC}"
echo ""
echo "   APP_ID:    ${WECHAT_APP_ID:0:10}..."
echo "   APP_SECRET: ******"
echo ""
echo -e "${YELLOW}💡 凭证仅在当前 shell 会话有效${NC}"
