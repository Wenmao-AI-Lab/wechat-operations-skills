#!/usr/bin/env bash
# wechat-article-gen: 发布 Markdown 到微信公众号草稿箱
# Usage: ./publish.sh <markdown-file> [theme] [highlight]
#
# 基于 wenyan-cli 的 wenyan publish 命令：
#   - 自动渲染 Markdown → HTML
#   - 自动上传本地/网络图片到微信 CDN
#   - 自动替换图片路径为 data-src CDN 地址
#   - 发布到草稿箱

set -e

# ============== 颜色 ==============
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ============== 默认配置 ==============
DEFAULT_THEME="lapis"
DEFAULT_HIGHLIGHT="solarized-light"
TOOLS_MD="$HOME/.openclaw/workspace/TOOLS.md"
SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# ============== 检查 wenyan-cli ==============
check_wenyan() {
    if ! command -v wenyan &> /dev/null; then
        echo -e "${RED}❌ wenyan-cli 未安装！${NC}"
        echo -e "${YELLOW}正在安装 wenyan-cli...${NC}"
        npm install -g @wenyan-md/cli
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✅ wenyan-cli 安装成功！${NC}"
        else
            echo -e "${RED}❌ 安装失败，请手动运行: npm install -g @wenyan-md/cli${NC}"
            exit 1
        fi
    fi
}

# ============== 读取凭证（优先级：环境变量 > TOOLS.md > config.env）==============
load_credentials() {
    if [ -z "$WECHAT_APP_ID" ] || [ -z "$WECHAT_APP_SECRET" ]; then
        # 尝试从 TOOLS.md 读取（export WECHAT_APP_ID=xxx 格式）
        if [ -f "$TOOLS_MD" ]; then
            echo -e "${YELLOW}📖 从 TOOLS.md 读取微信公众号凭证...${NC}"
            export WECHAT_APP_ID=$(grep "export WECHAT_APP_ID=" "$TOOLS_MD" | head -1 | sed 's/.*export WECHAT_APP_ID=//' | tr -d ' `')
            export WECHAT_APP_SECRET=$(grep "export WECHAT_APP_SECRET=" "$TOOLS_MD" | head -1 | sed 's/.*export WECHAT_APP_SECRET=//' | tr -d ' `')
        fi
        # 尝试从 config.env 读取（key=value 格式）
        if [ -z "$WECHAT_APP_ID" ] || [ -z "$WECHAT_APP_SECRET" ]; then
            local cfg="$SKILL_DIR/config.env"
            if [ -f "$cfg" ]; then
                echo -e "${YELLOW}📖 从 config.env 读取微信公众号凭证...${NC}"
                export WECHAT_APP_ID=$(grep "^WECHAT_APP_ID=" "$cfg" | head -1 | sed 's/.*=//' | tr -d ' `')
                export WECHAT_APP_SECRET=$(grep "^WECHAT_APP_SECRET=" "$cfg" | head -1 | sed 's/.*=//' | tr -d ' `')
            fi
        fi
    fi
}

# ============== 检查环境变量 ==============
check_env() {
    load_credentials

    if [ -z "$WECHAT_APP_ID" ] || [ -z "$WECHAT_APP_SECRET" ]; then
        echo -e "${RED}❌ 环境变量未设置！${NC}"
        echo ""
        echo -e "${YELLOW}请在 TOOLS.md 或 config.env 中添加微信公众号凭证：${NC}"
        echo ""
        echo "## 🔐 WeChat Official Account"
        echo "export WECHAT_APP_ID=your_app_id"
        echo "export WECHAT_APP_SECRET=your_app_secret"
        echo ""
        echo "或者运行："
        echo "  source ./scripts/setup.sh"
        exit 1
    fi
    echo -e "${GREEN}✅ 微信公众号凭证已就绪${NC}"
}

# ============== 检查文件 ==============
check_file() {
    local file="$1"
    if [ ! -f "$file" ]; then
        echo -e "${RED}❌ 文件不存在: $file${NC}"
        exit 1
    fi
    # 检查 frontmatter
    if ! head -5 "$file" | grep -q "^---"; then
        echo -e "${YELLOW}⚠️  警告：文件可能缺少 frontmatter${NC}"
        echo "   frontmatter 必须包含 title 和 cover："
        echo "   ---"
        echo "   title: 文章标题"
        echo "   cover: ./cover.png"
        echo "   ---"
    fi
}

# ============== 发布 ==============
publish() {
    local file="$1"
    local theme="${2:-$DEFAULT_THEME}"
    local highlight="${3:-$DEFAULT_HIGHLIGHT}"

    echo -e "${BLUE}📝 准备发布文章...${NC}"
    echo "   文件: $file"
    echo "   主题: $theme"
    echo "   代码高亮: $highlight"
    echo ""

    wenyan publish -f "$file" -t "$theme" -h "$highlight"

    if [ $? -eq 0 ]; then
        echo ""
        echo -e "${GREEN}✅ 发布成功！${NC}"
        echo -e "${YELLOW}📱 请前往微信公众号后台草稿箱查看：${NC}"
        echo "   https://mp.weixin.qq.com/"
    else
        echo ""
        echo -e "${RED}❌ 发布失败！${NC}"
        echo -e "${YELLOW}💡 常见问题：${NC}"
        echo "   1. IP 未在白名单 → 添加到公众号后台"
        echo "   2. Frontmatter 缺失 → 文件顶部添加 title + cover"
        echo "   3. API 凭证错误 → 检查 TOOLS.md 或 config.env"
        echo "   4. 封面图缺失 → frontmatter 中添加 cover 字段"
        exit 1
    fi
}

# ============== 帮助 ==============
show_help() {
    echo "Usage: $0 <markdown-file> [theme] [highlight]"
    echo ""
    echo "Examples:"
    echo "  $0 article.md"
    echo "  $0 article.md lapis"
    echo "  $0 article.md lapis solarized-light"
    echo ""
    echo "Available themes: default, lapis, phycat, ..."
    echo "  Run 'wenyan theme -l' to see all themes"
    echo ""
    echo "Available highlights:"
    echo "  atom-one-dark, atom-one-light, dracula, github-dark, github,"
    echo "  monokai, solarized-dark, solarized-light, xcode"
}

# ============== 主函数 ==============
main() {
    if [ $# -eq 0 ] || [ "$1" == "-h" ] || [ "$1" == "--help" ]; then
        show_help
        exit 0
    fi

    local file="$1"
    local theme="$2"
    local highlight="$3"

    check_wenyan
    check_env
    check_file "$file"
    publish "$file" "$theme" "$highlight"
}

main "$@"
