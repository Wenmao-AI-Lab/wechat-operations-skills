---

name: wechat-publisher-auto
version: 1.1.0
description: 微信公众号自动化发布助手（单账号版）。支持增量式配置向导、热点方向选择、多模型文生图（通义万相/DALL-E）、V5 极致排版及草稿箱发布。
tags: [wechat, automation, publishing, v5-layout, image-generation]
---




# WeChat Publisher Pro

## 触发场景
当用户希望自动化生产并发布微信公众号文章时触发。

## 核心流程
1. **智能配置检查**：启动时自动检测凭证完整性，仅针对缺失项启动增量式交互向导。
2. **热点精准选择**：从预设的 `topics` 列表中让用户手动选择一个创作方向。
3. **AI 配图生成**：根据选题自动生成扁平插画风格封面，支持通义万相（默认）或 DALL-E 3。
4. **素材自动上传**：生成的封面图自动上传至微信素材库，获取 `thumb_media_id`。
5. **V5 极致排版**：使用内置引擎将 Markdown 转换为极致压缩的 HTML，消除段间距。
6. **草稿箱同步**：通过微信 API 将内容同步至草稿箱。

## 配置说明
- **凭证存储**：所有敏感信息（AppID, Secret, API Keys）均通过 AES-256 加密存储在本地 `config.enc`。
- **排版规范**：默认采用 V5 标准，行高 1.75，字间距 1px，两端对齐，HTML 源码极致压缩。
- **模型切换**：在首次配置或补全 Key 时，可自由选择文生图模型。
