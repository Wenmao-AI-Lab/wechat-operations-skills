import os
from openai import OpenAI

class QwenAdapter:
    def __init__(self, api_key, model="qwen-plus"):
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
        )
        self.model = model

    def generate_article(self, topic, style="专业科技"):
        """根据选题和风格生成文章"""
        system_prompt = f"""你是一位资深的公众号主笔。请围绕主题“{topic}”撰写一篇深度文章。
要求：
1. 风格：{style}
2. 结构：包含标题、开篇引入、3-4个核心观点小节、结尾总结。
3. 格式：使用 Markdown 格式，重点内容加粗。
4. 字数：1200-1500 字左右。
5. 语气：自然流畅，避免 AI 味，适当加入行业洞察。"""
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"请开始创作关于 {topic} 的文章。"}
            ]
        )
        return response.choices[0].message.content
