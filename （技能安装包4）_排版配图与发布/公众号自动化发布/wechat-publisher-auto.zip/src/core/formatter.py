import re
import markdown

class V5Formatter:
    def __init__(self):
        # 根据 TASK-V0.1.1.md 阶段五定义的固定样式
        self.styles = {
            "container": "max-width: 677px; font-size: 16px; line-height: 1.75; letter-spacing: 0.05em; color: #333; text-align: justify;",
            "h1": "font-size: 20px; font-weight: bold; border-left: 4px solid #07c160; padding-left: 10px; margin: 20px 0 15px;",
            "h2": "font-size: 18px; font-weight: bold; border-left: 3px solid #07c160; padding-left: 10px; margin: 20px 0 15px;",
            "h3": "font-size: 17px; font-weight: bold; margin: 15px 0 10px;",
            "p": "margin: 15px 0; text-align: justify;",
            "strong": "color: #07c160;",
            "code": "background-color: #f6f8fa; color: #e83e8c; padding: 2px 4px; border-radius: 3px; font-family: monospace;",
            "blockquote": "background-color: #f6f8fa; padding: 15px; border-left: 4px solid #dfe2e5; margin: 15px 0; color: #666;",
            "ul": "padding-left: 20px; list-style-type: disc;",
            "li": "margin-bottom: 8px;",
            "hr": "border: none; height: 1px; background-color: #eaeaea; margin: 25px 0;",
            "a": "color: #07c160; text-decoration: none;"
        }

    def _inject_styles(self, html):
        """将 CSS 样式注入到 HTML 标签中"""
        # 标题处理
        html = re.sub(r'<h1>(.*?)</h1>', f'<section style="{self.styles["h1"]}">\\1</section>', html)
        html = re.sub(r'<h2>(.*?)</h2>', f'<section style="{self.styles["h2"]}">\\1</section>', html)
        html = re.sub(r'<h3>(.*?)</h3>', f'<section style="{self.styles["h3"]}">\\1</section>', html)
        
        # 段落与列表
        html = re.sub(r'<p>(.*?)</p>', f'<p style="{self.styles["p"]}">\\1</p>', html)
        html = re.sub(r'<ul>', f'<ul style="{self.styles["ul"]}">', html)
        html = re.sub(r'<li>', f'<li style="{self.styles["li"]}">', html)
        
        # 强调与代码
        html = re.sub(r'<strong>(.*?)</strong>', f'<strong style="{self.styles["strong"]}">\\1</strong>', html)
        html = re.sub(r'<code>(.*?)</code>', f'<code style="{self.styles["code"]}">\\1</code>', html)
        
        # 引用块与分隔线
        html = re.sub(r'<blockquote>(.*?)</blockquote>', f'<blockquote style="{self.styles["blockquote"]}">\\1</blockquote>', html)
        html = re.sub(r'<hr />', f'<hr style="{self.styles["hr"]}" />', html)
        
        return html

    def format(self, markdown_content):
        # 转换 Markdown 为 HTML
        html = markdown.markdown(markdown_content, extensions=['fenced_code'])
        
        # 注入样式
        styled_html = self._inject_styles(html)
        
        # 包裹容器并执行极致压缩（消除微信隐形段间距）
        content = f"<section style='{self.styles['container']}'>{styled_html}</section>"
        content = re.sub(r'>\s+<', '><', content)
        
        return content
