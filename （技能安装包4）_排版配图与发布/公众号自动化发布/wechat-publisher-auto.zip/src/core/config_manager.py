import os
import json
from cryptography.fernet import Fernet

class ConfigManager:
    def __init__(self, skill_dir):
        self.config_path = os.path.join(skill_dir, 'config.enc')
        self.key_path = os.path.join(skill_dir, '.key')
        self._ensure_key()

    def _ensure_key(self):
        if not os.path.exists(self.key_path):
            key = Fernet.generate_key()
            with open(self.key_path, 'wb') as f:
                f.write(key)
        with open(self.key_path, 'rb') as f:
            self.cipher = Fernet(f.read())

    def load(self) -> dict:
        if not os.path.exists(self.config_path):
            return {}
        with open(self.config_path, 'rb') as f:
            encrypted_data = f.read()
        return json.loads(self.cipher.decrypt(encrypted_data).decode())

    def save(self, config: dict):
        # 确保新字段有默认值
        if 'image_model' not in config:
            config['image_model'] = 'wanx-v1'
        encrypted_data = self.cipher.encrypt(json.dumps(config).encode())
        with open(self.config_path, 'wb') as f:
            f.write(encrypted_data)
