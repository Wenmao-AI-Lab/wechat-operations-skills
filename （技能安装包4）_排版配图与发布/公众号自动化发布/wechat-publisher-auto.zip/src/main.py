import os
import sys
import json
import pyperclip

# 动态路径探测：确保脚本在任何环境下都能正确加载 core 模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config_manager import ConfigManager
from core.formatter import V5Formatter
from core.api_client import WechatApiClient
from core.image_generator import ImageGenerator
from core.llm_adapter import QwenAdapter

def setup_wizard(cm):
    """增量式配置向导：只询问缺失的配置项"""
    print("=== wechat-publisher-pro 配置向导 ===")
    config = cm.load()
    
    if not config.get('app_id'):
        config['app_id'] = input("请输入公众号 AppID: ").strip()
    
    if not config.get('app_secret'):
        config['app_secret'] = input("请输入公众号 AppSecret: ").strip()

    # LLM 配置（新增）
    if not config.get('llm_api_key'):
        config['llm_api_key'] = input("请输入通义千问 (Qwen) API Key: ").strip()
    
    # 文生图模型选择与 Key 配置
    if not config.get('image_api_key'):
        print("\n请选择文生图模型:")
        print("1. 通义万相 (默认, 推荐)")
        print("2. DALL-E 3")
        choice = input("输入序号 (直接回车选 1): ").strip()
        config['image_model'] = 'dall-e-3' if choice == '2' else 'wanx-v1'
        
        key_name = "DALL-E API Key" if config['image_model'] == 'dall-e-3' else "通义万相 API Key"
        config['image_api_key'] = input(f"请输入 {key_name}: ").strip()
    
    if not config.get('topics'):
        topics_input = input("\n请输入选题方向（用逗号分隔，如：AI,法律科技,SaaS）: ")
        config['topics'] = [t.strip() for t in topics_input.split(',') if t.strip()]
    
    cm.save(config)
    print("✅ 配置已加密保存！")
    return config

def select_topic(topics):
    if not topics:
        return "AI 趋势"
    print("\n可选热点方向：")
    for i, t in enumerate(topics, 1):
        print(f"{i}. {t}")
    choice = input("请选择编号 (直接回车选第一个): ").strip()
    try:
        idx = int(choice) - 1
        if 0 <= idx < len(topics):
            return topics[idx]
    except:
        pass
    return topics[0]

def copy_to_clipboard(text):
    """将内容写入系统剪贴板 (安全修复：使用 pyperclip 替代 subprocess)"""
    try:
        pyperclip.copy(text)
        print("✅ 已自动复制到系统剪贴板 (Cmd + V / Ctrl + V 即可粘贴)")
    except Exception as e:
        print(f"⚠️ 剪贴板写入失败: {e}")
        print("💡 请手动复制以下内容：")
        print(text)

def extract_title(markdown_content):
    """从 Markdown 内容中提取第一行作为标题"""
    lines = markdown_content.strip().split('\n')
    for line in lines:
        if line.startswith('#'):
            return line.lstrip('#').strip()
    return "AI 深度观察"

def main():
    # 确定技能根目录（src 的上一级）
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cm = ConfigManager(root_dir)
    
    # 检查关键配置是否缺失，若缺失则启动向导
    config = cm.load()
    required_keys = ['app_id', 'app_secret', 'image_api_key', 'llm_api_key']
    if any(not config.get(k) for k in required_keys) or not config.get('topics'):
        config = setup_wizard(cm)

    if not config.get('topics'):
        print("❌ 未找到选题方向，请在配置中添加。")
        return

    topic = select_topic(config['topics'])
    print(f"\n🚀 正在围绕【{topic}】进行搜索与创作...")
    
    # 初始化模块
    formatter = V5Formatter()
    api = WechatApiClient(config['app_id'], config['app_secret'])
    img_gen = ImageGenerator(model=config.get('image_model', 'wanx-v1'), api_key=config['image_api_key'])
    llm = QwenAdapter(api_key=config['llm_api_key'])
    
    # 1. AI 深度写作
    print("✍️ 正在进行 AI 深度创作...")
    markdown_content = llm.generate_article(topic, style="专业科技")
    title = extract_title(markdown_content)
    print(f"📝 文章标题：{title}")
    
    # 2. 生成封面图并上传
    print("🎨 正在生成扁平插画风格封面...")
    cover_prompt = f"扁平插画风格，温暖橘色调，关于 {topic} 的科技商业场景，极简主义，9:16 竖版构图"
    cover_path = img_gen.generate(cover_prompt)
    thumb_media_id = None
    if cover_path:
        token = api.get_token()
        thumb_media_id = img_gen.upload_to_wechat(token, cover_path)
        if thumb_media_id:
            print(f"✅ 封面图上传成功，media_id: {thumb_media_id}")
    
    # 3. V5 极致排版
    print("📐 正在执行 V5 极致排版...")
    html = formatter.format(markdown_content)
    
    # 4. 尝试发布到草稿箱
    if thumb_media_id:
        print("📤 正在同步至公众号草稿箱...")
        result = api.publish_to_draft(title, html, thumb_media_id)
        if 'errcode' in result and result['errcode'] == 0:
            print(f"✅ 发布成功！草稿 ID: {result.get('draft_id')}")
        else:
            print(f"⚠️ API 发布失败: {result}")
            print("💡 建议：请检查 IP 白名单或手动复制以下内容到后台。")
            copy_to_clipboard(html)
    else:
        print("⚠️ 由于缺少封面图 media_id，无法调用 API 发布。")
        copy_to_clipboard(html)

if __name__ == "__main__":
    main()
