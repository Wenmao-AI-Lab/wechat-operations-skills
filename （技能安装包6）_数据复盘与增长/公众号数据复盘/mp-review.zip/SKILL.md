---
name: mp-review
description: 引导零技术基础的公众号运营者一次性配置微信公众平台 JSON 凭证，按文章发布日期拉取文章正文和原生指标；先自动建立跨行业账号画像、识别内容类型并确认复盘目标，再调用多个 AI 智能体从可比文章的表现差异中提炼选题、标题、风格和结构规律，生成带评分雷达图、可离线打开的单文件 HTML 数据复盘报告。用于各行业公众号 API 配置、AppID/AppSecret、IP 白名单、文章数据导出、爆文复盘、内容增长复盘、选题优化或写作计划；也支持分析后台导出的 CSV/XLSX。最终报告不得写成文章观点摘要或把内容指标冒充商业转化。
---

# 公众号数据复盘

完成“配置 → 拉取 → 校验 → 多智能体语义分析 → 行动”的闭环。面向小白一次只安排一个操作，用户确认完成后再继续。

## 运行环境适配

- 在  、Codex、Claude Code、Cursor 或其他能访问本地文件和终端的 AI 环境中，由 AI 完成创建配置文件、设置权限、检查 IP、运行脚本和读取报告。不要让非技术用户手动输入本可以代为执行的终端命令。
- 不得询问非技术用户“你的 IP 是多少”，也不得要求用户自行搜索“我的 IP”。必须由 AI 运行 skill 的 `--check-ip` 命令，获取当前真实公网出口 IP 并直接告知用户。
- 用户只负责必须本人完成的网页操作：管理员扫码登录、查看 AppID/AppSecret、确认重置密钥风险、修改 IP 白名单。
- 一次只给用户一个网页操作，说清“点哪里”“应看到什么”“完成后如何回复”。
- 若当前环境不能访问本地文件或终端，再提供可复制的命令，并逐步等待用户返回结果。

## 原则

- 只调用读取接口，不发布、删除、回复或修改公众号内容。
- 使用持久 JSON 保存 AppID 与 AppSecret，不要求用户每次输入。
- 明确告诉用户 JSON 含明文密钥；将真实配置文件加入 `.gitignore` 并设置仅本人可读。不要在对话、报告或日志中展示文件内容。
- 只使用微信接口实际返回的公众号数据，不补造缺失指标，不分析外部业务转化。
- 让脚本负责抓取、清洗、派生率和候选分组；让 AI 智能体负责语义理解。不要用脚本生成的分数替代内容判断。
- 不抓取其他账号，不绕过权限、登录、验证码或反爬机制。官方正文接口无法覆盖时，只允许读取当前账号统计接口返回的 `mp.weixin.qq.com` 公开文章链接。

## 1. 权限分流

先确认：账号类型与认证状态、想按文章发布日期复盘最近 7/14/30 天还是自定义发布日期、主要内容目标。必须向用户说明：这里选的是“哪些发布日期的文章”，不是阅读数据的统计日期。

- 企业主体已认证且具有数据、发布接口权限：走 API 路径。
- 未认证、个人主体、接口返回 `48001`，或日期早于接口存储起点：走后台导出路径。

开始配置前完整读取 [references/setup-guide.md](references/setup-guide.md)。解释指标或错误码时读取 [references/api-and-metrics.md](references/api-and-metrics.md)。

## 2. 一次性创建 JSON 配置

从 [assets/mp-review.config.example.json](assets/mp-review.config.example.json) 创建用户工作目录下的 `mp-review.config.json`，然后只让用户在本地编辑器中填写一次：

```json
{
  "app_id": "公众号 AppID",
  "app_secret": "公众号 AppSecret",
  "default_days": 30,
  "output_dir": "mp-review-output",
  "proxy": "http://127.0.0.1:7897"
}
```

若用户不使用代理，将 `proxy` 设为 `""`。不要让用户把填写后的 JSON 粘贴到对话。创建后执行：

```bash
chmod 600 mp-review.config.json
```

若当前目录是 Git 仓库，确认 `.gitignore` 包含独立一行 `mp-review.config.json`。不要忽略示例模板。

运行命令时，将示例里的 `scripts/...` 解析为当前 skill 目录下脚本的实际绝对路径；配置和输出仍放在用户工作目录，不要把真实密钥写进已安装的 skill 目录。

## 3. 配置公众号后台

逐步引导用户登录 `https://developers.weixin.qq.com/platform`。管理员扫码后，先在“我的业务”选择“公众号”，点进目标公众号；进入后再通过右上角账号入口核对或切换到真正要分析的公众号。必须按 [references/setup-guide.md](references/setup-guide.md) 的小白步骤逐项引导，不要一次把全部步骤丢给用户：

1. 选择“公众号”并进入目标账号，再核对右上角当前公众号名称。
2. 确认账号类型、认证状态和接口权限。
3. 获取 AppID 和 AppSecret，填入本地 JSON。
4. AI 用同一个配置主动获取当前实际公网出口 IP：

```bash
python3 scripts/fetch_wechat_data.py --config mp-review.config.json --check-ip
```

5. AI 把脚本实时返回的 IP 明确显示给用户，再让用户将它加入公众号 IP 白名单。

这一步是 API 正式抓取前的强制门禁：未成功获取并向用户显示实时 IP，不得进入白名单配置或正式抓取。不得使用文档示例 IP、上一次运行的 IP、局域网 IP，或由用户凭记忆提供的 IP。

显示 IP 时必须立即提醒：该 IP 只适用于当前“网络 + 代理开关 + 代理节点”组合。切换 Wi-Fi/有线网、开关代理、切换节点、重启路由器后公网 IP 都可能变化；变化后必须重新运行 `--check-ip` 并更新白名单。检查 IP 和正式抓取必须使用同一配置和同一出口。AppSecret 重置可能影响已有系统，重置前先提醒用户确认。

## 4. 按发布时间拉取数据

优先使用现有 Python；脚本只用标准库，不安装依赖。

```bash
# 发布日期在最近 7 天内的文章
python3 scripts/fetch_wechat_data.py --config mp-review.config.json --days 7

# 发布日期在最近 14 天内的文章
python3 scripts/fetch_wechat_data.py --config mp-review.config.json --days 14

# 发布日期在最近 30 天内的文章
python3 scripts/fetch_wechat_data.py --config mp-review.config.json --days 30

# 自定义文章发布日期范围
python3 scripts/fetch_wechat_data.py --config mp-review.config.json --start 2026-07-01 --end 2026-07-31
```

这里的 7/14/30 天都是文章发布日期范围，不是阅读指标的统计日期。没有传日期时使用 JSON 的 `default_days`。最近 N 天以昨日为结束日，按文章发布时间向前包含 N 个自然日。

正文按以下顺序补全：

1. 已发布文章列表 `freepublish/batchget`；
2. 永久图文素材列表 `material/batchget_material`；
3. 必要时根据 `media_id` 调用 `material/get_material`；
4. 仍缺失时，仅读取统计接口返回的本账号公开文章链接。

脚本输出：

- `wechat_articles.csv`：规范化指标表，包含正文和正文来源；
- `wechat_articles.json`：正文、原始 ID、指标及匹配信息；
- `fetch_report.json`：日期范围、文章数、缺失、延迟与错误摘要。

先检查 `fetch_report.json`，再抽查文章数量、标题、日期、正文匹配和零值比例。缺失值不是 0，数据延迟不是表现差。

## 5. 无 API 权限时接收导出文件

让用户从公众号后台内容分析/图文分析中，按文章发布日期选择最近 7/14/30 天或自定义范围，导出 CSV/XLSX 并提供文件。必须说明这不是阅读指标的统计日期。保留原文件，另生成规范化数据；字段规则见 [references/data-schema.md](references/data-schema.md)。

至少需要标题、发布日期和一个原生效果指标。没有正文时补充文章链接或正文；只有标题时只分析选题与标题，不猜测风格和结构。

## 6. 先建立行业与账号画像

这是分析阶段的第一步，不得先看高低表现文章再倒推账号定位。完整读取 [references/profile-and-content-types.md](references/profile-and-content-types.md)，再执行：

1. 从整批标题、摘要和正文推断行业、账号定位、核心读者、关注动机、现有品牌口吻和可能的合规边界。
2. 为每篇文章标记主要内容类型和可选的次要类型；类型体系可按行业调整，不强制所有账号共用同一组名称。
3. 将结果按参考文件的结构写入输出目录的 `review_profile.json`，为本批每篇文章标记主要内容类型，并先向用户展示简短画像摘要。
4. 只有关键字段未知或明显矛盾时，才向用户提出一个确认问题；不要让用户从空白表格开始填写。
5. 确认本次主要复盘目标：`reach`、`share`、`save`、`completion`、`engagement`、`trust`、`conversion` 或 `balanced`。用户没有明确目标时给出建议并请其确认一次；无法等待时使用 `balanced` 并注明。

医疗、健康、金融、法律、教育、政务等行业只要涉及高风险主张，就在画像中标记“需行业合规复核”。没有咨询、到店、购买、报名等外部数据时，不得选择公众号原生指标作为商业转化证明。

## 7. 按目标准备候选索引

运行：

```bash
python3 scripts/prepare_review.py mp-review-output/wechat_articles.json --profile mp-review-output/review_profile.json --output mp-review-output/review_brief.html
```

脚本读取 `review_profile.json` 中确认的目标和逐篇内容类型，在类型内部准备候选排序，并继续分开展示阅读、分享、收藏和承接候选。需要临时覆盖画像目标时可追加 `--goal <目标键>`。`trust` 和 `conversion` 只能使用代理指标准备候选；最终结论仍需直接数据。

`review_brief.html` 是可离线打开的内部候选索引，只保留标题、指标、正文状态和字符数，不展开摘要或正文观点。正文留在 JSON 中供 AI 按需核验。候选分是同批次相对排序，仅用于缩小 AI 阅读范围，不是最终结论。

控制可比性：先在同一主要内容类型内，比较相近发布时间、统计窗口、推送位置、通知状态和受众阶段的文章。同类型少于 2 篇时不建立高低对照；找不到可比文章时明确写“缺少可比样本”。

## 8. 调用 AI 智能体做语义复盘

开始前完整读取 `review_profile.json`、[references/profile-and-content-types.md](references/profile-and-content-types.md) 和 [references/agent-review.md](references/agent-review.md)。
必须使用其中的统一评分尺：先逐篇独立打分，再比较高低表现组；不得自行改变维度定义或用中间分代替缺失证据。

当智能体工具可用且样本不少于 4 篇时，必须并行调用三个独立智能体：

1. 选题与标题智能体；
2. 风格与结构智能体；
3. 数据质检与反证智能体。

先给它们 `review_profile.json` 和 `review_brief.html`，要求按已确认行业、账号定位、内容类型和目标分析；仅在判断选题、标题兑现、风格或结构时读取 `wechat_articles.json` 中必要正文，不泄露预期答案。正文是内部证据，不是最终报告的摘要素材。等待三者完成后，由主智能体回到原始文章和数据核验、处理分歧并综合输出。

若智能体工具不可用，由主智能体按三个角色依次分析，并明确说明没有使用并行智能体。少于 4 篇时不建立统计好坏组，主智能体逐篇复盘。

## 9. 输出 HTML 行动报告

完整读取 [references/html-report-format.md](references/html-report-format.md)，并以 [assets/final-report-data.example.json](assets/final-report-data.example.json) 为字段模板。最终主要交付物固定为输出目录中的 `公众号数据复盘报告.html`，不得另交付 Markdown 版本。

先将核验后的结论写入输出目录的 `_final_report_data.json`，再运行：

```bash
python3 scripts/render_final_report.py mp-review-output/_final_report_data.json --output mp-review-output/公众号数据复盘报告.html
python3 scripts/validate_report_html.py mp-review-output/公众号数据复盘报告.html --expect-radar
```

仅在数据不足、按规则省略雷达图时，校验命令去掉 `--expect-radar`。校验失败必须修正后重新生成，再将 HTML 文件交给用户。

报告必须是单文件 HTML：样式和雷达图均内嵌，不依赖 CDN、外部字体、图片或 JavaScript，确保非开发人员双击即可查看，也能直接打印或另存为 PDF。

评分可视化必须遵守统一评分尺：至少有 3 个适用维度且存在同类型可比组时，用雷达图比较高位与低位候选组的维度均值；`N/A` 和证据不足不计入均值，并显示每个维度的有效样本数。缺少可比数据时不画雷达图，在数据边界中解释原因，不得虚构分数补图。

用小白能看懂的中文写入 HTML，核心回答“在这个行业、账号定位、内容类型和目标下，下一步应该优先验证什么”：

1. 一句话总览；
2. 数据范围、统计周期与可靠性；
3. 按样本量动态生成高潜选题母题，逐项写清内容类型、目标人群、关注动机、触发场景、内容承诺、推荐角度和置信度；
4. 标题规律：哪些钩子、阅读价值、情绪强度和具体性更适合主要内容类型；
5. 风格与结构打法：只总结类型内有证据的口吻、细节/案例密度、开头方式、篇幅和结尾动作；
6. 按证据量动态生成下一周期选题池，每个选题给 2–3 个标题方向；
7. “继续做、停止做、下次测试”的规则；
8. 两周内容实验计划，每次只改变一个主要变量。

不要逐篇介绍文章讲了什么，也不要复述作者的结论、案例过程或正文观点。先按画像把文章抽象成中性的“人群 + 动机 + 场景 + 内容承诺 + 内容类型 + 表达方式”，再比较可比组。文章标题只作为规律的简短证据索引；每条洞察应使用可比的高低表现证据。找不到可比反例时标记证据不足，不得跨类型强行配对。把观察与解释分开；存在混杂因素时降低置信度，不把相关性写成因果，不承诺一定“爆”。建议数量按 [references/profile-and-content-types.md](references/profile-and-content-types.md) 的样本规则动态调整。

## 失败处理

- 配置文件不存在或 JSON 格式错误：指向具体文件和行列，帮助用户修正。
- `40164`：用同一配置重新检查出口 IP，并更新白名单。
- `40125`：AppSecret 无效；管理员确认或重置后只更新 JSON。
- `40013`：检查 AppID 大小写和空格。
- `48001`：改用后台导出，不反复重试。
- 返回空文章：检查范围是否到昨日、是否确实发表、数据是否延迟。
- 正文无法匹配：先按“已发布列表 → 永久素材 → 单素材详情 → 本账号公开链接”顺序补全；仍失败时保留指标，补充正文后再判断风格与结构。
