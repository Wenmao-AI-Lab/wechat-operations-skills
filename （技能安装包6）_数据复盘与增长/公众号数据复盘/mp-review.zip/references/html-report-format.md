# HTML 最终报告格式

最终用户报告必须通过 `scripts/render_final_report.py` 生成单文件 HTML，不再输出 Markdown 报告。结构化数据示例见 `assets/final-report-data.example.json`。

## 生成流程

1. 将主智能体核验后的结论写入输出目录的 `_final_report_data.json`，字段与示例一致。
2. `radar` 仅使用 `agent-review.md` 中已有的 1–5 分维度，不创建新的综合维度。
3. 运行：

```bash
python3 scripts/render_final_report.py mp-review-output/_final_report_data.json --output mp-review-output/公众号数据复盘报告.html
```

4. 检查 HTML 可打开、必需章节存在、雷达图和数值表一致后，将 `.html` 文件交付给用户。`_final_report_data.json` 是内部中间文件，不作为主要交付物。

有雷达图时运行校验：

```bash
python3 scripts/validate_report_html.py mp-review-output/公众号数据复盘报告.html --expect-radar
```

没有足够数据绘制雷达图时省略 `--expect-radar`。校验失败必须修正后重新生成。

## 雷达图规则

- 只在至少有 3 个适用评分维度、且存在可比组时绘制。
- 每条轴必须直接对应统一评分尺中的一个原始维度；建议一次展示 3–8 个最相关维度，避免标签拥挤。
- 比较组使用同一内容类型、相近统计条件下的高位与低位候选组。不得把不同内容类型混为一条系列。
- 每个值是该组在该维度的有效评分均值，保留 1 位小数；`N/A` 和“证据不足”不计入平均。
- `axes[].sample` 写该轴实际参与平均的评分数。某轴任一比较组没有有效评分时，删除该轴。
- 图下注明：分数只描述文本特征，不证明这些特征导致表现差异。
- 样本少于 4 篇、缺少同类型可比组或有效维度少于 3 个时省略 `radar`，在数据边界中解释原因，不用虚构分数补图。

## 内容与安全要求

- 所有正文内容都写入 HTML，不链接外部 CSS、JavaScript、字体、图片或 CDN；确保离线双击可看。
- 不写逐篇观点摘要，不放连续正文摘录；文章标题只作为证据索引。
- 不把候选分、互动指标或雷达图解释成因果、信任或商业转化。
- 必须保留账号画像、一句话结论、数据边界、高潜选题地图、标题打法、风格与结构、下一批选题、继续/停止/测试和实验计划。
- 数量随样本证据动态缩减；没有证据时明确写“暂无可报告内容”或省略雷达图，不填充模板凑数。
