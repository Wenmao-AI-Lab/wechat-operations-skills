# API 与指标口径

## 使用的读取接口

### 稳定版 access token

`POST https://api.weixin.qq.com/cgi-bin/stable_token`

请求字段为 `grant_type=client_credential`、`appid`、`secret`，默认不强制刷新。token 通常在 7200 秒内有效。不要频繁强刷。

### 文章详细数据

`POST https://api.weixin.qq.com/datacube/getarticletotaldetail?access_token=...`

- 按文章发表日期查询；单次日期范围只能是 1 天。
- `end_date` 最大为昨日。
- 数据存储起始时间为 2025-11-01。
- 每篇文章的统计周期最长 30 天。
- 数据可能延迟，官方建议次日 8 点后拉取前一天数据。
- `detail_list` 是从发表日至各统计日的累计数据，复盘时取最后一个统计日。

关键字段：

| 字段 | 含义 | 复盘用法 |
|---|---|---|
| `read_user` | 阅读人数 | 规模指标 |
| `share_user` | 分享人数 | 分享率 = 分享人数 / 阅读人数 |
| `zaikan_user` | 爱心赞人数 | 在看/爱心赞率 |
| `like_user` | 拇指赞人数 | 点赞率 |
| `comment_count` | 留言条数 | 留言率；不是唯一留言人数 |
| `collection_user` | 微信收藏人数 | 收藏率 |
| `read_subscribe_user` | 阅读后关注人数 | 原生结果字段，默认仅保留数据，不作为本 skill 的转化分析目标 |
| `read_delivery_rate` | 阅读送达率 | 通知推送内容的打开表现 |
| `read_finish_rate` | 阅读完成率 | 内容承接与结构表现 |
| `read_avg_activetime` | 平均阅读时长（分钟） | 深度阅读参考 |
| `praise_money` | 赞赏金额（分） | 价值认同参考 |
| `publish_type` | 0 已通知；1 未开启通知 | 分组控制变量 |

### 已发布文章列表

`POST https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token=...`

用于补齐正文 HTML、摘要、作者、封面等信息。接口返回 `article_id`、`update_time` 和 `content.news_item`。正文匹配优先用规范化链接，其次用标题；标题重复时必须标记低置信度，不可静默误配。

### 永久图文素材回退

已发布文章列表未覆盖目标文章时，调用：

`POST https://api.weixin.qq.com/cgi-bin/material/batchget_material?access_token=...`

请求 `type=news`。列表通常直接返 `item[].content.news_item[].content`。若某条只有 `media_id` 或正文为空，再调用：

`POST https://api.weixin.qq.com/cgi-bin/material/get_material?access_token=...`

请求体为 `{"media_id":"..."}`，从 `news_item[].content` 取得正文。该接口是 `POST`，不是 `GET`。

### 本账号公开文章链接回退

如果上述两类官方正文接口仍无法覆盖某篇文章，但文章详细数据接口已返回该文章的 `content_url`，可仅对 `mp.weixin.qq.com` 的该链接读取公开正文容器 `js_content`。

- 只允许读取当前账号统计接口返回的链接；
- 不接受用户任意输入的网址，不抓取其他账号；
- 遇到验证页、访问异常或正文容器缺失时立即停止，不绕过验证。

## 不能自动假设的指标

- 接口缺失或权限不足时，不要用 0 代替。

## 比较原则

优先比较比率与同批次相对表现，不只看绝对阅读量。阅读量高度受粉丝规模、是否通知、推送位置、发布时间和分发渠道影响。

建议派生：

- 分享率 = `share_user / read_user`
- 收藏率 = `collection_user / read_user`
- 点赞率 = `(zaikan_user + like_user) / read_user`
- 留言率 = `comment_count / read_user`

分母为 0 或字段缺失时结果留空，不得输出 0%。

## 典型错误

| 错误码 | 含义 | 处理 |
|---|---|---|
| 40013 | AppID 不合法 | 检查大小写、空格和账号 |
| 40125 | AppSecret 无效 | 管理员确认或重置 |
| 40164 | IP 不在白名单 | 检查实际出口 IP |
| 48001 | API 未授权 | 确认账号权限，改走后台导出 |
| 45009 | 超过调用额度 | 停止重试，稍后再抓取 |
