# 微信公众号 API 配置指南

## 谁来做什么

在  、Codex、Claude Code、Cursor 等可访问本机的 AI 环境中：

- AI 负责：复制 JSON 模板、打开本地配置文件、设置 `chmod 600`、检查 `.gitignore`、运行 IP 检查和数据抓取命令、解读错误。
- 用户负责：扫码登录微信公众平台、在网页中查看并填写 AppID/AppSecret、修改 IP 白名单。

除非 AI 无终端权限，不要把 Python、`chmod` 或 `.gitignore` 操作交给非技术用户。

## 先确认是否适合 API 路径

截至 2026 年，文章明细、图文分析和留言等关键接口通常要求企业主体已认证账号；具体以该账号“接口权限”页面为准。发布列表接口对已认证公众号和服务号的适用范围不同，个人主体或未认证企业账号可能没有权限。

让用户在后台确认：

- 账号类型：订阅号或服务号；
- 主体与认证：企业主体且认证有效；
- 接口权限：数据分析、发布能力是否可用；
- 目标日期：新明细接口的数据存储从 2025-11-01 开始。

若任何一项不满足，直接采用后台导出文件路径。

## 小白配置步骤

界面名称可能随微信改版变化。不要要求用户盲找固定层级；以“我的业务”“公众号”“开发接口管理”“开发者 ID”“AppID”“AppSecret”“IP 白名单”“接口权限”等页面文字为准。每次只发送下面一步，等用户确认后再继续。

### 第 1 步：登录微信开发者平台

让用户打开 [微信开发者平台](https://developers.weixin.qq.com/platform)，由公众号管理员扫码登录。完成标志：页面显示“我的业务”，并能看到名下的小程序、公众号等业务数量。让用户只回复“已看到我的业务”。

### 第 2 步：选择公众号业务

在“我的业务”中点击“公众号”。页面会显示该管理员名下的公众号。完成标志：看到可选择的公众号列表或直接进入某个公众号。

### 第 3 步：选对并核对目标公众号

让用户点击真正要分析的公众号。进入后，必须查看右上角的当前账号名称或账号切换入口：

- 如果当前名称就是要分析的公众号，确认后继续；
- 如果不是，通过右上角切换到目标公众号；
- 在账号名称未核对前，不得复制 AppID、配置 IP 白名单或抓取数据。

完成标志：用户明确回复“右上角已显示要分析的公众号”。

### 第 4 步：进入“基础信息”

进入目标公众号后，默认查看“基础信息”页。当前界面上方可能显示“基础信息”“开放能力”“接口管理”“绑定关系”“授权关系”等页签。

在“基础信息”中寻找“开发密钥”区域，这里可以操作 AppSecret 和“API IP白名单”。页面上的“原始ID”不是 AppID，不得把以 `gh_` 开头的原始ID填入 `app_id`。

### 第 5 步：确认接口权限

让用户打开“接口管理”页签，查看数据分析、已发布内容和永久素材相关接口是否可用。如果页面明确显示未获得权限，保留其他可用的正文回退路径；如果数据分析接口也不可用，则改用后台导出路径。

### 第 6 步：填写 AppID

让用户找到明确标注为“AppID”的值，复制后粘贴到 AI 已在本地打开的 `mp-review.config.json` 的 `app_id` 引号中。不要要求用户把 AppID 发到对话，也不得用“原始ID”或微信号代替 AppID。

### 第 7 步：填写 AppSecret

让用户找到“开发者密码（AppSecret）”。若后台只有“重置”按钮，先让用户确认是否有其他线上系统正在使用旧密钥；重置会使旧密钥失效。用户将 AppSecret 直接填入本地 JSON 的 `app_secret` 引号中，不粘贴到对话、截图或报告。

### 第 8 步：AI 保护本地配置

AI 确认用户已保存文件后，执行 `chmod 600 mp-review.config.json`，并确认 `.gitignore` 包含独立一行 `mp-review.config.json`。AI 只检查文件存在、JSON 语法和字段是否为空；不输出文件内容。

### 第 9 步：AI 自动获取当前公网 IP（强制）

不要询问用户 IP，不要让用户打开搜索引擎查 IP，也不要复用上次的检查结果。AI 必须在当前机器上，使用正式抓取时的同一份 JSON 主动运行：

```bash
python3 <skill绝对路径>/scripts/fetch_wechat_data.py --config mp-review.config.json --check-ip
```

AI 把命令实时输出的 IPv4 直接显示给用户，同时必须说明：这个 IP 只对当前“网络 + 代理开关 + 代理节点”组合有效。脚本未返回 IP 时立即停止，先排查网络或代理，不允许继续配置白名单。

只有满足下面三项，才能进入第 10 步：

- AI 已在当前机器上运行 `--check-ip`；
- 脚本已返回一个实时公网 IP；
- AI 已把该 IP 显示给用户。

### 第 10 步：填写 IP 白名单

让用户回到“基础信息”的“开发密钥”区域，在“API IP白名单”右侧点击“编辑”，将上一步显示的 IPv4 填入并保存。完成标志：页面不再提示未保存，并能在“API IP白名单”中看到该 IP。

### 第 11 步：用同一出口正式抓取

不更改 JSON 中的 `proxy`，不切换网络或代理节点，直接运行正式抓取。如果已切换 Wi-Fi/有线网、开关代理、更换代理节点或重启路由器，先重复第 9–10 步。

## IP 白名单的常见误区

- 填写的是本机局域网地址（如 `192.168.x.x`），而不是公网出口 IP。
- 检查 IP 时没开代理，抓取时开了代理，导致出口不同。
- 家庭宽带公网 IP 变化后未更新白名单。
- 公司网络有多个出口，前后请求走了不同出口。
- 使用托管函数但没有固定出口 IP。不要默认 Cloudflare Workers、Vercel 等共享无服务器平台能提供可白名单的固定出口。

将白名单中的 IP 视为“当前出口的快照”，不是电脑或公众号的永久身份。每次返回 `40164` 时，都先用同一 JSON 重新运行 `--check-ip`，不要盲目重试。

## 配置文件规则

- AppID、AppSecret、默认时间范围、输出目录和代理持久保存在本机 JSON。
- 配置是明文敏感文件，只允许当前用户读取，并禁止提交到 Git。
- access_token 只保存在进程内存，不写文件。
- 报告中只记录 AppID 的末 4 位（如确有排错需要），绝不记录 AppSecret 或 token。
- 如果用户误发 AppSecret，提醒其立即在公众平台重置。

## 官方资料

- [稳定版接口调用凭据](https://developers.weixin.qq.com/doc/service/api/base/api_getstableaccesstoken.html)
- [获取发表内容发表详细数据](https://developers.weixin.qq.com/doc/service/api/wedata/news/api_getarticletotaldetail.html)
- [获取已发布的消息列表](https://developers.weixin.qq.com/doc/service/api/public/api_freepublish_batchget.html)
- [获取永久素材列表](https://developers.weixin.qq.com/doc/service/api/material/permanent/api_batchgetmaterial.html)
- [获取单个永久素材](https://developers.weixin.qq.com/doc/service/api/material/permanent/api_getmaterial.html)
- [数据统计接口介绍](https://developers.weixin.qq.com/doc/offiaccount/Analytics/Graphic_Analysis_Data_Interface.html)
