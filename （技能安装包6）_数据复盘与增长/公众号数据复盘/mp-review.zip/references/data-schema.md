# 复盘数据规范

## 最小字段

| 规范字段 | 必需 | 常见中文列名 |
|---|---:|---|
| `title` | 是 | 标题、文章标题、图文标题 |
| `publish_date` | 是 | 发表日期、发布日期、群发日期、时间 |
| `read_user` | 至少一个效果指标 | 阅读人数、阅读用户数、阅读量 |
| `content_url` | 否 | 文章链接、原文链接、URL |
| `content_text` | 深度复盘建议 | 正文、文章内容 |
| `content_source` | 否 | 正文来源 |

## 推荐指标字段

`share_user`、`zaikan_user`、`like_user`、`comment_count`、`collection_user`、`read_subscribe_user`、`read_delivery_rate`、`read_finish_rate`、`read_avg_activetime`。

## 规范化规则

- 日期统一为 `YYYY-MM-DD`，时间另存 `publish_time`。
- 人数、次数、金额保留数值；百分数统一为 0–1 小数。
- `--`、空白、`N/A（无数据）` 保留为空值，不转成 0。
- 去重优先使用 `msgid`；没有 ID 时用标题 + 发布日期。
- 保存原始文件，不覆盖；输出 UTF-8 with BOM CSV 便于 Excel 打开。
- API 输出的 JSON 和 CSV 都应包含 `content_text`；`content_source` 用于区分“已发布文章列表”“永久图文素材”和“本账号公开文章链接”。
- 记录每次字段映射与无法识别的列，方便用户复核。

## 数据不足时的输出边界

- 少于 4 篇：逐篇复盘，不划分统计意义上的好坏组。
- 4–7 篇：按上下半区探索性比较，明确小样本。
- 8 篇及以上：可使用上下四分位对照。
- 没有正文：只分析选题和标题，不评价行文结构。
- 没有送达或受众数据：不要把阅读人数差异全部归因于内容。
