#!/usr/bin/env python3
"""将公众号复盘的结构化 JSON 渲染为可离线打开的单文件 HTML 报告。"""

from __future__ import annotations

import argparse
import html
import json
import math
import re
from pathlib import Path
from typing import Any


def esc(value: Any) -> str:
    return html.escape(str(value or ""), quote=True)


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def text_list(items: Any, class_name: str = "bullet-list") -> str:
    values = [item for item in as_list(items) if str(item).strip()]
    if not values:
        return '<p class="muted">暂无可报告内容。</p>'
    return (
        f'<ul class="{class_name}">'
        + "".join(f"<li>{esc(item)}</li>" for item in values)
        + "</ul>"
    )


def field(label: str, value: Any) -> str:
    content = esc(value) if str(value or "").strip() else "—"
    return (
        f'<div class="field"><span>{esc(label)}</span><strong>{content}</strong></div>'
    )


def confidence(value: Any) -> str:
    label = str(value or "未标注")
    tone = "high" if label == "高" else "medium" if label == "中" else "low"
    return f'<span class="confidence {tone}">置信度 · {esc(label)}</span>'


def safe_color(value: Any, fallback: str) -> str:
    color = str(value or "")
    return color if re.fullmatch(r"#[0-9a-fA-F]{6}", color) else fallback


def radar_svg(radar: dict[str, Any]) -> str:
    axes = [axis for axis in as_list(radar.get("axes")) if isinstance(axis, dict)]
    series = [item for item in as_list(radar.get("series")) if isinstance(item, dict)]
    if len(axes) < 3 or not series:
        return ""

    axis_count = len(axes)
    width, height = 760, 570
    cx, cy, radius = 380.0, 270.0, 185.0

    def point(index: int, level: float) -> tuple[float, float]:
        angle = -math.pi / 2 + 2 * math.pi * index / axis_count
        distance = radius * level / 5
        return cx + math.cos(angle) * distance, cy + math.sin(angle) * distance

    rings = []
    for level in range(1, 6):
        coords = " ".join(
            f"{x:.1f},{y:.1f}" for x, y in (point(i, level) for i in range(axis_count))
        )
        rings.append(
            f'<polygon points="{coords}" fill="none" stroke="#d9d7cf" stroke-width="1" />'
        )

    spokes = []
    labels = []
    for index, axis in enumerate(axes):
        x, y = point(index, 5)
        lx, ly = point(index, 6.05)
        anchor = "middle"
        if lx < cx - 20:
            anchor = "end"
        elif lx > cx + 20:
            anchor = "start"
        label = str(axis.get("label") or f"维度 {index + 1}")
        sample = str(axis.get("sample") or "")
        spokes.append(
            f'<line x1="{cx}" y1="{cy}" x2="{x:.1f}" y2="{y:.1f}" stroke="#d9d7cf" stroke-width="1" />'
        )
        labels.append(
            f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="{anchor}" class="axis-label">{esc(label)}</text>'
            + (
                f'<text x="{lx:.1f}" y="{ly + 17:.1f}" text-anchor="{anchor}" class="axis-sample">n={esc(sample)}</text>'
                if sample
                else ""
            )
        )

    palette = ["#176b52", "#d2793d", "#6f5aae", "#2d70a8"]
    polygons = []
    legend = []
    rows = []
    for series_index, item in enumerate(series):
        name = str(item.get("name") or f"系列 {series_index + 1}")
        color = safe_color(item.get("color"), palette[series_index % len(palette)])
        raw_values = as_list(item.get("values"))
        values: list[float] = []
        for axis_index in range(axis_count):
            try:
                value = float(raw_values[axis_index])
            except (IndexError, TypeError, ValueError):
                value = 0.0
            values.append(min(5.0, max(0.0, value)))
        coords = " ".join(
            f"{x:.1f},{y:.1f}"
            for x, y in (point(i, values[i]) for i in range(axis_count))
        )
        polygons.append(
            f'<polygon points="{coords}" fill="{esc(color)}" fill-opacity=".16" '
            f'stroke="{esc(color)}" stroke-width="3" />'
        )
        for index, value in enumerate(values):
            x, y = point(index, value)
            polygons.append(
                f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="{esc(color)}" />'
            )
        legend.append(
            f'<span><i style="background:{esc(color)}"></i>{esc(name)}</span>'
        )
        rows.append(
            f"<tr><th>{esc(name)}</th>"
            + "".join(f"<td>{value:.1f}</td>" for value in values)
            + "</tr>"
        )

    header = "".join(f"<th>{esc(axis.get('label'))}</th>" for axis in axes)
    return f"""
    <section id="radar" class="radar-section">
      <div class="section-heading"><div><p class="eyebrow">SCORE PROFILE</p><h2>{esc(radar.get("title") or "评分维度雷达图")}</h2></div></div>
      <p class="section-intro">{esc(radar.get("note") or "分数仅用于统一描述，不单独构成增长结论。")}</p>
      <div class="radar-layout">
        <figure>
          <svg class="radar" viewBox="0 0 {width} {height}" role="img" aria-labelledby="radar-title radar-desc">
            <title id="radar-title">{esc(radar.get("title") or "评分维度雷达图")}</title>
            <desc id="radar-desc">对比不同候选组在统一 1 至 5 分评分维度上的平均得分。</desc>
            {"".join(rings)}{"".join(spokes)}{"".join(polygons)}{"".join(labels)}
            <text x="{cx + 8}" y="{cy - radius + 14}" class="scale-label">5</text>
            <text x="{cx + 8}" y="{cy - radius / 5 + 4}" class="scale-label">1</text>
          </svg>
          <figcaption class="legend">{"".join(legend)}</figcaption>
        </figure>
        <div class="radar-notes">{text_list(radar.get("insights"))}</div>
      </div>
      <details><summary>查看雷达图数值表</summary><div class="table-wrap"><table><thead><tr><th>组别</th>{header}</tr></thead><tbody>{"".join(rows)}</tbody></table></div></details>
    </section>"""


def topic_map(items: Any) -> str:
    cards = []
    for index, item in enumerate(as_list(items), 1):
        if not isinstance(item, dict):
            continue
        cards.append(
            f"""<article class="opportunity-card">
              <div class="card-top"><span class="rank">{index:02d}</span>{confidence(item.get("confidence"))}</div>
              <h3>{esc(item.get("title") or "未命名机会")}</h3>
              <div class="field-grid">
                {field("内容类型", item.get("content_type"))}{field("目标人群", item.get("audience"))}
                {field("关注动机", item.get("motivation"))}{field("触发场景", item.get("trigger"))}
                {field("内容承诺", item.get("promise"))}{field("主要指标", item.get("metric"))}
              </div>
              <div class="evidence"><p><strong>可比证据</strong>{esc(item.get("evidence") or "证据不足")}</p><p><strong>反例 / 边界</strong>{esc(item.get("counterexample") or "未发现可比反例")}</p></div>
            </article>"""
        )
    return "".join(cards) or '<p class="muted">样本不足，暂不生成高潜选题地图。</p>'


def playbook(items: Any, kind: str) -> str:
    cards = []
    for item in as_list(items):
        if not isinstance(item, dict):
            continue
        if kind == "title":
            body = (
                '<div class="do-dont"><div><h4>推荐</h4>'
                + text_list(item.get("recommended"))
                + "</div><div><h4>避免</h4>"
                + text_list(item.get("avoid"))
                + "</div></div>"
            )
        else:
            body = (
                '<div class="field-grid">'
                + "".join(
                    field(label, item.get(key))
                    for label, key in (
                        ("口吻", "voice"),
                        ("开头", "opening"),
                        ("案例 / 细节", "detail"),
                        ("节奏", "rhythm"),
                        ("篇幅", "length"),
                        ("结尾动作", "ending"),
                    )
                )
                + "</div>"
            )
        cards.append(
            f'<article class="play-card"><p class="tag">{esc(item.get("content_type") or "未分型")}</p>{body}'
            f'<p class="proof"><strong>证据：</strong>{esc(item.get("evidence") or "证据不足")}</p></article>'
        )
    return "".join(cards) or '<p class="muted">暂无可报告内容。</p>'


def next_topics(items: Any) -> str:
    rows = []
    for item in as_list(items):
        if not isinstance(item, dict):
            continue
        titles = "".join(
            f"<li>{esc(title)}</li>" for title in as_list(item.get("titles"))
        )
        rows.append(
            f"<tr><td><strong>{esc(item.get('topic'))}</strong><small>{esc(item.get('content_type'))}</small></td>"
            f"<td>{esc(item.get('metric'))}</td><td><ol>{titles}</ol></td></tr>"
        )
    if not rows:
        return '<p class="muted">样本不足，暂不生成下一批选题清单。</p>'
    return (
        '<div class="table-wrap"><table class="topic-table"><thead><tr><th>选题</th><th>目标指标</th><th>标题方向</th></tr></thead><tbody>'
        + "".join(rows)
        + "</tbody></table></div>"
    )


def experiments(items: Any) -> str:
    cards = []
    for index, item in enumerate(as_list(items), 1):
        if not isinstance(item, dict):
            continue
        cards.append(
            f"""<article class="experiment-card"><span class="step">实验 {index}</span><h3>{esc(item.get("hypothesis"))}</h3>
            <div class="field-grid">{field("时间", item.get("period"))}{field("对照组", item.get("control"))}{field("实验组", item.get("variant"))}{field("直接指标", item.get("metric"))}{field("统计窗口", item.get("window"))}</div></article>"""
        )
    return "".join(cards) or '<p class="muted">暂无可执行实验。</p>'


def render(data: dict[str, Any]) -> str:
    profile = as_dict(data.get("profile"))
    boundary = as_dict(data.get("data_boundary"))
    actions = as_dict(data.get("actions"))
    metadata = as_dict(data.get("meta"))
    stats = [item for item in as_list(boundary.get("stats")) if isinstance(item, dict)]
    stat_html = "".join(
        f'<div class="hero-stat"><span>{esc(item.get("label"))}</span><strong>{esc(item.get("value"))}</strong></div>'
        for item in stats[:4]
    )
    profile_items = "".join(
        field(label, profile.get(key))
        for label, key in (
            ("行业", "industry"),
            ("账号定位", "positioning"),
            ("核心读者", "audience"),
            ("关注动机", "motivations"),
            ("主要内容类型", "content_types"),
            ("本次目标", "goal"),
        )
    )
    radar = radar_svg(as_dict(data.get("radar")))
    caveats = text_list(boundary.get("caveats"))
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(metadata.get("title") or "公众号数据复盘报告")}</title>
<style>
:root{{--ink:#14221d;--muted:#66736d;--paper:#f4f0e7;--card:#fffdf8;--line:#ded8cb;--green:#176b52;--green2:#0f4939;--mint:#dfeee6;--amber:#cb7940;--red:#a64b42;--purple:#6f5aae}}
*{{box-sizing:border-box}}html{{scroll-behavior:smooth}}body{{margin:0;color:var(--ink);background:var(--paper);font:15px/1.68 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}}main{{width:min(1140px,calc(100% - 32px));margin:28px auto 72px}}.hero{{position:relative;overflow:hidden;padding:54px;border-radius:28px;color:#f7f4ec;background:linear-gradient(135deg,#0e2921,#176b52 66%,#b66d38);box-shadow:0 24px 70px #193a2e29}}.hero:after{{content:"";position:absolute;right:-90px;top:-120px;width:360px;height:360px;border:1px solid #ffffff25;border-radius:50%;box-shadow:0 0 0 55px #ffffff0a,0 0 0 110px #ffffff08}}.eyebrow{{margin:0 0 9px;color:#85ae9c;font-size:11px;font-weight:800;letter-spacing:.18em}}.hero .eyebrow{{color:#b9d9ca}}h1{{position:relative;z-index:1;max-width:820px;margin:0;font-size:clamp(34px,5.7vw,66px);line-height:1.03;letter-spacing:-.045em}}.hero-sub{{position:relative;z-index:1;max-width:780px;margin:18px 0 0;color:#d5e4dd;font-size:17px}}.hero-meta{{position:relative;z-index:1;margin:9px 0 0;color:#a9c8ba;font-size:12px}}.hero-stats{{position:relative;z-index:1;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:30px}}.hero-stat{{padding:15px 17px;border:1px solid #ffffff24;border-radius:15px;background:#ffffff10}}.hero-stat span{{display:block;color:#b9cec5;font-size:11px}}.hero-stat strong{{display:block;margin-top:3px;font-size:19px}}section{{margin-top:17px;padding:30px;border:1px solid var(--line);border-radius:22px;background:var(--card);box-shadow:0 10px 35px #29392f10}}.section-heading{{display:flex;align-items:flex-end;justify-content:space-between;gap:20px}}h2{{margin:0;font-size:27px;line-height:1.2;letter-spacing:-.025em}}h3{{margin:0 0 12px;font-size:19px;line-height:1.35}}h4{{margin:0 0 8px;font-size:13px}}.section-intro,.muted{{color:var(--muted)}}.lead{{margin:14px 0 0;padding:20px 22px;border-left:5px solid var(--amber);border-radius:12px;background:#fff2df;font-size:18px;font-weight:650}}.field-grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}.field{{padding:13px 15px;border:1px solid #e7e2d6;border-radius:12px;background:#fff}}.field span{{display:block;color:var(--muted);font-size:11px;font-weight:750}}.field strong{{display:block;margin-top:3px;font-size:14px}}.boundary-grid{{display:grid;grid-template-columns:1.1fr .9fr;gap:18px}}.callout{{padding:18px;border-radius:14px;background:#eef5f1}}.bullet-list{{margin:0;padding-left:1.25em}}.bullet-list li+li{{margin-top:7px}}.opportunity-grid,.play-grid,.experiment-grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}}.opportunity-card,.play-card,.experiment-card{{padding:22px;border:1px solid var(--line);border-radius:16px;background:#fff}}.card-top{{display:flex;justify-content:space-between;align-items:center;margin-bottom:13px}}.rank{{color:#b6b1a5;font:800 22px/1 ui-monospace,SFMono-Regular,Menlo,monospace}}.confidence,.tag,.step{{display:inline-block;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:750}}.confidence.high{{color:var(--green);background:var(--mint)}}.confidence.medium{{color:#8b571e;background:#f9e8cf}}.confidence.low{{color:var(--red);background:#f7dfdb}}.evidence{{margin-top:14px;padding-top:11px;border-top:1px solid var(--line);color:var(--muted);font-size:13px}}.evidence p{{margin:7px 0}}.evidence strong{{display:block;color:var(--ink)}}.tag,.step{{margin:0 0 13px;color:var(--green);background:var(--mint)}}.do-dont{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}.do-dont>div{{padding:14px;border-radius:12px;background:#f5f5f0}}.proof{{margin:14px 0 0;color:var(--muted);font-size:13px}}.radar-layout{{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(260px,.65fr);gap:16px;align-items:center}}figure{{margin:0}}.radar{{display:block;width:100%;height:auto;max-height:570px}}.axis-label{{fill:var(--ink);font-size:13px;font-weight:650}}.axis-sample,.scale-label{{fill:#929b96;font-size:10px}}.legend{{display:flex;flex-wrap:wrap;justify-content:center;gap:16px;color:var(--muted);font-size:12px}}.legend span{{display:inline-flex;align-items:center;gap:6px}}.legend i{{width:18px;height:4px;border-radius:5px}}.radar-notes{{padding:20px;border-radius:14px;background:#f2f5f2}}details{{margin-top:12px}}summary{{cursor:pointer;color:var(--green);font-weight:700}}.table-wrap{{margin-top:12px;overflow:auto;border:1px solid var(--line);border-radius:14px}}table{{width:100%;border-collapse:collapse;background:#fff}}th,td{{padding:12px 13px;border-bottom:1px solid #ece7dc;text-align:left;vertical-align:top}}th{{color:var(--muted);background:#f6f4ee;font-size:12px}}tr:last-child td{{border-bottom:0}}.topic-table td:first-child{{min-width:220px}}.topic-table small{{display:block;color:var(--muted);margin-top:4px}}.topic-table ol{{margin:0;padding-left:1.2em}}.actions{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}}.action-card{{padding:19px;border-radius:15px}}.action-card.keep{{background:#e7f2ec}}.action-card.stop{{background:#f7e8e4}}.action-card.test{{background:#f8eedb}}.experiment-card h3{{min-height:52px}}footer{{margin-top:24px;color:var(--muted);font-size:12px;text-align:center}}
@media(max-width:780px){{main{{width:min(100% - 20px,1140px);margin-top:10px}}.hero,section{{padding:23px;border-radius:17px}}.hero-stats,.field-grid,.boundary-grid,.opportunity-grid,.play-grid,.experiment-grid,.actions,.radar-layout{{grid-template-columns:1fr}}.do-dont{{grid-template-columns:1fr}}h1{{font-size:38px}}}}
@media print{{body{{background:#fff}}main{{width:100%;margin:0}}.hero{{color:var(--ink);background:#fff;border:1px solid var(--line);box-shadow:none}}.hero-sub,.hero-meta,.hero .eyebrow{{color:var(--muted)}}section{{box-shadow:none;break-inside:avoid}}.opportunity-card,.play-card,.experiment-card{{break-inside:avoid}}details{{display:block}}}}
</style></head><body><main>
<header class="hero"><p class="eyebrow">WECHAT CONTENT REVIEW</p><h1>{esc(metadata.get("title") or "公众号数据复盘报告")}</h1><p class="hero-sub">{esc(metadata.get("subtitle") or "从同类型可比文章中提炼下一步值得验证的内容机会。")}</p><p class="hero-meta">{esc(metadata.get("account_name"))} · {esc(metadata.get("report_period"))} · {esc(metadata.get("generated_at"))}</p><div class="hero-stats">{stat_html}</div></header>
<section id="profile"><p class="eyebrow">ACCOUNT PROFILE</p><h2>账号画像与本次目标</h2><div class="field-grid" style="margin-top:16px">{profile_items}</div><p class="muted">仍未知的边界：{esc(profile.get("unknowns") or "无")}</p></section>
<section id="summary"><p class="eyebrow">ONE-LINE TAKEAWAY</p><h2>一句话结论</h2><p class="lead">{esc(data.get("one_sentence") or "当前证据不足，建议先补充可比样本。")}</p></section>
<section id="boundary"><p class="eyebrow">DATA BOUNDARY</p><h2>数据边界</h2><div class="boundary-grid" style="margin-top:16px"><div><p>{esc(boundary.get("summary"))}</p></div><div class="callout">{caveats}</div></div></section>
{radar}
<section id="opportunities"><p class="eyebrow">OPPORTUNITY MAP</p><h2>高潜选题地图</h2><p class="section-intro">只保留同类型可比证据能够支撑的方向。</p><div class="opportunity-grid">{topic_map(data.get("topic_map"))}</div></section>
<section id="titles"><p class="eyebrow">TITLE PLAYBOOK</p><h2>标题打法</h2><div class="play-grid" style="margin-top:16px">{playbook(data.get("title_playbook"), "title")}</div></section>
<section id="style"><p class="eyebrow">STYLE & STRUCTURE</p><h2>风格与结构打法</h2><div class="play-grid" style="margin-top:16px">{playbook(data.get("style_structure"), "style")}</div></section>
<section id="topics"><p class="eyebrow">NEXT TOPICS</p><h2>下一批选题清单</h2>{next_topics(data.get("next_topics"))}</section>
<section id="actions"><p class="eyebrow">DECISION RULES</p><h2>继续 / 停止 / 测试</h2><div class="actions" style="margin-top:16px"><article class="action-card keep"><h3>继续</h3>{text_list(actions.get("continue"))}</article><article class="action-card stop"><h3>停止</h3>{text_list(actions.get("stop"))}</article><article class="action-card test"><h3>测试</h3>{text_list(actions.get("test"))}</article></div></section>
<section id="experiments"><p class="eyebrow">EXPERIMENT PLAN</p><h2>两周内容实验计划</h2><p class="section-intro">每次只改变一个主要变量，并使用直接指标判断。</p><div class="experiment-grid">{experiments(data.get("experiments"))}</div></section>
<footer>本报告由 mp-review 生成。相关性不等于因果，所有“高潜”均指本批样本中的待验证方向。</footer>
</main></body></html>"""


def main() -> int:
    parser = argparse.ArgumentParser(description="将公众号复盘 JSON 渲染为单文件 HTML")
    parser.add_argument("input", type=Path, help="结构化最终报告 JSON")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("公众号数据复盘报告.html"),
        help="HTML 输出路径",
    )
    args = parser.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8"))
    except FileNotFoundError:
        parser.error(f"找不到输入文件：{args.input}")
    except json.JSONDecodeError as exc:
        parser.error(f"输入 JSON 无效：第 {exc.lineno} 行第 {exc.colno} 列")
    if not isinstance(data, dict):
        parser.error("输入 JSON 顶层必须是对象")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render(data), encoding="utf-8")
    print(f"已生成：{args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
