#!/usr/bin/env python3
"""检查 mp-review HTML 是否可离线打开且包含最终报告必需结构。"""

from __future__ import annotations

import argparse
import re
from html.parser import HTMLParser
from pathlib import Path

REQUIRED_IDS = {
    "profile",
    "summary",
    "boundary",
    "opportunities",
    "titles",
    "style",
    "topics",
    "actions",
    "experiments",
}


class ReportParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: set[str] = set()
        self.tags: set[str] = set()
        self.external_refs: list[str] = []
        self.lang = ""
        self.has_charset = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.tags.add(tag)
        values = dict(attrs)
        if tag == "html":
            self.lang = values.get("lang") or ""
        if tag == "meta" and (values.get("charset") or "").lower() == "utf-8":
            self.has_charset = True
        if values.get("id"):
            self.ids.add(str(values["id"]))
        for key in ("src", "href"):
            value = values.get(key) or ""
            if re.match(r"^(?:https?:)?//", value, re.IGNORECASE):
                self.external_refs.append(value)


def main() -> int:
    parser = argparse.ArgumentParser(description="校验 mp-review 最终 HTML 报告")
    parser.add_argument("input", type=Path, help="待校验的 HTML 文件")
    parser.add_argument(
        "--expect-radar",
        action="store_true",
        help="要求报告包含内嵌 SVG 雷达图和数值表",
    )
    args = parser.parse_args()
    try:
        source = args.input.read_text(encoding="utf-8")
    except FileNotFoundError:
        parser.error(f"找不到文件：{args.input}")

    report = ReportParser()
    report.feed(source)
    errors: list[str] = []
    if not source.lstrip().lower().startswith("<!doctype html>"):
        errors.append("缺少 HTML5 doctype")
    if report.lang != "zh-CN":
        errors.append("html lang 必须是 zh-CN")
    if not report.has_charset:
        errors.append("缺少 UTF-8 charset")
    if "style" not in report.tags:
        errors.append("缺少内嵌样式")
    missing = sorted(REQUIRED_IDS - report.ids)
    if missing:
        errors.append("缺少必需章节：" + "、".join(missing))
    if report.external_refs:
        errors.append("存在外部资源引用：" + "、".join(report.external_refs))
    if re.search(r"(?:@import|url\()\s*['\"]?(?:https?:)?//", source, re.IGNORECASE):
        errors.append("内嵌样式中存在外部资源引用")
    if args.expect_radar:
        if "radar" not in report.ids or "svg" not in report.tags:
            errors.append("缺少内嵌 SVG 雷达图")
        if "查看雷达图数值表" not in source:
            errors.append("缺少雷达图数值表")
    if "```" in source or re.search(r"(?m)^#{1,6}\s", source):
        errors.append("HTML 中残留 Markdown 语法")

    if errors:
        for error in errors:
            print(f"错误：{error}")
        return 1
    print(f"校验通过：{args.input.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
