#!/usr/bin/env python3
"""使用本地 JSON 凭证读取微信公众号文章和指标。

仅使用 Python 标准库。凭证文件始终保留在本地，不会输出到终端或报告。
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import ssl
import sys
import time
from datetime import date, datetime, timedelta
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, ClassVar
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from urllib.request import HTTPSHandler, ProxyHandler, Request, build_opener

API_ROOT = "https://api.weixin.qq.com"
DETAIL_START_DATE = date(2025, 11, 1)
MAX_ARTICLE_HTML_BYTES = 8 * 1024 * 1024
METRIC_FIELDS = [
    "read_user",
    "share_user",
    "zaikan_user",
    "like_user",
    "comment_count",
    "collection_user",
    "praise_money",
    "read_subscribe_user",
    "read_delivery_rate",
    "read_finish_rate",
    "read_avg_activetime",
]


def translate_cli_error(message: str) -> str:
    """将 argparse 常见英文错误转换为中文。"""
    replacements = (
        ("the following arguments are required:", "缺少必填参数："),
        ("unrecognized arguments:", "无法识别的参数："),
        ("expected one argument", "需要一个值"),
        ("invalid choice:", "值无效："),
        ("choose from", "可选值为"),
        ("invalid int value:", "必须是整数："),
        ("not allowed with argument", "不能与以下参数同时使用："),
        ("argument ", "参数 "),
    )
    for source, target in replacements:
        message = message.replace(source, target)
    return message


class ChineseArgumentParser(argparse.ArgumentParser):
    """使命令行帮助标题和错误前缀统一使用中文。"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs["add_help"] = False
        super().__init__(*args, **kwargs)
        self._positionals.title = "位置参数"
        self._optionals.title = "选项"
        self.add_argument("-h", "--help", action="help", help="显示帮助信息并退出")

    def format_usage(self) -> str:
        return super().format_usage().replace("usage:", "用法：", 1)

    def format_help(self) -> str:
        return super().format_help().replace("usage:", "用法：", 1)

    def error(self, message: str) -> None:
        self.print_usage(sys.stderr)
        self.exit(2, f"{self.prog}：错误：{translate_cli_error(message)}\n")


def load_config(path: Path, required: bool = True) -> dict[str, Any]:
    if not path.exists():
        if required:
            raise RuntimeError(
                f"找不到配置文件：{path}。请复制 assets/mp-review.config.example.json "
                "为 mp-review.config.json，填写后再运行。"
            )
        return {}
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"配置文件不是有效 JSON：第 {exc.lineno} 行第 {exc.colno} 列"
        ) from exc
    if not isinstance(config, dict):
        raise TypeError("配置文件顶层必须是 JSON 对象")
    return config


class TextExtractor(HTMLParser):
    BLOCKS: ClassVar[set[str]] = {
        "p",
        "div",
        "section",
        "article",
        "h1",
        "h2",
        "h3",
        "h4",
        "li",
        "blockquote",
        "br",
    }

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.skip = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style"}:
            self.skip += 1
        if not self.skip and tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style"} and self.skip:
            self.skip -= 1
        if not self.skip and tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self.skip:
            self.parts.append(data)

    def text(self) -> str:
        value = unescape("".join(self.parts)).replace("\xa0", " ")
        value = re.sub(r"[ \t]+", " ", value)
        value = re.sub(r"\n\s*\n+", "\n\n", value)
        return value.strip()


class WeChatArticleExtractor(TextExtractor):
    """仅提取公众号页面 `js_content` 容器内的正文。"""

    def __init__(self) -> None:
        super().__init__()
        self.capture_depth = 0
        self.found = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        if not self.capture_depth:
            if tag == "div" and attributes.get("id") == "js_content":
                self.capture_depth = 1
                self.found = True
            return
        if tag == "div":
            self.capture_depth += 1
        super().handle_starttag(tag, attrs)

    def handle_endtag(self, tag: str) -> None:
        if not self.capture_depth:
            return
        super().handle_endtag(tag)
        if tag == "div":
            self.capture_depth -= 1

    def handle_data(self, data: str) -> None:
        if self.capture_depth:
            super().handle_data(data)


def html_to_text(value: str | None) -> str:
    if not value:
        return ""
    parser = TextExtractor()
    parser.feed(value)
    return parser.text()


def wechat_page_to_text(value: str) -> str:
    parser = WeChatArticleExtractor()
    parser.feed(value)
    if not parser.found:
        return ""
    return parser.text()


def normalized_url(value: str | None) -> str:
    if not value:
        return ""
    try:
        parts = urlsplit(value.strip())
        query = parse_qsl(parts.query, keep_blank_values=True)
        if parts.netloc.lower().endswith("weixin.qq.com"):
            # These parameters identify a WeChat article. Dropping the full
            # query would collapse every /s link into the same URL.
            keep = {"__biz", "mid", "idx", "sn"}
            query = [(key, val) for key, val in query if key in keep]
        else:
            query = [
                (key, val) for key, val in query if not key.lower().startswith("utm_")
            ]
        query.sort()
        return urlunsplit(
            (
                parts.scheme.lower(),
                parts.netloc.lower(),
                parts.path,
                urlencode(query),
                "",
            )
        )
    except ValueError:
        return value.strip()


def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("日期必须是 YYYY-MM-DD") from exc


def dates_between(start: date, end: date):
    cursor = start
    while cursor <= end:
        yield cursor
        cursor += timedelta(days=1)


def metric_rate(detail: dict[str, Any], read: Any, numerator: str) -> float | None:
    value = detail.get(numerator)
    if (
        not isinstance(read, (int, float))
        or read <= 0
        or not isinstance(value, (int, float))
    ):
        return None
    return value / read


class WeChatClient:
    def __init__(self, proxy: str | None = None, timeout: int = 30) -> None:
        handlers: list[Any] = []
        if proxy:
            handlers.append(ProxyHandler({"http": proxy, "https": proxy}))
        handlers.append(HTTPSHandler(context=ssl.create_default_context()))
        self.opener = build_opener(*handlers)
        self.timeout = timeout

    def request_json(
        self, url: str, payload: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        data = (
            None
            if payload is None
            else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        )
        request = Request(
            url,
            data=data,
            headers={"Content-Type": "application/json", "User-Agent": "mp-review/1.0"},
        )
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8")
        except HTTPError as exc:
            raise RuntimeError(f"HTTP {exc.code}: {exc.reason}") from exc
        except URLError as exc:
            raise RuntimeError(f"网络连接失败: {exc.reason}") from exc
        try:
            result = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError("接口未返回 JSON；请检查网络或代理") from exc
        if isinstance(result, dict) and result.get("errcode") not in (None, 0):
            code = result.get("errcode")
            message = result.get("errmsg", "未知错误")
            hints = {
                40013: "检查 AppID 大小写和多余空格。",
                40125: "AppSecret 无效，请由管理员确认或重置。",
                40164: "当前出口 IP 不在白名单；先运行 --check-ip。",
                48001: "账号没有该接口权限，请改用后台导出。",
                45009: "接口调用超过额度，请停止重试并稍后再试。",
            }
            raise RuntimeError(
                f"微信接口错误 {code}: {message} {hints.get(code, '')}".strip()
            )
        return result

    def public_ip(self) -> str:
        result = self.request_json("https://api.ipify.org?format=json")
        return str(result.get("ip", "未知"))

    def stable_token(self, appid: str, secret: str) -> str:
        result = self.request_json(
            f"{API_ROOT}/cgi-bin/stable_token",
            {
                "grant_type": "client_credential",
                "appid": appid,
                "secret": secret,
                "force_refresh": False,
            },
        )
        token = result.get("access_token")
        if not token:
            raise RuntimeError("接口没有返回 access_token")
        return str(token)

    def article_details(self, token: str, day: date) -> dict[str, Any]:
        stamp = day.isoformat()
        return self.request_json(
            f"{API_ROOT}/datacube/getarticletotaldetail?access_token={token}",
            {"begin_date": stamp, "end_date": stamp},
        )

    def published_articles(self, token: str, limit: int) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        offset = 0
        while len(items) < limit:
            count = min(20, limit - len(items))
            result = self.request_json(
                f"{API_ROOT}/cgi-bin/freepublish/batchget?access_token={token}",
                {"offset": offset, "count": count, "no_content": 0},
            )
            batch = result.get("item") or []
            if not isinstance(batch, list):
                break
            items.extend(batch)
            offset += len(batch)
            total = int(result.get("total_count") or len(items))
            if not batch or offset >= total:
                break
            time.sleep(0.05)
        return items

    def permanent_materials(self, token: str, limit: int) -> list[dict[str, Any]]:
        """分页读取永久图文素材列表。"""
        items: list[dict[str, Any]] = []
        offset = 0
        while len(items) < limit:
            count = min(20, limit - len(items))
            result = self.request_json(
                f"{API_ROOT}/cgi-bin/material/batchget_material?access_token={token}",
                {"type": "news", "offset": offset, "count": count},
            )
            batch = result.get("item") or []
            if not isinstance(batch, list):
                break
            items.extend(batch)
            offset += len(batch)
            total = int(result.get("total_count") or len(items))
            if not batch or offset >= total:
                break
            time.sleep(0.05)
        return items

    def permanent_material(self, token: str, media_id: str) -> dict[str, Any]:
        """根据 media_id 读取单个永久素材详情。"""
        return self.request_json(
            f"{API_ROOT}/cgi-bin/material/get_material?access_token={token}",
            {"media_id": media_id},
        )

    def public_article_text(self, url: str) -> str:
        """从统计接口返回的本账号公开文章链接中提取正文。"""
        try:
            parts = urlsplit(url)
            host = (parts.hostname or "").lower()
        except ValueError as exc:
            raise RuntimeError("文章链接格式无效") from exc
        if (
            parts.scheme not in {"http", "https"}
            or host != "mp.weixin.qq.com"
            or parts.username
            or parts.password
            or parts.port is not None
        ):
            raise RuntimeError("只允许读取统计接口返回的微信文章链接")
        # 统计接口可能仍返回 http 旧链接；实际请求前主动升级为 HTTPS。
        safe_url = urlunsplit(("https", parts.netloc, parts.path, parts.query, ""))
        request = Request(
            safe_url,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                    "AppleWebKit/537.36 Chrome/124 Safari/537.36"
                ),
                "Accept-Language": "zh-CN,zh;q=0.9",
            },
        )
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                final_parts = urlsplit(response.geturl())
                if (
                    final_parts.scheme != "https"
                    or (final_parts.hostname or "").lower() != "mp.weixin.qq.com"
                ):
                    raise RuntimeError("文章链接跳转到了非微信域名，已停止读取")
                raw_bytes = response.read(MAX_ARTICLE_HTML_BYTES + 1)
                charset = response.headers.get_content_charset() or "utf-8"
        except HTTPError as exc:
            raise RuntimeError(f"文章页读取失败：HTTP {exc.code}") from exc
        except URLError as exc:
            raise RuntimeError(f"文章页网络连接失败：{exc.reason}") from exc
        if len(raw_bytes) > MAX_ARTICLE_HTML_BYTES:
            raise RuntimeError("文章页超过 8 MB 安全限制")
        raw = raw_bytes.decode(charset, errors="replace")
        if any(
            marker in raw for marker in ("环境异常", "访问过于频繁", "请输入验证码")
        ):
            raise RuntimeError("微信返回了访问验证页，已停止继续请求")
        content = wechat_page_to_text(raw)
        if not content:
            raise RuntimeError("文章页未找到正文容器")
        return content


def flatten_published(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for parent in items:
        content = parent.get("content") or {}
        for index, article in enumerate(content.get("news_item") or []):
            row = dict(article)
            row["article_id"] = parent.get("article_id")
            row["article_index"] = index
            row["update_time"] = parent.get("update_time")
            row["content_text"] = html_to_text(row.get("content"))
            row["content_source"] = "已发布文章列表"
            result.append(row)
    return result


def flatten_materials(
    client: WeChatClient, token: str, items: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """展开永久图文素材；列表缺少正文时再逐个读取详情。"""
    result: list[dict[str, Any]] = []
    for parent in items:
        media_id = str(parent.get("media_id") or "")
        articles = (parent.get("content") or {}).get("news_item") or []
        needs_detail = not articles or any(
            not str(article.get("content") or "").strip() for article in articles
        )
        if media_id and needs_detail:
            detail = client.permanent_material(token, media_id)
            detail_articles = detail.get("news_item") or []
            if isinstance(detail_articles, list) and detail_articles:
                articles = detail_articles
            time.sleep(0.05)
        for index, article in enumerate(articles):
            row = dict(article)
            row["media_id"] = media_id
            row["article_index"] = index
            row["update_time"] = parent.get("update_time")
            row["content_text"] = html_to_text(row.get("content"))
            row["content_source"] = "永久图文素材"
            result.append(row)
    return result


def latest_detail(article: dict[str, Any]) -> dict[str, Any]:
    details = article.get("detail_list") or []
    if not details:
        return {}
    return max(details, key=lambda item: str(item.get("stat_date") or ""))


def build_content_indexes(items: list[dict[str, Any]]):
    by_url: dict[str, list[dict[str, Any]]] = {}
    by_title: dict[str, list[dict[str, Any]]] = {}
    for item in items:
        if not str(item.get("content_text") or "").strip():
            continue
        url = normalized_url(item.get("url") or item.get("content_url"))
        title = str(item.get("title") or "").strip()
        if url:
            by_url.setdefault(url, []).append(item)
        if title:
            by_title.setdefault(title, []).append(item)
    return by_url, by_title


def find_content(
    title: str,
    url: str,
    published_indexes: tuple[
        dict[str, list[dict[str, Any]]], dict[str, list[dict[str, Any]]]
    ],
    material_indexes: tuple[
        dict[str, list[dict[str, Any]]], dict[str, list[dict[str, Any]]]
    ],
) -> tuple[dict[str, Any], str]:
    """链接匹配优先于标题，已发布列表优先于永久素材。"""
    published_by_url, published_by_title = published_indexes
    material_by_url, material_by_title = material_indexes
    normalized = normalized_url(url)
    attempts = [
        (published_by_url, normalized, "url"),
        (material_by_url, normalized, "url"),
        (published_by_title, title, "title"),
        (material_by_title, title, "title"),
    ]
    ambiguous = False
    for index, key, match_type in attempts:
        if not key:
            continue
        candidates = index.get(key, [])
        if len(candidates) == 1:
            return candidates[0], match_type
        if len(candidates) > 1:
            ambiguous = True
    return {}, "ambiguous" if ambiguous else "missing"


def normalize_articles(
    raw: list[dict[str, Any]],
    published: list[dict[str, Any]],
    materials: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    published_indexes = build_content_indexes(published)
    material_indexes = build_content_indexes(materials or [])
    rows: list[dict[str, Any]] = []
    for article in raw:
        detail = latest_detail(article)
        title = str(article.get("title") or "").strip()
        url = str(article.get("content_url") or "")
        content, confidence = find_content(
            title, url, published_indexes, material_indexes
        )
        read = detail.get("read_user")
        row: dict[str, Any] = {
            "publish_date": article.get("ref_date"),
            "stat_date": detail.get("stat_date"),
            "msgid": article.get("msgid"),
            "publish_type": article.get("publish_type"),
            "title": title,
            "content_url": url,
            "author": content.get("author"),
            "digest": content.get("digest"),
            "content_text": content.get("content_text") or "",
            "content_match": confidence,
            "content_source": content.get("content_source") or "",
            "data_delayed": article.get("_is_delay", False),
            "read_user_source": detail.get("read_user_source"),
            "read_jump_position": detail.get("read_jump_position"),
        }
        for field in METRIC_FIELDS:
            row[field] = detail.get(field)
        like_values = [
            value
            for value in (detail.get("zaikan_user"), detail.get("like_user"))
            if isinstance(value, (int, float))
        ]
        row.update(
            {
                "share_rate": metric_rate(detail, read, "share_user"),
                "collection_rate": metric_rate(detail, read, "collection_user"),
                "like_rate": sum(like_values) / read
                if like_values and isinstance(read, (int, float)) and read > 0
                else None,
                "comment_rate": metric_rate(detail, read, "comment_count"),
            }
        )
        rows.append(row)
    rows.sort(
        key=lambda item: (
            str(item.get("publish_date") or ""),
            str(item.get("title") or ""),
        ),
        reverse=True,
    )
    return rows


def fill_content_from_public_urls(
    client: WeChatClient, rows: list[dict[str, Any]]
) -> list[str]:
    """仅对正文缺失的本账号文章使用官方返回的公开链接补全。"""
    errors: list[str] = []
    for row in rows:
        if str(row.get("content_text") or "").strip():
            continue
        url = str(row.get("content_url") or "").strip()
        if not url:
            errors.append(f"{row.get('title') or '未命名文章'}：缺少文章链接")
            continue
        try:
            row["content_text"] = client.public_article_text(url)
            row["content_match"] = "url"
            row["content_source"] = "本账号公开文章链接"
        except RuntimeError as exc:
            errors.append(f"{row.get('title') or '未命名文章'}：{exc}")
            if "访问验证页" in str(exc):
                break
        time.sleep(0.2)
    return errors


def write_outputs(
    output: Path, rows: list[dict[str, Any]], report: dict[str, Any]
) -> None:
    output.mkdir(parents=True, exist_ok=True)
    json_path = output / "wechat_articles.json"
    json_path.write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    csv_fields = [
        "publish_date",
        "stat_date",
        "msgid",
        "publish_type",
        "title",
        "content_url",
        "author",
        "digest",
        "content_text",
        "content_source",
        *METRIC_FIELDS,
        "share_rate",
        "collection_rate",
        "like_rate",
        "comment_rate",
        "content_match",
        "data_delayed",
    ]
    with (output / "wechat_articles.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=csv_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    (output / "fetch_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def main() -> int:
    yesterday = datetime.now().astimezone().date() - timedelta(days=1)
    parser = ChineseArgumentParser(
        description="安全拉取微信公众号文章数据（零第三方依赖）"
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("mp-review.config.json"),
        metavar="配置文件",
        help="持久配置文件",
    )
    parser.add_argument(
        "--days",
        type=int,
        choices=(7, 14, 30),
        metavar="天数",
        help="按文章发布日期读取最近 7、14 或 30 天",
    )
    parser.add_argument(
        "--start",
        type=parse_date,
        metavar="起始日期",
        help="自定义文章发表起始日 YYYY-MM-DD，需与 --end 同时使用",
    )
    parser.add_argument(
        "--end",
        type=parse_date,
        metavar="结束日期",
        help="自定义文章发表结束日 YYYY-MM-DD，需与 --start 同时使用",
    )
    parser.add_argument(
        "--output",
        type=Path,
        metavar="输出目录",
        help="输出目录；默认读取配置文件 output_dir",
    )
    parser.add_argument(
        "--proxy",
        metavar="代理地址",
        help="可选 HTTP/HTTPS 代理，如 http://127.0.0.1:7897",
    )
    parser.add_argument(
        "--check-ip", action="store_true", help="仅显示本次请求的公网出口 IP"
    )
    parser.add_argument(
        "--max-published",
        type=int,
        default=1000,
        metavar="数量",
        help="最多读取多少条已发布素材",
    )
    parser.add_argument(
        "--max-materials",
        type=int,
        default=1000,
        metavar="数量",
        help="最多读取多少条永久图文素材",
    )
    parser.add_argument(
        "--skip-content", action="store_true", help="跳过所有正文读取，只保留指标"
    )
    parser.add_argument(
        "--skip-public-url",
        action="store_true",
        help="不从统计接口返回的本账号公开文章链接补全正文",
    )
    args = parser.parse_args()

    config = load_config(args.config, required=not args.check_ip)
    proxy = args.proxy or config.get("proxy") or None
    client = WeChatClient(proxy=proxy)
    if args.check_ip:
        print(f"本次请求的公网出口 IP：{client.public_ip()}")
        print("请把这个 IP 加入公众号后台 IP 白名单。")
        print("重要：该 IP 只对当前‘网络 + 代理开关 + 代理节点’组合有效。")
        print("切换网络或代理节点后，请重新运行 --check-ip 并更新白名单。")
        return 0

    if bool(args.start) != bool(args.end):
        parser.error("--start 和 --end 必须同时使用")
    if args.start and args.days:
        parser.error("--days 不能与 --start/--end 同时使用")
    if args.start:
        start, end = args.start, args.end
    else:
        days = args.days or config.get("default_days", 30)
        if days not in (7, 14, 30):
            parser.error("配置项 default_days 只能是 7、14 或 30")
        end = yesterday
        start = end - timedelta(days=days - 1)
    if end > yesterday:
        parser.error("结束日期最大为昨日")
    if start > end:
        parser.error("起始日期不能晚于结束日期")
    if start < DETAIL_START_DATE:
        parser.error(
            "文章明细接口仅存储 2025-11-01 起的数据；更早数据请从公众号后台导出"
        )

    appid = str(config.get("app_id") or "").strip()
    secret = str(config.get("app_secret") or "").strip()
    if not appid or not secret:
        parser.error("配置文件中的 app_id 和 app_secret 不能为空")
    output = args.output or Path(str(config.get("output_dir") or "mp-review-output"))

    print("正在获取安全调用凭据……")
    token = client.stable_token(appid, secret)
    raw_articles: list[dict[str, Any]] = []
    delayed_dates: list[str] = []
    print(f"正在按发表日期拉取 {start} 至 {end} 的文章明细……")
    for day in dates_between(start, end):
        response = client.article_details(token, day)
        delayed = bool(response.get("is_delay"))
        if delayed:
            delayed_dates.append(day.isoformat())
        for article in response.get("list") or []:
            article["_is_delay"] = delayed
            raw_articles.append(article)
        print(f"  {day}: {len(response.get('list') or [])} 篇")
        time.sleep(0.05)

    published: list[dict[str, Any]] = []
    materials: list[dict[str, Any]] = []
    published_error = None
    material_error = None
    public_url_errors: list[str] = []
    if not args.skip_content:
        print("正在读取已发布文章正文……")
        try:
            published = flatten_published(
                client.published_articles(token, args.max_published)
            )
        except RuntimeError as exc:
            published_error = str(exc)
            print(f"已发布文章列表读取失败：{exc}", file=sys.stderr)

        rows = normalize_articles(raw_articles, published)
        if any(not str(row.get("content_text") or "").strip() for row in rows):
            print("已发布列表未覆盖全部文章，正在读取永久图文素材……")
            try:
                material_items = client.permanent_materials(token, args.max_materials)
                materials = flatten_materials(client, token, material_items)
            except RuntimeError as exc:
                material_error = str(exc)
                print(f"永久图文素材读取失败：{exc}", file=sys.stderr)
            rows = normalize_articles(raw_articles, published, materials)

        if not args.skip_public_url and any(
            not str(row.get("content_text") or "").strip() for row in rows
        ):
            print("官方正文接口仍有缺失，正从本账号公开文章链接补全……")
            public_url_errors = fill_content_from_public_urls(client, rows)
            if public_url_errors:
                print(
                    f"有 {len(public_url_errors)} 篇公开文章未能补全，详情已写入报告。",
                    file=sys.stderr,
                )
    else:
        rows = normalize_articles(raw_articles, published, materials)

    content_errors = [value for value in (published_error, material_error) if value]
    report = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "start": start.isoformat(),
        "end": end.isoformat(),
        "article_count": len(rows),
        "published_content_count": len(published),
        "material_content_count": len(materials),
        "content_source_counts": {
            source: sum(row.get("content_source") == source for row in rows)
            for source in (
                "已发布文章列表",
                "永久图文素材",
                "本账号公开文章链接",
            )
        },
        "content_matched": sum(
            bool(str(row.get("content_text") or "").strip()) for row in rows
        ),
        "content_missing_or_ambiguous": sum(
            not str(row.get("content_text") or "").strip() for row in rows
        ),
        "delayed_dates": delayed_dates,
        "published_content_fetch_error": published_error,
        "material_content_fetch_error": material_error,
        "public_article_fetch_errors": public_url_errors,
        "content_fetch_error": " | ".join(content_errors) if content_errors else None,
        "notes": [
            "指标最多覆盖文章发表后 30 天。",
            "缺失值不是 0；复盘前请人工抽查标题、日期和文章数。",
        ],
    }
    write_outputs(output, rows, report)
    print(f"完成：{len(rows)} 篇文章，输出到 {output.resolve()}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, TypeError, KeyboardInterrupt) as exc:
        print(f"失败：{exc}", file=sys.stderr)
        raise SystemExit(1)
