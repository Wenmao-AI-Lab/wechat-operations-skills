#!/usr/bin/env python3
"""为微信公众号增长复盘生成高低表现候选索引。"""

from __future__ import annotations

import argparse
import html
import json
import math
import sys
from pathlib import Path
from typing import Any

GOAL_LABELS = {
    "balanced": "均衡探索",
    "reach": "扩大阅读",
    "share": "提升传播",
    "save": "提升收藏",
    "completion": "提升完读",
    "engagement": "提升互动",
    "trust": "建立信任（仅使用代理指标）",
    "conversion": "促进转化（缺少外部转化数据时仅使用代理指标）",
}

GOAL_METRICS = {
    "balanced": [
        ("read_user", 1.0),
        ("share_rate", 1.4),
        ("collection_rate", 1.4),
        ("like_rate", 0.7),
        ("comment_rate", 0.5),
        ("read_finish_rate", 1.2),
        ("read_avg_activetime", 0.6),
    ],
    "reach": [("read_user", 1.0)],
    "share": [("share_user", 1.0), ("share_rate", 1.0)],
    "save": [("collection_user", 1.0), ("collection_rate", 1.0)],
    "completion": [("read_finish_rate", 1.2), ("read_avg_activetime", 0.8)],
    "engagement": [
        ("zaikan_user", 0.8),
        ("like_user", 0.8),
        ("comment_count", 1.0),
        ("like_rate", 0.8),
        ("comment_rate", 1.0),
    ],
    # 公众号没有“信任”和“转化”的直接指标。这两个模式只用较接近的
    # 内容代理信号准备候选，最终报告必须结合用户提供的外部数据。
    "trust": [
        ("share_user", 0.8),
        ("collection_user", 1.0),
        ("read_finish_rate", 1.0),
        ("read_avg_activetime", 0.8),
    ],
    "conversion": [
        ("collection_user", 1.0),
        ("comment_count", 1.0),
        ("read_finish_rate", 0.8),
    ],
}


def translate_cli_error(message: str) -> str:
    """将 argparse 常见英文错误转换为中文。"""
    replacements = (
        ("the following arguments are required:", "缺少必填参数："),
        ("unrecognized arguments:", "无法识别的参数："),
        ("expected one argument", "需要一个值"),
        ("argument ", "参数 "),
    )
    for source, target in replacements:
        message = message.replace(source, target)
    return message


class ChineseArgumentParser(argparse.ArgumentParser):
    """使命令行帮助标题和错误前缀统一使用中文。"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs["add_help"] = False
        super().__init__(*args, **kwargs)
        self._positionals.title = "位置参数"
        self._optionals.title = "选项"
        self.add_argument("-h", "--help", action="help", help="显示帮助信息并退出")

    def format_usage(self) -> str:
        return super().format_usage().replace("usage:", "用法：", 1)

    def format_help(self) -> str:
        return super().format_help().replace("usage:", "用法：", 1)

    def error(self, message: str) -> None:
        self.print_usage(sys.stderr)
        self.exit(2, f"{self.prog}：错误：{translate_cli_error(message)}\n")


def number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)) and math.isfinite(float(value)):
        return float(value)
    try:
        parsed = float(value)
        return parsed if math.isfinite(parsed) else None
    except (TypeError, ValueError):
        return None


def percentile_ranks(rows: list[dict[str, Any]], field: str) -> dict[int, float]:
    values = [(index, number(row.get(field))) for index, row in enumerate(rows)]
    available = sorted((value, index) for index, value in values if value is not None)
    if not available:
        return {}
    if len(available) == 1:
        return {available[0][1]: 0.5}
    ranks: dict[int, float] = {}
    cursor = 0
    while cursor < len(available):
        end = cursor
        while (
            end + 1 < len(available) and available[end + 1][0] == available[cursor][0]
        ):
            end += 1
        rank = ((cursor + end) / 2) / (len(available) - 1)
        for position in range(cursor, end + 1):
            ranks[available[position][1]] = rank
        cursor = end + 1
    return ranks


def score_rows(
    rows: list[dict[str, Any]], metrics: list[tuple[str, float]]
) -> list[dict[str, Any]]:
    ranks = {field: percentile_ranks(rows, field) for field, _ in metrics}
    scored: list[dict[str, Any]] = []
    for index, row in enumerate(rows):
        total = 0.0
        weight_sum = 0.0
        used: list[str] = []
        for field, weight in metrics:
            if index in ranks[field]:
                total += ranks[field][index] * weight
                weight_sum += weight
                used.append(field)
        copy = dict(row)
        copy["review_score"] = total / weight_sum if weight_sum else 0.0
        copy["score_fields"] = used
        scored.append(copy)
    return sorted(scored, key=lambda row: row["review_score"], reverse=True)


def load_profile(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    try:
        profile = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise RuntimeError(f"找不到画像文件：{path}") from exc
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"画像文件不是有效 JSON：第 {exc.lineno} 行第 {exc.colno} 列"
        ) from exc
    if not isinstance(profile, dict):
        raise TypeError("画像文件顶层必须是 JSON 对象")
    articles = profile.get("articles")
    if articles is not None and not isinstance(articles, list):
        raise TypeError("画像文件中的 articles 必须是数组")
    return profile


def apply_content_types(
    rows: list[dict[str, Any]], profile: dict[str, Any]
) -> tuple[list[dict[str, Any]], int]:
    exact: dict[tuple[str, str], str] = {}
    by_title: dict[str, set[str]] = {}
    for article in profile.get("articles") or []:
        if not isinstance(article, dict):
            continue
        title = str(article.get("title") or "").strip()
        publish_date = str(article.get("publish_date") or "").strip()
        content_type = str(article.get("primary_type") or "").strip()
        if not title or not content_type:
            continue
        if publish_date:
            exact[(title, publish_date)] = content_type
        by_title.setdefault(title, set()).add(content_type)

    typed: list[dict[str, Any]] = []
    matched = 0
    for row in rows:
        copy = dict(row)
        title = str(row.get("title") or "").strip()
        publish_date = str(row.get("publish_date") or "").strip()
        content_type = exact.get((title, publish_date), "")
        if not content_type and len(by_title.get(title, set())) == 1:
            content_type = next(iter(by_title[title]))
        copy["content_type"] = content_type or "未分型"
        if content_type:
            matched += 1
        typed.append(copy)
    return typed, matched


def fmt(value: Any, percent: bool = False) -> str:
    parsed = number(value)
    if parsed is None:
        return "—"
    if percent:
        return f"{parsed * 100:.2f}%"
    if parsed.is_integer():
        return f"{int(parsed):,}"
    return f"{parsed:.2f}"


def cohort_size(count: int) -> int:
    if count < 4:
        return 0
    if count < 8:
        return max(1, count // 2)
    return max(2, count // 4)


def comparable_cohort_size(count: int) -> int:
    if count < 2:
        return 0
    return max(1, count // 4)


def escape(value: Any) -> str:
    return html.escape(str(value), quote=True)


def table(rows: list[dict[str, Any]]) -> str:
    body: list[str] = []
    for row in rows:
        title = escape(row.get("title") or "未命名")
        content_length = len(str(row.get("content_text") or "").strip())
        body.append(
            "<tr>"
            f'<td class="article-title">{title}</td>'
            f"<td>{escape(row.get('publish_date') or '—')}</td>"
            f"<td>{escape(fmt(row.get('read_user')))}</td>"
            f"<td>{escape(fmt(row.get('share_rate'), True))}</td>"
            f"<td>{escape(fmt(row.get('collection_rate'), True))}</td>"
            f"<td>{escape(fmt(row.get('like_rate'), True))}</td>"
            f"<td>{escape(fmt(row.get('comment_rate'), True))}</td>"
            f"<td>{escape(fmt(row.get('read_finish_rate'), True))}</td>"
            f"<td>{content_length:,}</td>"
            f"<td>{float(row.get('review_score', 0)):.3f}</td>"
            "</tr>"
        )
    return (
        '<div class="table-wrap"><table><thead><tr>'
        "<th>文章</th><th>日期</th><th>阅读</th><th>分享率</th>"
        "<th>收藏率</th><th>点赞率</th><th>留言率</th><th>完读率</th>"
        "<th>正文字符</th><th>目标候选分</th>"
        "</tr></thead><tbody>" + "".join(body) + "</tbody></table></div>"
    )


def cohort_index(label: str, rows: list[dict[str, Any]]) -> str:
    return f"<section><h2>{escape(label)}</h2>{table(rows)}</section>"


def content_type_cohorts(
    rows: list[dict[str, Any]], metrics: list[tuple[str, float]]
) -> str:
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(str(row.get("content_type") or "未分型"), []).append(row)
    output = ["<section><h2>同类型可比候选</h2>"]
    for content_type, group in sorted(groups.items()):
        output.append(
            f'<article class="cohort"><h3>{escape(content_type)}'
            f'<span class="count">{len(group)} 篇</span></h3>'
        )
        size = comparable_cohort_size(len(group))
        if not size:
            output.append(
                '<p class="empty">缺少同类型可比样本，不建立高低对照。</p></article>'
            )
            continue
        scored = score_rows(group, metrics)
        output.append('<h4><span class="dot high"></span>高位候选</h4>')
        output.append(table(scored[:size]))
        output.append('<h4><span class="dot low"></span>低位候选</h4>')
        output.append(table(scored[-size:]))
        output.append("</article>")
    output.append("</section>")
    return "".join(output)


def metric_candidates(rows: list[dict[str, Any]], size: int) -> str:
    targets = [
        ("打开规模", [("read_user", 1.0)]),
        ("传播潜力", [("share_user", 1.0), ("share_rate", 1.0)]),
        ("收藏价值", [("collection_user", 1.0), ("collection_rate", 1.0)]),
        (
            "内容承接",
            [("read_finish_rate", 1.2), ("read_avg_activetime", 0.8)],
        ),
        (
            "互动潜力",
            [("like_user", 0.8), ("comment_count", 1.0), ("like_rate", 0.8)],
        ),
    ]
    output = [
        "<section><h2>按目标拆分的全样本候选</h2>",
        '<p class="section-note">以下名单只用于定位文章；跨类型排名不能直接形成内容规律。</p>',
        '<div class="metric-grid">',
    ]
    for label, metrics in targets:
        available = [
            row
            for row in rows
            if any(number(row.get(field)) is not None for field, _ in metrics)
        ]
        if not available:
            output.append(
                f'<article class="metric-card"><h3>{escape(label)}</h3>'
                '<p class="empty">没有可用指标。</p></article>'
            )
            continue
        ordered = score_rows(available, metrics)
        high = "、".join(str(row.get("title") or "未命名") for row in ordered[:size])
        low = "、".join(str(row.get("title") or "未命名") for row in ordered[-size:])
        fields = " + ".join(field for field, _ in metrics)
        output.append(
            f'<article class="metric-card"><h3>{escape(label)}</h3>'
            f'<p class="metric-fields">{escape(fields)}</p>'
            f"<p><strong>高位：</strong>{escape(high or '无')}</p>"
            f"<p><strong>低位：</strong>{escape(low or '无')}</p></article>"
        )
    output.append("</div></section>")
    return "".join(output)


def render_document(
    *,
    rows: list[dict[str, Any]],
    profile: dict[str, Any],
    typed_count: int,
    goal: str,
    confidence: str,
    missing_content: int,
    body: str,
) -> str:
    industry = str(profile.get("industry") or "未知") if profile else "未建立画像"
    positioning = (
        str(profile.get("account_positioning") or "未知") if profile else "未建立画像"
    )
    warning = ""
    if goal == "trust":
        warning = (
            '<div class="warning"><strong>指标边界：</strong>公众号没有信任的直接指标；'
            "当前排序只使用收藏、分享和承接等代理信号。</div>"
        )
    elif goal == "conversion":
        warning = (
            '<div class="warning"><strong>指标边界：</strong>公众号原生数据不能代表商业转化；'
            "没有咨询、到店、购买或报名数据时不得下转化结论。</div>"
        )
    coverage = f"{typed_count}/{len(rows)}" if profile else "—"
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>公众号增长复盘候选索引</title>
  <style>
    :root {{ --ink:#18231f; --muted:#64716b; --paper:#f5f1e8; --card:#fffdf8; --line:#ded8ca; --green:#176b52; --mint:#dcebe4; --amber:#b56b2d; --red:#a64b42; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; color:var(--ink); background:var(--paper); font:15px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif; }}
    main {{ width:min(1180px,calc(100% - 32px)); margin:32px auto 72px; }}
    header {{ padding:40px; color:#f8f5ed; border-radius:24px; background:linear-gradient(135deg,#102d25,#1d654f 68%,#b47a42); box-shadow:0 18px 50px #15352b24; }}
    .eyebrow {{ margin:0 0 8px; color:#b7dbc9; font-size:12px; font-weight:800; letter-spacing:.16em; text-transform:uppercase; }}
    h1 {{ margin:0; font-size:clamp(30px,5vw,54px); line-height:1.08; letter-spacing:-.04em; }}
    .subtitle {{ max-width:760px; margin:14px 0 0; color:#dbe8e2; }}
    .summary {{ display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px; margin:18px 0 0; }}
    .stat {{ padding:16px 18px; border:1px solid #ffffff26; border-radius:16px; background:#ffffff12; }}
    .stat span {{ display:block; color:#bfcec7; font-size:12px; }} .stat strong {{ display:block; margin-top:2px; font-size:18px; }}
    .context {{ display:grid; grid-template-columns:1fr 1.4fr; gap:14px; margin:16px 0; }}
    .context article, section {{ padding:26px; border:1px solid var(--line); border-radius:20px; background:var(--card); box-shadow:0 8px 26px #2b3c3210; }}
    .context span {{ display:block; color:var(--muted); font-size:12px; font-weight:700; }} .context strong {{ font-size:17px; }}
    .warning {{ margin:16px 0; padding:16px 18px; border-left:4px solid var(--amber); border-radius:12px; background:#fff4df; }}
    section {{ margin-top:16px; }} h2 {{ margin:0 0 14px; font-size:24px; letter-spacing:-.02em; }}
    h3 {{ margin:0 0 12px; font-size:18px; }} h4 {{ margin:20px 0 8px; color:var(--muted); font-size:13px; letter-spacing:.04em; }}
    .count {{ margin-left:8px; padding:3px 8px; color:var(--green); border-radius:999px; background:var(--mint); font-size:12px; vertical-align:middle; }}
    .cohort {{ padding:22px 0; border-top:1px solid var(--line); }} .cohort:first-of-type {{ border-top:0; }}
    .table-wrap {{ width:100%; overflow:auto; border:1px solid var(--line); border-radius:14px; }}
    table {{ width:100%; border-collapse:collapse; min-width:940px; background:white; }}
    th,td {{ padding:11px 12px; border-bottom:1px solid #ece8de; text-align:right; white-space:nowrap; }}
    th {{ color:var(--muted); background:#f7f5ef; font-size:12px; }} th:first-child,td:first-child {{ text-align:left; }}
    tbody tr:last-child td {{ border-bottom:0; }} .article-title {{ max-width:320px; overflow:hidden; text-overflow:ellipsis; }}
    .dot {{ display:inline-block; width:8px; height:8px; margin-right:7px; border-radius:50%; }} .high {{ background:var(--green); }} .low {{ background:var(--red); }}
    .section-note,.empty {{ color:var(--muted); }} .metric-grid {{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; }}
    .metric-card {{ padding:18px; border:1px solid var(--line); border-radius:14px; background:#fff; }} .metric-card p {{ margin:7px 0 0; }}
    .metric-fields {{ color:var(--green); font:12px ui-monospace,SFMono-Regular,Menlo,monospace; }}
    ol {{ margin:0; padding-left:1.4em; }} li + li {{ margin-top:7px; }} footer {{ margin-top:20px; color:var(--muted); font-size:12px; text-align:center; }}
    @media(max-width:760px) {{ main {{ width:min(100% - 20px,1180px); margin-top:10px; }} header,section {{ padding:22px; border-radius:16px; }} .summary,.context,.metric-grid {{ grid-template-columns:1fr; }} }}
    @media print {{ body {{ background:white; }} main {{ width:100%; margin:0; }} header {{ color:var(--ink); background:white; box-shadow:none; border:1px solid var(--line); }} .subtitle,.eyebrow {{ color:var(--muted); }} section,.context article {{ box-shadow:none; break-inside:avoid; }} }}
  </style>
</head>
<body><main>
  <header>
    <p class="eyebrow">MP REVIEW · INTERNAL EVIDENCE INDEX</p>
    <h1>公众号增长复盘候选索引</h1>
    <p class="subtitle">供 AI 进行语义复盘的候选定位文件；不展开文章观点，也不把相对候选分当作最终结论。</p>
    <div class="summary">
      <div class="stat"><span>样本数</span><strong>{len(rows)} 篇</strong></div>
      <div class="stat"><span>正文缺失</span><strong>{missing_content} 篇</strong></div>
      <div class="stat"><span>内容分型覆盖</span><strong>{escape(coverage)}</strong></div>
      <div class="stat"><span>本次目标</span><strong>{escape(GOAL_LABELS[goal])}</strong></div>
    </div>
  </header>
  <div class="context">
    <article><span>行业</span><strong>{escape(industry)}</strong></article>
    <article><span>账号定位</span><strong>{escape(positioning)}</strong></article>
  </div>
  <div class="warning"><strong>判断边界：</strong>{escape(confidence)} 目标候选分仅表示同批次相对排序，不代表因果或跨账号绝对水平。</div>
  {warning}
  {body}
  <section><h2>增长复盘待回答问题</h2><ol>
    <li>同类型文章中，哪些“人群 + 关注动机 + 场景 + 内容承诺”组合呈现更高潜力？</li>
    <li>可比文章在标题钩子、情绪强度、具体性和阅读价值上有什么稳定差异？</li>
    <li>各内容类型分别适合哪些口吻、细节/案例密度、结构节奏和篇幅？</li>
    <li>哪些差异可能由发布时间、通知状态、题材或样本量造成？</li>
    <li>下一周期优先写哪些高潜选题，并用什么单变量实验验证？</li>
  </ol></section>
  <footer>本文件为内部证据索引。最终用户报告应另存为独立 HTML 文件。</footer>
</main></body></html>"""


def main() -> int:
    parser = ChineseArgumentParser(description="生成公众号高低表现文章候选索引")
    parser.add_argument(
        "input",
        type=Path,
        metavar="输入文件",
        help="fetch_wechat_data.py 输出的 JSON 文件",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("review_brief.html"),
        metavar="输出文件",
        help="复盘简报输出路径",
    )
    parser.add_argument(
        "--goal",
        choices=tuple(GOAL_METRICS),
        metavar="目标",
        help=(
            "复盘目标：balanced、reach、share、save、completion、engagement、"
            "trust 或 conversion"
        ),
    )
    parser.add_argument(
        "--profile",
        type=Path,
        metavar="画像文件",
        help="AI 生成的 review_profile.json；用于读取目标并按内容类型比较",
    )
    args = parser.parse_args()
    rows = json.loads(args.input.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        parser.error("输入 JSON 顶层必须是文章数组")
    profile = load_profile(args.profile)
    profile_goal = str(profile.get("primary_goal") or "").strip()
    goal = args.goal or profile_goal or "balanced"
    if goal not in GOAL_METRICS:
        parser.error(
            "画像文件中的 primary_goal 无效；可选 balanced、reach、share、save、"
            "completion、engagement、trust 或 conversion"
        )
    typed_rows, typed_count = apply_content_types(rows, profile)
    scored = score_rows(typed_rows, GOAL_METRICS[goal])
    size = cohort_size(len(scored))
    if size:
        top = scored[:size]
        bottom = scored[-size:]
    else:
        top = scored
        bottom = []

    confidence = (
        "样本少于 4 篇，不建立好坏对照组，仅做逐篇观察。"
        if len(scored) < 4
        else "样本为 4–7 篇，按上下半区探索性比较，不下强结论。"
        if len(scored) < 8
        else "样本达到 8 篇，使用上下四分位文章做对照；仍需控制发布时间、通知状态和题材差异。"
    )
    missing_content = sum(
        not str(row.get("content_text") or "").strip() for row in scored
    )
    body_parts: list[str] = []
    if profile:
        body_parts.append(content_type_cohorts(typed_rows, GOAL_METRICS[goal]))
    else:
        body_parts.append(cohort_index("未分型高表现候选组", top))
        if bottom:
            body_parts.append(cohort_index("未分型低表现候选组", bottom))
    if size:
        body_parts.append(metric_candidates(scored, size))
    document = render_document(
        rows=scored,
        profile=profile,
        typed_count=typed_count,
        goal=goal,
        confidence=confidence,
        missing_content=missing_content,
        body="".join(body_parts),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(document, encoding="utf-8")
    print(f"已生成：{args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
